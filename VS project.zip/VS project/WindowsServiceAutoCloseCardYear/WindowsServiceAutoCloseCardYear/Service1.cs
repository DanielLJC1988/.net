﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using Newtonsoft.Json;
using System.Net;
using System.Threading;
using System.Security.Cryptography;
using System.Net.Mail;

namespace WindowsServiceAutoCloseCardYear
{
    public partial class Service1 : ServiceBase
    {
        //定时器  
        System.Timers.Timer t1 = null;
        System.Timers.Timer t2 = null;

        System.Timers.Timer t5 = null;
        System.Timers.Timer t6 = null;

        System.Timers.Timer t7 = null;
        System.Timers.Timer t8 = null;

        System.Timers.Timer t3 = null;
        System.Timers.Timer t4 = null;
        System.Timers.Timer t9 = null;
        System.Timers.Timer t10 = null;
        System.Timers.Timer t11 = null;
        System.Timers.Timer t12 = null;

        //定义全局变量类Condition，其中的condition
        class Condition
        {
            //用来把sql语句赋值给下面的全局变量

            public static string condition = "";
            public static string condition2 = "";
            public static string conditionOther = "";
            //public static string condition2Other = "";

            public static string condition3 = "";
            public static string condition4 = "";

            public static string conditiontest = "";
            public static string conditiontest2 = "";
            public static string conditiontestOther = "";

            public static string account_error = "";
            public static List<Account> listData;
            public static string geturlvalue = "";
        }

        //定义json类
        public class Account
        {
            public string reason { get; set; }      //获取响应状态
            public string id { get; set; }          //获取ID号
            public string status { get; set; }      //获取卡状态
            public string imsi { get; set; }        //获取imsi号码
            public string msisdn { get; set; }      //获取msisdn号码

        }

        //定义返回URL值
        private string GetContentFromUrll(string _requestUrl)
        {
            string _StrResponse = "";
            HttpWebRequest _WebRequest = (HttpWebRequest)WebRequest.Create(_requestUrl);
            _WebRequest.Method = "GET";
            WebResponse _WebResponse = _WebRequest.GetResponse();
            StreamReader _ResponseStream = new StreamReader(_WebResponse.GetResponseStream(), System.Text.Encoding.GetEncoding("gb2312"));
            _StrResponse = _ResponseStream.ReadToEnd();
            _WebResponse.Close();
            _ResponseStream.Close();
            return _StrResponse;
        }

        public Service1()
        {
            InitializeComponent();
            //启用暂停恢复  
            base.CanPauseAndContinue = true;

            t1 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t1.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent1);
            t1.AutoReset = true;
            t1.Enabled = true;

            t2 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t2.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent2);
            t2.AutoReset = true;
            t2.Enabled = true;

            t3 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t3.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent3);
            t3.AutoReset = true;
            t3.Enabled = true;

            t4 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t4.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent4);
            t4.AutoReset = true;
            t4.Enabled = true;

            t9 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t9.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent9);
            t9.AutoReset = true;
            t9.Enabled = true;

            t10 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t10.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent10);
            t10.AutoReset = true;
            t10.Enabled = true;

            t11 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t11.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent11);
            t11.AutoReset = true;
            t11.Enabled = true;

            t12 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t12.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent12);
            t12.AutoReset = true;
            t12.Enabled = true;

            t5 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t5.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent5);
            t5.AutoReset = true;
            t5.Enabled = true;

            t6 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t6.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent6);
            t6.AutoReset = true;
            t6.Enabled = true;

            t7 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t7.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent7);
            t7.AutoReset = true;
            t7.Enabled = true;

            t8 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t8.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent8);
            t8.AutoReset = true;
            t8.Enabled = true;

        }

        protected override void OnStart(string[] args)
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "启动";
            WriteLog(state);
        }

        //停止服务执行  
        protected override void OnStop()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "停止";
            WriteLog(state);
        }

        //恢复服务执行  
        protected override void OnContinue()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "继续";
            WriteLog(state);
            t1.Start();
            t2.Start();
            t3.Start();
            t4.Start();
            t5.Start();
            t6.Start();
            t7.Start();
            t8.Start();
            t9.Start();
            t10.Start();
            t11.Start();
            t12.Start();
        }

        //暂停服务执行  
        protected override void OnPause()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "暂停";
            WriteLog(state);
            t1.Stop();
            t2.Stop();
            t3.Stop();
            t4.Stop();
            t5.Stop();
            t6.Stop();
            t7.Stop();
            t8.Stop();
            t9.Stop();
            t10.Stop();
            t11.Stop();
            t12.Stop();
        }

        public void WriteLog(string str)
        {
            using (StreamWriter sw = File.AppendText(@"d:\AutoCardCloseYear.txt"))
            {
                sw.WriteLine(str);
                sw.Flush();
            }
        }

        public void OnTimedEvent1(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 00;
            int ihour = 6;


            Condition.condition = " where (Traffic.source like  '169.%'  ) ";
            Condition.condition2 = " where (Traffic2.source like  '169.%'  ) ";
            Condition.conditionOther = " where (IP like '10.32%' or IP like '10.255.217.251%' or IP like '10.255.217.255%' or IP like '172.16%'  or IP like '169.%' or IP like '10.3%' or IP like '130.130.1%' or IP like '192.168.254.%' ) ";


            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                //string sqlEK = " select datediff(day,OutDate,getdate()) as 使用天数,ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State,Property, sum(流量) as 流量 from ("
                //       + " select source ,sum(traffic) as 流量  "
                //       + " from Traffic2 "
                //       + Condition.condition2;




                //sqlEK += string.Format("  group by source ")
                //    + " union "
                //    + " select source ,sum(traffic) as 流量 "
                //    + " from Traffic "
                //    + Condition.condition;



                //sqlEK += string.Format("  group by source ")
                //    + " )Traffic2 inner join ClientInfo  ON source = IP "
                //        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, Property, Outdate  having  "
                //    + "  State <> '关停'  and ClientName <> '闲置在库'  and Property = '包年' and datediff(day,Outdate,getdate()) > 365 ";
                //sqlEK += " order by 使用天数 DESC ";


                    string sqlEK = " select datediff(day,OutDate,getdate()) as 使用天数,ClientName, IP, Card, MailAddress, MailAddressCC, Outdate,State  from ClientInfo  "
                        + Condition.conditionOther
                        + " and State <> '关停'  and ClientName <> '闲置在库' and Property = '包年' and datediff(day,Outdate,getdate()) > 365  ";
                    sqlEK += "  order by 使用天数 DESC ";


                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string usedate = myReader["使用天数"].ToString();
                    string client = myReader["ClientName"].ToString();
                    //string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    //string Traffictotal = myReader["Traffic"].ToString();
                    //string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    //decimal dectraffictotal = decimal.Parse(Traffictotal);
                    //decimal dectrafficuse = decimal.Parse(Trafficuse);
                    //decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"3G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("noc@fashion-tele.com," + MailAddress);//收件人
                    mmsg.CC.Add("service@fashion-tele.com," + MailAddressCC);//抄送人
                    mmsg.Bcc.Add("sales1@fashion-tele.com,business@fashion-tele.com");
                    mmsg.IsBodyHtml = true;
                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 的包年卡已使用了" + usedate + "天！！ 现已被系统自动关停！！ ";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 的包年卡已使用了 <b>" + usedate + "天</b>" + " ，现已被系统自动关停！！如需继续使用请和相关人员联系，谢谢！！" 
                              + "<br><br>"; //----------------------<br>軟銀通信科技（上海）有限公司<br>SoftBank Telecom China CO., LTD<br><br>愛思梯安莱通信科技（蘇州）有限公司<br>SBTM ONLINE（SUZHOU）CO., LTD<br><br>営業支援課<br>Email : STSGRP-chinasalessp@g.softbank.co.jp<br>----------------------";


                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "smtp.exmail.qq.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                    try
                    {
                        //SmtpMail.Send(mmsg);//发送邮件
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent2(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 00;
            int ihour = 6;


            Condition.condition = " where (Traffic.source like '169.%'  ) ";
            Condition.condition2 = " where (Traffic2.source like '169.%'  ) ";
            Condition.conditionOther = " where (IP like '10.32%' or IP like '10.255.217.251%' or IP like '10.255.217.255%' or IP like '172.16%'  or IP like '169.%' or IP like '10.3%' or IP like '130.130.1%' or IP like '192.168.254.%' ) ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                //string SqlClose = " select datediff(day,OutDate,getdate()) as 使用天数,ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State,Property, sum(流量) as 流量 from ("
                //       + " select source ,sum(traffic) as 流量  "
                //       + " from Traffic2 "
                //       + Condition.condition2;




                //SqlClose += string.Format("  group by source ")
                //    + " union "
                //    + " select source ,sum(traffic) as 流量 "
                //    + " from Traffic "
                //    + Condition.condition;


                //SqlClose += string.Format("  group by source ")
                //    + " )Traffic2 inner join ClientInfo  ON source = IP "
                //        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, Property, Outdate  having  "
                //    + "  State <> '关停'  and Property = '包年' and ClientName <> '闲置在库' and datediff(day,Outdate,getdate()) > 365  ";
                //SqlClose += " order by 使用天数 DESC ";


                string SqlClose = " select datediff(day,OutDate,getdate()) as 使用天数,CardType, ClientName, IP, Card, MailAddress, MailAddressCC, Outdate,State  from ClientInfo  "
                    + Condition.conditionOther
                    + " and State <> '关停'  and ClientName <> '闲置在库' and Property = '包年' and datediff(day,Outdate,getdate()) > 365  ";
                SqlClose += "  order by 使用天数 DESC ";


                SqlCommand cmd = new SqlCommand(SqlClose, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string usedate = myReader["使用天数"].ToString();
                    string CardType = myReader["CardType"].ToString();
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    //string Traffictotal = myReader["Traffic"].ToString();
                    //string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    string sql = "";
                    string sql2 = "";
                    string StateOpen = "启用";
                    string StateClose = "关停";

                    string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
                    string Role;

                    //声明数据库
                    string strconn1 = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                    SqlConnection conn1 = new SqlConnection(strconn1);
                    if (State.Equals("启用") || State.Equals("忽略") && !CardType.Equals("4G卡"))
                    {

                        //string jsonText = "act=sms&mobile=&msg=短信平台测试短信";
                        string sURL = "http://169.2.3.8:80/card/search/" + source1;

                        WebRequest wrGETURL;
                        wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

                        string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
                        Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                        string reason = account.reason;                                         //取出返回值名称为reason的数值
                        string id = account.id;                                                 //取出返回值名称为id的数值
                        string status = account.status;
                        string msisdn = account.msisdn;
                        string imsi = account.imsi;

                        if (reason == "Success!" && status == "active")
                        {
                            if (msisdn != null)
                            {
                                string sURL2 = "http://169.2.3.8:80/card/status/" + msisdn + "/" + "inactive";

                                WebRequest wrGETURL2;
                                wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                                string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                                Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                                string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                                string id2 = account2.id;                                                 //取出返回值名称为id的数值
                                string status2 = account2.status;

                                if (reason2 == "Success!" && status2 == "inactive")
                                {

                                    //暂时更新此卡数据库状态信息为 开启/关停
                                    sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command = new SqlCommand(sql, conn1);
                                    int result = command.ExecuteNonQuery();
                                    conn1.Close();



                                    Role = "自动系统";
                                    //写入数据库日志
                                    sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1}'  ,'将卡号为: {2} 关停')", logtime, Role, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command2 = new SqlCommand(sql2, conn1);
                                    int result2 = command2.ExecuteNonQuery();
                                    conn1.Close();

                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
                                }
                                else
                                {
                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
                                }
                            }

                            else if (imsi != null)
                            {
                                string sURL2 = "http://169.2.3.8:80/card/status/" + imsi + "/" + "inactive";

                                WebRequest wrGETURL2;
                                wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                                string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                                Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                                string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                                string id2 = account2.id;                                                 //取出返回值名称为id的数值
                                string status2 = account2.status;

                                if (reason2 == "Success!" && status2 == "inactive")
                                {

                                    //暂时更新此卡数据库状态信息为 开启/关停
                                    sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command = new SqlCommand(sql, conn1);
                                    int result = command.ExecuteNonQuery();
                                    conn1.Close();



                                    Role = "自动系统";
                                    //写入数据库日志
                                    sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} ','将卡号为: {2} 关停')", logtime, Role, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command2 = new SqlCommand(sql2, conn1);
                                    int result2 = command2.ExecuteNonQuery();
                                    conn1.Close();

                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
                                }
                                else
                                {
                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
                                }
                            }

                        }
                    }
                    #region 状态为启用的4G卡执行
                    else if (State.Equals("启用") && CardType.Equals("4G卡"))
                    {


                        string sURL = "http://169.2.3.8:80/l2tp/search/" + source1;

                        WebRequest wrGETURL;
                        wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

                        string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
                        Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                        string reason = account.reason;
                        string status = account.status;

                        if (reason == "Success!" && status == "active")
                        {

                            string sURL2 = "http://169.2.3.8:80/l2tp/inactive/" + source1;

                            WebRequest wrGETURL2;
                            wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                            string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                            Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                            //string error2 = account2.error;                                           //取出返回值名称为id的数值
                            //string reason2 = account2.reason;

                            //if (reason2 == "Success!" && error2 == "False")
                            //{

                            //暂时更新此卡数据库状态信息为 开启/关停
                            sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                            //打开数据库连接
                            conn1.Open();

                            //创建command对象
                            SqlCommand command = new SqlCommand(sql, conn1);
                            int result = command.ExecuteNonQuery();
                            conn1.Close();



                            Role = "自动系统";
                            //写入数据库日志
                            sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} ','将卡号为: {2} 关停')", logtime, Role, card);                                //打开数据库连接
                            conn1.Open();

                            //创建command对象
                            SqlCommand command2 = new SqlCommand(sql2, conn1);
                            int result2 = command2.ExecuteNonQuery();
                            conn1.Close();

                            WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停4G卡成功 ");
                            //}
                            //else
                            //{
                            //WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停3G卡失败 ");
                            //}


                        }
                        //}
                    #endregion

                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }


        public void OnTimedEvent5(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 01;
            int ihour = 10;



            

            Condition.condition3 = " and  IP like  '169.%'  and IP not like '169.1.53.%' and IP not like '169.6.12.%' and IP not like '169.6.6.%' and IP not like '169.6.7.%' ";


            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  datediff(day,OutDate,getdate()) as 使用天数, ClientName, IP, Card,  CardType, Traffic, MailAddress, MailAddressCC,State, Property, sum(total) as 流量 from TrafficL2 "
                        + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                        + Condition.condition3
                        + " and date > = Outdate and datediff(day,OutDate,getdate()) < 365 ";


                sqlEK += " group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State,Property,OutDate  "
                       + " having sum(total) >= Traffic     and State <> '关停' and IP is not Null  and State <> '忽略' and ClientName <> '浦发'   and ClientName not like '%哈希%' and Property = '包年' "
                       + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string timeJP = System.DateTime.Now.ToString("MM月dd日HH時");

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("noc@fashion-tele.com," + MailAddress);//收件人
                    mmsg.CC.Add("service@fashion-tele.com," + MailAddressCC);//抄送人
                    mmsg.Bcc.Add("sales1@fashion-tele.com,business@fashion-tele.com");
                    mmsg.IsBodyHtml = true;
                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本年已使用超过套餐流量，现已被系统自动关停！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本年套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，本年套餐流量已用尽，现已被系统自动关停！！"
                              + "<br><br>"; 


                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "smtp.exmail.qq.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                    try
                    {
                        //SmtpMail.Send(mmsg);//发送邮件
                        smtpclient.Send(mmsg);
                        System.Threading.Thread.Sleep(500);
                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent6(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 05;
            int ihour = 10;



            Condition.condition3 = " and  IP like  '169.%'  and IP not like '169.1.53.%' and IP not like '169.6.12.%' and IP not like '169.6.6.%' and IP not like '169.6.7.%' ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();




                string SqlClose = " select  datediff(day,OutDate,getdate()) as 使用天数, ClientName, IP, Card,  CardType, Traffic, MailAddress, MailAddressCC,State, Property, sum(total) as 流量 from TrafficL2 "
                        + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                        + Condition.condition3
                        + " and date > = Outdate and datediff(day,OutDate,getdate()) < 365 ";


                SqlClose += " group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State,Property,OutDate  "
                       + " having sum(total) >= Traffic     and State <> '关停' and IP is not Null  and State <> '忽略' and ClientName <> '浦发'   and ClientName not like '%哈希%' and Property = '包年' "
                       + " order by 流量 DESC ";


                SqlCommand cmd = new SqlCommand(SqlClose, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string usedate = myReader["使用天数"].ToString();
                    string CardType = myReader["CardType"].ToString();
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    //string Traffictotal = myReader["Traffic"].ToString();
                    //string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    string sql = "";
                    string sql2 = "";
                    string StateOpen = "启用";
                    string StateClose = "关停";

                    string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
                    string Role;

                    //声明数据库
                    string strconn1 = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                    SqlConnection conn1 = new SqlConnection(strconn1);
                    if (CardType.Equals("3G卡"))
                    {

                        //string jsonText = "act=sms&mobile=&msg=短信平台测试短信";
                        string sURL = "http://169.2.3.8:80/card/search/" + source1;

                        WebRequest wrGETURL;
                        wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

                        string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
                        Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                        string reason = account.reason;                                         //取出返回值名称为reason的数值
                        string id = account.id;                                                 //取出返回值名称为id的数值
                        string status = account.status;
                        string msisdn = account.msisdn;
                        string imsi = account.imsi;

                        if (reason == "Success!" && status == "active")
                        {
                            if (msisdn != null)
                            {
                                string sURL2 = "http://169.2.3.8:80/card/status/" + msisdn + "/" + "inactive";

                                WebRequest wrGETURL2;
                                wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                                string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                                Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                                string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                                string id2 = account2.id;                                                 //取出返回值名称为id的数值
                                string status2 = account2.status;

                                if (reason2 == "Success!" && status2 == "inactive")
                                {

                                    //暂时更新此卡数据库状态信息为 开启/关停
                                    sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}'  ", StateClose, source1);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command = new SqlCommand(sql, conn1);
                                    int result = command.ExecuteNonQuery();
                                    conn1.Close();



                                    Role = "自动系统";
                                    //写入数据库日志
                                    sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1}'  ,'将卡号为: {2} 关停')", logtime, Role, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command2 = new SqlCommand(sql2, conn1);
                                    int result2 = command2.ExecuteNonQuery();
                                    conn1.Close();

                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
                                }
                                else
                                {
                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
                                }
                            }

                            else if (imsi != null)
                            {
                                string sURL2 = "http://169.2.3.8:80/card/status/" + imsi + "/" + "inactive";

                                WebRequest wrGETURL2;
                                wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                                string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                                Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                                string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                                string id2 = account2.id;                                                 //取出返回值名称为id的数值
                                string status2 = account2.status;

                                if (reason2 == "Success!" && status2 == "inactive")
                                {

                                    //暂时更新此卡数据库状态信息为 开启/关停
                                    sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command = new SqlCommand(sql, conn1);
                                    int result = command.ExecuteNonQuery();
                                    conn1.Close();



                                    Role = "自动系统";
                                    //写入数据库日志
                                    sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} ','将卡号为: {2} 关停')", logtime, Role, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command2 = new SqlCommand(sql2, conn1);
                                    int result2 = command2.ExecuteNonQuery();
                                    conn1.Close();

                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
                                }
                                else
                                {
                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
                                }
                            }

                        }
                    }
                    #region 状态为启用的4G卡执行
                    else if (State.Equals("启用") && CardType.Equals("4G卡"))
                    {


                        string sURL = "http://169.2.3.8:80/l2tp/search/" + source1;

                        WebRequest wrGETURL;
                        wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

                        string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
                        Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                        string reason = account.reason;
                        string status = account.status;

                        if (reason == "Success!" && status == "active")
                        {

                            string sURL2 = "http://169.2.3.8:80/l2tp/inactive/" + source1;

                            WebRequest wrGETURL2;
                            wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                            string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                            Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                            //string error2 = account2.error;                                           //取出返回值名称为id的数值
                            //string reason2 = account2.reason;

                            //if (reason2 == "Success!" && error2 == "False")
                            //{

                            //暂时更新此卡数据库状态信息为 开启/关停
                            sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                            //打开数据库连接
                            conn1.Open();

                            //创建command对象
                            SqlCommand command = new SqlCommand(sql, conn1);
                            int result = command.ExecuteNonQuery();
                            conn1.Close();



                            Role = "自动系统";
                            //写入数据库日志
                            sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} ','将卡号为: {2} 关停')", logtime, Role, card);                                //打开数据库连接
                            conn1.Open();

                            //创建command对象
                            SqlCommand command2 = new SqlCommand(sql2, conn1);
                            int result2 = command2.ExecuteNonQuery();
                            conn1.Close();

                            WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停4G卡成功 ");
                            //}
                            //else
                            //{
                            //WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停3G卡失败 ");
                            //}


                        }
                        //}
                    #endregion

                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent7(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 07;
            int ihour = 10;





            Condition.condition4 = " where (  IP like  '169.%'  and IP not like '169.1.53.%' and IP not like '169.6.12.%' and IP not like '169.6.6.%' and IP not like '169.6.7.%') ";


            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select datediff(day,OutDate,getdate()) as 使用天数,ClientName, IP, Card, Outdate,State, MailAddress, MailAddressCC  from ClientInfo  "
                   + Condition.condition4
                   + " and State <> '关停' and State <> '忽略' and ClientName <> '闲置在库' and Property = '包年' and datediff(day,Outdate,getdate()) >= 365  ";
                sqlEK += "  order by 使用天数 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string timeJP = System.DateTime.Now.ToString("MM月dd日HH時");

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    //decimal dectraffictotal = decimal.Parse(Traffictotal);
                    //decimal dectrafficuse = decimal.Parse(Trafficuse);
                    //decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("noc@fashion-tele.com," + MailAddress);//收件人
                    mmsg.CC.Add("service@fashion-tele.com," + MailAddressCC);//抄送人
                    mmsg.Bcc.Add("sales1@fashion-tele.com,business@fashion-tele.com");
                    mmsg.IsBodyHtml = true;
                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 的包年卡已经到期，现已被系统自动关停！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 的包年卡已经到期，现已被系统自动关停！！"
                              + "<br><br>";


                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "smtp.exmail.qq.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                    try
                    {
                        //SmtpMail.Send(mmsg);//发送邮件
                        smtpclient.Send(mmsg);
                        System.Threading.Thread.Sleep(500);
                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent8(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 10;
            int ihour = 10;



            Condition.condition4 = " where ( IP like  '169.%'  and IP not like '169.1.53.%' and IP not like '169.6.12.%' and IP not like '169.6.6.%' and IP not like '169.6.7.%')  ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();




                string sqlEK = " select datediff(day,OutDate,getdate()) as 使用天数,ClientName, IP, CardType, Card, Outdate,State, MailAddress, MailAddressCC  from ClientInfo  "
                   + Condition.condition4
                   + " and State <> '关停' and State <> '忽略' and ClientName <> '闲置在库' and Property = '包年' and datediff(day,Outdate,getdate()) >= 365  ";
                sqlEK += "  order by 使用天数 DESC ";


                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string usedate = myReader["使用天数"].ToString();
                    string CardType = myReader["CardType"].ToString();
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    //string Traffictotal = myReader["Traffic"].ToString();
                    //string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    string sql = "";
                    string sql2 = "";
                    string StateOpen = "启用";
                    string StateClose = "关停";

                    string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
                    string Role;

                    //声明数据库
                    string strconn1 = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                    SqlConnection conn1 = new SqlConnection(strconn1);
                    if (State.Equals("启用") || State.Equals("忽略") && !CardType.Equals("4G卡"))
                    {

                        //string jsonText = "act=sms&mobile=&msg=短信平台测试短信";
                        string sURL = "http://169.2.3.8:80/card/search/" + source1;

                        WebRequest wrGETURL;
                        wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

                        string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
                        Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                        string reason = account.reason;                                         //取出返回值名称为reason的数值
                        string id = account.id;                                                 //取出返回值名称为id的数值
                        string status = account.status;
                        string msisdn = account.msisdn;
                        string imsi = account.imsi;

                        if (reason == "Success!" && status == "active")
                        {
                            if (msisdn != null)
                            {
                                string sURL2 = "http://169.2.3.8:80/card/status/" + msisdn + "/" + "inactive";

                                WebRequest wrGETURL2;
                                wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                                string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                                Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                                string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                                string id2 = account2.id;                                                 //取出返回值名称为id的数值
                                string status2 = account2.status;

                                if (reason2 == "Success!" && status2 == "inactive")
                                {

                                    //暂时更新此卡数据库状态信息为 开启/关停
                                    sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command = new SqlCommand(sql, conn1);
                                    int result = command.ExecuteNonQuery();
                                    conn1.Close();



                                    Role = "自动系统";
                                    //写入数据库日志
                                    sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1}'  ,'将卡号为: {2} 关停')", logtime, Role, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command2 = new SqlCommand(sql2, conn1);
                                    int result2 = command2.ExecuteNonQuery();
                                    conn1.Close();

                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
                                }
                                else
                                {
                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
                                }
                            }

                            else if (imsi != null)
                            {
                                string sURL2 = "http://169.2.3.8:80/card/status/" + imsi + "/" + "inactive";

                                WebRequest wrGETURL2;
                                wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                                string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                                Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                                string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                                string id2 = account2.id;                                                 //取出返回值名称为id的数值
                                string status2 = account2.status;

                                if (reason2 == "Success!" && status2 == "inactive")
                                {

                                    //暂时更新此卡数据库状态信息为 开启/关停
                                    sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command = new SqlCommand(sql, conn1);
                                    int result = command.ExecuteNonQuery();
                                    conn1.Close();



                                    Role = "自动系统";
                                    //写入数据库日志
                                    sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} ','将卡号为: {2} 关停')", logtime, Role, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command2 = new SqlCommand(sql2, conn1);
                                    int result2 = command2.ExecuteNonQuery();
                                    conn1.Close();

                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
                                }
                                else
                                {
                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
                                }
                            }

                        }
                    }
                    #region 状态为启用的4G卡执行
                    else if (State.Equals("启用") && CardType.Equals("4G卡"))
                    {


                        string sURL = "http://169.2.3.8:80/l2tp/search/" + source1;

                        WebRequest wrGETURL;
                        wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

                        string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
                        Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                        string reason = account.reason;
                        string status = account.status;

                        if (reason == "Success!" && status == "active")
                        {

                            string sURL2 = "http://169.2.3.8:80/l2tp/inactive/" + source1;

                            WebRequest wrGETURL2;
                            wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                            string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                            Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                            //string error2 = account2.error;                                           //取出返回值名称为id的数值
                            //string reason2 = account2.reason;

                            //if (reason2 == "Success!" && error2 == "False")
                            //{

                            //暂时更新此卡数据库状态信息为 开启/关停
                            sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                            //打开数据库连接
                            conn1.Open();

                            //创建command对象
                            SqlCommand command = new SqlCommand(sql, conn1);
                            int result = command.ExecuteNonQuery();
                            conn1.Close();



                            Role = "自动系统";
                            //写入数据库日志
                            sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} ','将卡号为: {2} 关停')", logtime, Role, card);                                //打开数据库连接
                            conn1.Open();

                            //创建command对象
                            SqlCommand command2 = new SqlCommand(sql2, conn1);
                            int result2 = command2.ExecuteNonQuery();
                            conn1.Close();

                            WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停4G卡成功 ");
                            //}
                            //else
                            //{
                            //WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停3G卡失败 ");
                            //}


                        }
                        //}
                    #endregion

                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }



        public void OnTimedEvent3(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 00;
            int ihour = 5;



            Condition.conditiontestOther = " where (IP like '169.%' ) ";


            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();




                string sqlEK = " select datediff(day,OutDate,getdate()) as 使用天数,ClientName, IP, Card, MailAddress, MailAddressCC, Outdate,State  from ClientInfo  "
                    + Condition.conditionOther
                    + " and State = '启用'  and ClientName <> '闲置在库' and Property = '包月' and datediff(day,Outdate,getdate()) = 61 and  ClientName  like '测试%'  ";
                sqlEK += "  order by 使用天数 DESC ";


                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string usedate = myReader["使用天数"].ToString();
                    string client = myReader["ClientName"].ToString();
                    //string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    //string Traffictotal = myReader["Traffic"].ToString();
                    //string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    //decimal dectraffictotal = decimal.Parse(Traffictotal);
                    //decimal dectrafficuse = decimal.Parse(Trafficuse);
                    //decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"3G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add(MailAddress);//收件人
                    mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.IsBodyHtml = true;
                    mmsg.Subject = client + "：截止" + time + "，卡号为 " + card + " 的公司卡已使用了" + usedate + "天！！ 现已被系统自动关停！！ ";
                    mmsg.Body = client + "：<br><br>截止" + time + "，卡号为 " + card + " 的公司卡已使用了 <b>" + usedate + "天</b>" + " ，现已被系统自动关停！！"
                              + "<br><br>";


                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "smtp.exmail.qq.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                    try
                    {
                        //SmtpMail.Send(mmsg);//发送邮件
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent4(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 04;
            int ihour = 5;



            Condition.conditiontestOther = " where (IP like '169.%' ) ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();




                string SqlClose = " select datediff(day,OutDate,getdate()) as 使用天数,CardType, ClientName, IP, Card, MailAddress, MailAddressCC, Outdate,State  from ClientInfo  "
                    + Condition.conditionOther
                    + " and State = '启用'  and ClientName <> '闲置在库' and Property = '包月' and datediff(day,Outdate,getdate()) = 61 and  ClientName  like '测试%'  ";
                SqlClose += "  order by 使用天数 DESC ";


                SqlCommand cmd = new SqlCommand(SqlClose, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string usedate = myReader["使用天数"].ToString();
                    string CardType = myReader["CardType"].ToString();
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    //string Traffictotal = myReader["Traffic"].ToString();
                    //string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    string sql = "";
                    string sql2 = "";
                    string StateOpen = "启用";
                    string StateClose = "关停";

                    string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
                    string Role;

                    //声明数据库
                    string strconn1 = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                    SqlConnection conn1 = new SqlConnection(strconn1);
                    if (State.Equals("启用") || State.Equals("忽略") && !CardType.Equals("4G卡"))
                    {

                        //string jsonText = "act=sms&mobile=&msg=短信平台测试短信";
                        string sURL = "http://169.2.3.8:80/card/search/" + source1;

                        WebRequest wrGETURL;
                        wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

                        string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
                        Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                        string reason = account.reason;                                         //取出返回值名称为reason的数值
                        string id = account.id;                                                 //取出返回值名称为id的数值
                        string status = account.status;
                        string msisdn = account.msisdn;
                        string imsi = account.imsi;

                        if (reason == "Success!" && status == "active")
                        {
                            if (msisdn != null)
                            {
                                string sURL2 = "http://169.2.3.8:80/card/status/" + msisdn + "/" + "inactive";

                                WebRequest wrGETURL2;
                                wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                                string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                                Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                                string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                                string id2 = account2.id;                                                 //取出返回值名称为id的数值
                                string status2 = account2.status;

                                if (reason2 == "Success!" && status2 == "inactive")
                                {

                                    //暂时更新此卡数据库状态信息为 开启/关停
                                    sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command = new SqlCommand(sql, conn1);
                                    int result = command.ExecuteNonQuery();
                                    conn1.Close();



                                    Role = "自动系统";
                                    //写入数据库日志
                                    sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1}'  ,'将卡号为: {2} 关停')", logtime, Role, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command2 = new SqlCommand(sql2, conn1);
                                    int result2 = command2.ExecuteNonQuery();
                                    conn1.Close();

                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
                                }
                                else
                                {
                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
                                }
                            }

                            else if (imsi != null)
                            {
                                string sURL2 = "http://169.2.3.8:80/card/status/" + imsi + "/" + "inactive";

                                WebRequest wrGETURL2;
                                wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                                string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                                Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                                string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                                string id2 = account2.id;                                                 //取出返回值名称为id的数值
                                string status2 = account2.status;

                                if (reason2 == "Success!" && status2 == "inactive")
                                {

                                    //暂时更新此卡数据库状态信息为 开启/关停
                                    sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command = new SqlCommand(sql, conn1);
                                    int result = command.ExecuteNonQuery();
                                    conn1.Close();



                                    Role = "自动系统";
                                    //写入数据库日志
                                    sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} ','将卡号为: {2} 关停')", logtime, Role, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command2 = new SqlCommand(sql2, conn1);
                                    int result2 = command2.ExecuteNonQuery();
                                    conn1.Close();

                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
                                }
                                else
                                {
                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
                                }
                            }

                        }
                    }
                    #region 状态为启用的4G卡执行
                    else if (State.Equals("启用") && CardType.Equals("4G卡"))
                    {


                        string sURL = "http://169.2.3.8:80/l2tp/search/" + source1;

                        WebRequest wrGETURL;
                        wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

                        string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
                        Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                        string reason = account.reason;
                        string status = account.status;

                        if (reason == "Success!" && status == "active")
                        {

                            string sURL2 = "http://169.2.3.8:80/l2tp/inactive/" + source1;

                            WebRequest wrGETURL2;
                            wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                            string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                            Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                            //string error2 = account2.error;                                           //取出返回值名称为id的数值
                            //string reason2 = account2.reason;

                            //if (reason2 == "Success!" && error2 == "False")
                            //{

                            //暂时更新此卡数据库状态信息为 开启/关停
                            sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                            //打开数据库连接
                            conn1.Open();

                            //创建command对象
                            SqlCommand command = new SqlCommand(sql, conn1);
                            int result = command.ExecuteNonQuery();
                            conn1.Close();



                            Role = "自动系统";
                            //写入数据库日志
                            sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} ','将卡号为: {2} 关停')", logtime, Role, card);                                //打开数据库连接
                            conn1.Open();

                            //创建command对象
                            SqlCommand command2 = new SqlCommand(sql2, conn1);
                            int result2 = command2.ExecuteNonQuery();
                            conn1.Close();

                            WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停4G卡成功 ");
                            //}
                            //else
                            //{
                            //WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停3G卡失败 ");
                            //}


                        }
                        //}
                    #endregion

                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent9(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 01;
            int ihour = 5;



            Condition.conditiontestOther = " where (IP like '169.%' ) ";


            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();




                string sqlEK = " select datediff(day,OutDate,getdate()) as 使用天数,ClientName, IP, Card, MailAddress, MailAddressCC, Outdate,State  from ClientInfo  "
                    + Condition.conditionOther
                    + " and State = '启用'  and ClientName <> '闲置在库' and Property = '包月' and datediff(day,Outdate,getdate()) = 31 and  ClientName  like '顶用%'  ";
                sqlEK += "  order by 使用天数 DESC ";


                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string usedate = myReader["使用天数"].ToString();
                    string client = myReader["ClientName"].ToString();
                    //string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    //string Traffictotal = myReader["Traffic"].ToString();
                    //string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    //decimal dectraffictotal = decimal.Parse(Traffictotal);
                    //decimal dectrafficuse = decimal.Parse(Trafficuse);
                    //decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"3G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add(MailAddress);//收件人
                    mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.IsBodyHtml = true;
                    mmsg.Subject = client + "：截止" + time + "，卡号为 " + card + " 的公司卡已使用了" + usedate + "天！！ 现已被系统自动关停！！ ";
                    mmsg.Body = client + "：<br><br>截止" + time + "，卡号为 " + card + " 的公司卡已使用了 <b>" + usedate + "天</b>" + " ，现已被系统自动关停！！"
                              + "<br><br>";


                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "smtp.exmail.qq.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                    try
                    {
                        //SmtpMail.Send(mmsg);//发送邮件
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent10(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 05;
            int ihour = 5;



            Condition.conditiontestOther = " where (IP like '169.%' ) ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();




                string SqlClose = " select datediff(day,OutDate,getdate()) as 使用天数,CardType, ClientName, IP, Card, MailAddress, MailAddressCC, Outdate,State  from ClientInfo  "
                    + Condition.conditionOther
                    + " and State = '启用'  and ClientName <> '闲置在库' and Property = '包月' and datediff(day,Outdate,getdate()) = 31 and  ClientName  like '顶用%'  ";
                SqlClose += "  order by 使用天数 DESC ";


                SqlCommand cmd = new SqlCommand(SqlClose, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string usedate = myReader["使用天数"].ToString();
                    string CardType = myReader["CardType"].ToString();
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    //string Traffictotal = myReader["Traffic"].ToString();
                    //string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    string sql = "";
                    string sql2 = "";
                    string StateOpen = "启用";
                    string StateClose = "关停";

                    string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
                    string Role;

                    //声明数据库
                    string strconn1 = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                    SqlConnection conn1 = new SqlConnection(strconn1);
                    if (State.Equals("启用") || State.Equals("忽略") && !CardType.Equals("4G卡"))
                    {

                        //string jsonText = "act=sms&mobile=&msg=短信平台测试短信";
                        string sURL = "http://169.2.3.8:80/card/search/" + source1;

                        WebRequest wrGETURL;
                        wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

                        string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
                        Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                        string reason = account.reason;                                         //取出返回值名称为reason的数值
                        string id = account.id;                                                 //取出返回值名称为id的数值
                        string status = account.status;
                        string msisdn = account.msisdn;
                        string imsi = account.imsi;

                        if (reason == "Success!" && status == "active")
                        {
                            if (msisdn != null)
                            {
                                string sURL2 = "http://169.2.3.8:80/card/status/" + msisdn + "/" + "inactive";

                                WebRequest wrGETURL2;
                                wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                                string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                                Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                                string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                                string id2 = account2.id;                                                 //取出返回值名称为id的数值
                                string status2 = account2.status;

                                if (reason2 == "Success!" && status2 == "inactive")
                                {

                                    //暂时更新此卡数据库状态信息为 开启/关停
                                    sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command = new SqlCommand(sql, conn1);
                                    int result = command.ExecuteNonQuery();
                                    conn1.Close();



                                    Role = "自动系统";
                                    //写入数据库日志
                                    sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1}'  ,'将卡号为: {2} 关停')", logtime, Role, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command2 = new SqlCommand(sql2, conn1);
                                    int result2 = command2.ExecuteNonQuery();
                                    conn1.Close();

                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
                                }
                                else
                                {
                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
                                }
                            }

                            else if (imsi != null)
                            {
                                string sURL2 = "http://169.2.3.8:80/card/status/" + imsi + "/" + "inactive";

                                WebRequest wrGETURL2;
                                wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                                string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                                Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                                string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                                string id2 = account2.id;                                                 //取出返回值名称为id的数值
                                string status2 = account2.status;

                                if (reason2 == "Success!" && status2 == "inactive")
                                {

                                    //暂时更新此卡数据库状态信息为 开启/关停
                                    sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command = new SqlCommand(sql, conn1);
                                    int result = command.ExecuteNonQuery();
                                    conn1.Close();



                                    Role = "自动系统";
                                    //写入数据库日志
                                    sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} ','将卡号为: {2} 关停')", logtime, Role, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command2 = new SqlCommand(sql2, conn1);
                                    int result2 = command2.ExecuteNonQuery();
                                    conn1.Close();

                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
                                }
                                else
                                {
                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
                                }
                            }

                        }
                    }
                    #region 状态为启用的4G卡执行
                    else if (State.Equals("启用") && CardType.Equals("4G卡"))
                    {


                        string sURL = "http://169.2.3.8:80/l2tp/search/" + source1;

                        WebRequest wrGETURL;
                        wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

                        string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
                        Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                        string reason = account.reason;
                        string status = account.status;

                        if (reason == "Success!" && status == "active")
                        {

                            string sURL2 = "http://169.2.3.8:80/l2tp/inactive/" + source1;

                            WebRequest wrGETURL2;
                            wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                            string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                            Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                            //string error2 = account2.error;                                           //取出返回值名称为id的数值
                            //string reason2 = account2.reason;

                            //if (reason2 == "Success!" && error2 == "False")
                            //{

                            //暂时更新此卡数据库状态信息为 开启/关停
                            sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                            //打开数据库连接
                            conn1.Open();

                            //创建command对象
                            SqlCommand command = new SqlCommand(sql, conn1);
                            int result = command.ExecuteNonQuery();
                            conn1.Close();



                            Role = "自动系统";
                            //写入数据库日志
                            sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} ','将卡号为: {2} 关停')", logtime, Role, card);                                //打开数据库连接
                            conn1.Open();

                            //创建command对象
                            SqlCommand command2 = new SqlCommand(sql2, conn1);
                            int result2 = command2.ExecuteNonQuery();
                            conn1.Close();

                            WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停4G卡成功 ");
                            //}
                            //else
                            //{
                            //WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停3G卡失败 ");
                            //}


                        }
                        //}
                    #endregion

                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent11(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 03;
            int ihour = 5;



            Condition.conditiontestOther = " where (IP like '169.%' ) ";


            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();




                string sqlEK = " select datediff(day,OutDate,getdate()) as 使用天数,ClientName, IP, Card, MailAddress, MailAddressCC, Outdate,State  from ClientInfo  "
                    + Condition.conditionOther
                    + " and State = '启用'  and ClientName <> '闲置在库' and Property = '包月' and datediff(day,Outdate,getdate()) = 16 and  ClientName  like '客服抢修卡%'  ";
                sqlEK += "  order by 使用天数 DESC ";


                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string usedate = myReader["使用天数"].ToString();
                    string client = myReader["ClientName"].ToString();
                    //string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    //string Traffictotal = myReader["Traffic"].ToString();
                    //string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    //decimal dectraffictotal = decimal.Parse(Traffictotal);
                    //decimal dectrafficuse = decimal.Parse(Trafficuse);
                    //decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"3G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add(MailAddress);//收件人
                    mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.IsBodyHtml = true;
                    mmsg.Subject = client + "：截止" + time + "，卡号为 " + card + " 的公司卡已使用了" + usedate + "天！！ 现已被系统自动关停！！ ";
                    mmsg.Body = client + "：<br><br>截止" + time + "，卡号为 " + card + " 的公司卡已使用了 <b>" + usedate + "天</b>" + " ，现已被系统自动关停！！"
                              + "<br><br>";


                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "smtp.exmail.qq.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                    try
                    {
                        //SmtpMail.Send(mmsg);//发送邮件
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent12(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 06;
            int ihour = 5;



            Condition.conditiontestOther = " where (IP like '169.%' ) ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();




                string SqlClose = " select datediff(day,OutDate,getdate()) as 使用天数,CardType, ClientName, IP, Card, MailAddress, MailAddressCC, Outdate,State  from ClientInfo  "
                    + Condition.conditionOther
                    + " and State = '启用'  and ClientName <> '闲置在库' and Property = '包月' and datediff(day,Outdate,getdate()) = 16 and  ClientName  like '%客服抢修卡%'  ";
                SqlClose += "  order by 使用天数 DESC ";


                SqlCommand cmd = new SqlCommand(SqlClose, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string usedate = myReader["使用天数"].ToString();
                    string CardType = myReader["CardType"].ToString();
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    //string Traffictotal = myReader["Traffic"].ToString();
                    //string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    string sql = "";
                    string sql2 = "";
                    string StateOpen = "启用";
                    string StateClose = "关停";

                    string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
                    string Role;

                    //声明数据库
                    string strconn1 = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                    SqlConnection conn1 = new SqlConnection(strconn1);
                    if (State.Equals("启用") || State.Equals("忽略") && !CardType.Equals("4G卡"))
                    {

                        //string jsonText = "act=sms&mobile=&msg=短信平台测试短信";
                        string sURL = "http://169.2.3.8:80/card/search/" + source1;

                        WebRequest wrGETURL;
                        wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

                        string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
                        Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                        string reason = account.reason;                                         //取出返回值名称为reason的数值
                        string id = account.id;                                                 //取出返回值名称为id的数值
                        string status = account.status;
                        string msisdn = account.msisdn;
                        string imsi = account.imsi;

                        if (reason == "Success!" && status == "active")
                        {
                            if (msisdn != null)
                            {
                                string sURL2 = "http://169.2.3.8:80/card/status/" + msisdn + "/" + "inactive";

                                WebRequest wrGETURL2;
                                wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                                string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                                Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                                string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                                string id2 = account2.id;                                                 //取出返回值名称为id的数值
                                string status2 = account2.status;

                                if (reason2 == "Success!" && status2 == "inactive")
                                {

                                    //暂时更新此卡数据库状态信息为 开启/关停
                                    sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command = new SqlCommand(sql, conn1);
                                    int result = command.ExecuteNonQuery();
                                    conn1.Close();



                                    Role = "自动系统";
                                    //写入数据库日志
                                    sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1}'  ,'将卡号为: {2} 关停')", logtime, Role, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command2 = new SqlCommand(sql2, conn1);
                                    int result2 = command2.ExecuteNonQuery();
                                    conn1.Close();

                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
                                }
                                else
                                {
                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
                                }
                            }

                            else if (imsi != null)
                            {
                                string sURL2 = "http://169.2.3.8:80/card/status/" + imsi + "/" + "inactive";

                                WebRequest wrGETURL2;
                                wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                                string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                                Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                                string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                                string id2 = account2.id;                                                 //取出返回值名称为id的数值
                                string status2 = account2.status;

                                if (reason2 == "Success!" && status2 == "inactive")
                                {

                                    //暂时更新此卡数据库状态信息为 开启/关停
                                    sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command = new SqlCommand(sql, conn1);
                                    int result = command.ExecuteNonQuery();
                                    conn1.Close();



                                    Role = "自动系统";
                                    //写入数据库日志
                                    sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} ','将卡号为: {2} 关停')", logtime, Role, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command2 = new SqlCommand(sql2, conn1);
                                    int result2 = command2.ExecuteNonQuery();
                                    conn1.Close();

                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
                                }
                                else
                                {
                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
                                }
                            }

                        }
                    }
                    #region 状态为启用的4G卡执行
                    else if (State.Equals("启用") && CardType.Equals("4G卡"))
                    {


                        string sURL = "http://169.2.3.8:80/l2tp/search/" + source1;

                        WebRequest wrGETURL;
                        wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

                        string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
                        Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                        string reason = account.reason;
                        string status = account.status;

                        if (reason == "Success!" && status == "active")
                        {

                            string sURL2 = "http://169.2.3.8:80/l2tp/inactive/" + source1;

                            WebRequest wrGETURL2;
                            wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                            string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                            Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                            //string error2 = account2.error;                                           //取出返回值名称为id的数值
                            //string reason2 = account2.reason;

                            //if (reason2 == "Success!" && error2 == "False")
                            //{

                            //暂时更新此卡数据库状态信息为 开启/关停
                            sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                            //打开数据库连接
                            conn1.Open();

                            //创建command对象
                            SqlCommand command = new SqlCommand(sql, conn1);
                            int result = command.ExecuteNonQuery();
                            conn1.Close();



                            Role = "自动系统";
                            //写入数据库日志
                            sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} ','将卡号为: {2} 关停')", logtime, Role, card);                                //打开数据库连接
                            conn1.Open();

                            //创建command对象
                            SqlCommand command2 = new SqlCommand(sql2, conn1);
                            int result2 = command2.ExecuteNonQuery();
                            conn1.Close();

                            WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停4G卡成功 ");
                            //}
                            //else
                            //{
                            //WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停3G卡失败 ");
                            //}


                        }
                        //}
                    #endregion

                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

    }
}
