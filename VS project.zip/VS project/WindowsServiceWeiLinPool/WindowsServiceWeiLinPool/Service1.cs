﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using Newtonsoft.Json;
using System.Net;
using System.Threading;
using System.Security.Cryptography;
using System.Net.Mail;

namespace WindowsServiceWeiLinPool
{
    public partial class Service1 : ServiceBase
    {
        //定时器  
        System.Timers.Timer t1 = null;
        System.Timers.Timer t2 = null;

        //定义全局变量类Condition，其中的condition
        class Condition
        {
            //用来把sql语句赋值给下面的全局变量

            public static string condition1 = "";
            public static string condition2 = "";
            public static int contrafficCTZJ = 0;
            public static int contrafficCTZJuse = 0;
            public static string account_error = "";
            public static List<Account> listData;
            public static string geturlvalue = "";
        }

        //定义json类
        public class Account
        {
            public string reason { get; set; }      //获取响应状态
            public string id { get; set; }          //获取ID号
            public string status { get; set; }      //获取卡状态
            public string imsi { get; set; }        //获取imsi号码
            public string msisdn { get; set; }      //获取msisdn号码

        }

        //定义返回URL值
        private string GetContentFromUrll(string _requestUrl)
        {
            string _StrResponse = "";
            HttpWebRequest _WebRequest = (HttpWebRequest)WebRequest.Create(_requestUrl);
            _WebRequest.Method = "GET";
            WebResponse _WebResponse = _WebRequest.GetResponse();
            StreamReader _ResponseStream = new StreamReader(_WebResponse.GetResponseStream(), System.Text.Encoding.GetEncoding("gb2312"));
            _StrResponse = _ResponseStream.ReadToEnd();
            _WebResponse.Close();
            _ResponseStream.Close();
            return _StrResponse;
        }

        public Service1()
        {
            InitializeComponent();
            //启用暂停恢复  
            base.CanPauseAndContinue = true;

            t1 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t1.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent1);
            t1.AutoReset = true;
            t1.Enabled = true;

            t2 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t2.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent2);
            t2.AutoReset = true;
            t2.Enabled = true;
        }

        protected override void OnStart(string[] args)
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "启动";
            WriteLog(state);
        }

        //停止服务执行  
        protected override void OnStop()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "停止";
            WriteLog(state);
        }

        //恢复服务执行  
        protected override void OnContinue()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "继续";
            WriteLog(state);
            t1.Start();
            t2.Start();
        }

        //暂停服务执行  
        protected override void OnPause()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "暂停";
            WriteLog(state);
            t1.Stop();
            t2.Stop();
        }

        public void WriteLog(string str)
        {
            using (StreamWriter sw = File.AppendText(@"d:\AutoCardWeiLinPool.txt"))
            {
                sw.WriteLine(str);
                sw.Flush();
            }
        }

        public void OnTimedEvent1(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 30;
            int ihour = 0;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd");
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd");
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd");
            #endregion

            Condition.condition1 = " where (Traffic.source like '169.1.31.%'  ) ";
            Condition.condition2 = " where (Traffic2.source like '169.1.31.%'  ) ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string SqlClose = " select ClientInfo.Card, Traffic2.source, State, sum(流量) as 流量 from ("
                        + " select source ,sum(traffic) as 流量  "
                        + " from Traffic2 "
                        + Condition.condition2
                        //+ " and (Traffic2.date >= '2016-8-1' and Traffic2.date <= '2016-8-31') group by source "
                        + " and (Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "')  "
                        + " group by source "
                        + " union "
                        + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                        + " from Traffic "
                        + Condition.condition1
                        //+ " and (Traffic.date >= '2016-8-1' and Traffic.date <= '2016-8-31') "
                        + " and (Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "') "
                        + " group by source "
                        + " )Traffic2 left join ClientInfo  ON source = IP  "
                        + " group by Traffic2.source,ClientInfo.Card,ClientInfo.ClientName,State "
                        + " having ClientInfo.ClientName  like '上海葳霖电子%'  "
                        + " order by 流量 DESC ";


                SqlCommand cmd = new SqlCommand(SqlClose, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    //string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    string sql = "";
                    string sql2 = "";
                    string StateOpen = "启用";
                    string StateClose = "关停";

                    string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
                    string Role;

                    //声明数据库
                    string strconn1 = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                    SqlConnection conn1 = new SqlConnection(strconn1);
                    if (State.Equals("启用"))
                    {

                        //string jsonText = "act=sms&mobile=&msg=短信平台测试短信";
                        string sURL = "http://169.2.3.8:80/card/search/" + source1;

                        WebRequest wrGETURL;
                        wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

                        string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
                        Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                        string reason = account.reason;                                         //取出返回值名称为reason的数值
                        string id = account.id;                                                 //取出返回值名称为id的数值
                        string status = account.status;
                        string msisdn = account.msisdn;
                        string imsi = account.imsi;

                        if (reason == "Success!" && status == "active")
                        {
                            if (msisdn != null)
                            {
                                string sURL2 = "http://169.2.3.8:80/card/status/" + msisdn + "/" + "inactive";

                                WebRequest wrGETURL2;
                                wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                                string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                                Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                                string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                                string id2 = account2.id;                                                 //取出返回值名称为id的数值
                                string status2 = account2.status;

                                if (reason2 == "Success!" && status2 == "inactive")
                                {

                                    //暂时更新此卡数据库状态信息为 开启/关停
                                    sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command = new SqlCommand(sql, conn1);
                                    int result = command.ExecuteNonQuery();
                                    conn1.Close();



                                    Role = "自动系统";
                                    //写入数据库日志
                                    sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1}'  ,'将卡号为: {2} 关停')", logtime, Role, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command2 = new SqlCommand(sql2, conn1);
                                    int result2 = command2.ExecuteNonQuery();
                                    conn1.Close();

                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
                                }
                                else
                                {
                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
                                }
                            }

                            else if (imsi != null)
                            {
                                string sURL2 = "http://169.2.3.8:80/card/status/" + imsi + "/" + "inactive";

                                WebRequest wrGETURL2;
                                wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                                string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                                Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                                string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                                string id2 = account2.id;                                                 //取出返回值名称为id的数值
                                string status2 = account2.status;

                                if (reason2 == "Success!" && status2 == "inactive")
                                {

                                    //暂时更新此卡数据库状态信息为 开启/关停
                                    sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command = new SqlCommand(sql, conn1);
                                    int result = command.ExecuteNonQuery();
                                    conn1.Close();



                                    Role = "自动系统";
                                    //写入数据库日志
                                    sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} ','将卡号为: {2} 关停')", logtime, Role, card);
                                    //打开数据库连接
                                    conn1.Open();

                                    //创建command对象
                                    SqlCommand command2 = new SqlCommand(sql2, conn1);
                                    int result2 = command2.ExecuteNonQuery();
                                    conn1.Close();

                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
                                }
                                else
                                {
                                    WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
                                }
                            }

                        }
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent2(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 26;
            int ihour = 0;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd");
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd");
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd");
            #endregion

            Condition.condition1 = " where (Traffic.source like '169.1.31.%'  ) ";
            Condition.condition2 = " where (Traffic2.source like '169.1.31.%'  ) ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string SqlClose = " select sum(流量) as 流量 from ("
                        + " select source ,sum(traffic) as 流量  "
                        + " from Traffic2 "
                        + Condition.condition2
                        //+ " and (Traffic2.date >= '2016-8-1' and Traffic2.date <= '2016-8-31') group by source "
                        + " and (Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "')  "
                        + " group by source "
                        + " union "
                        + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                        + " from Traffic "
                        + Condition.condition1
                        //+ " and (Traffic.date >= '2016-8-1' and Traffic.date <= '2016-8-31') "
                        + " and (Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "') "
                        + " group by source "
                        + " )Traffic2 left join ClientInfo  ON source = IP where ClientInfo.ClientName  like '上海葳霖电子%'  "
                        + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(SqlClose, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string strtraffic = myReader["流量"].ToString();
                    double doubletraffic = double.Parse(strtraffic);
                    int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型
                    Condition.contrafficCTZJuse = inttraffic;
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");


                    //16年5月24日第一批加了25张50M的   = 1250MB
                    float shenyutrafficCTZJ = (float)inttraffic / 1250;

                    /////////////////////////////////////////////////////////////
                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.High;//设置优先级别
                    mmsg.From = new MailAddress("\"3G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("service@fashion-tele.com,technology@fashion-tele.com");//收件人
                    mmsg.CC.Add("business@fashion-tele.com,gujp@fashion-tele.com");//抄送人
                    mmsg.IsBodyHtml = true;

                    if (shenyutrafficCTZJ >= 0.6 && shenyutrafficCTZJ < 0.8)
                    {
                        mmsg.Subject = "本月上海葳霖电子流量池已使用了60%！！！";
                        mmsg.Body = "<br><br>截止" + time + "，本月上海葳霖电子通流量池已使用了60%！！！"
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                    else if (shenyutrafficCTZJ >= 0.8 && shenyutrafficCTZJ < 1)
                    {
                        mmsg.Subject = "本月上海葳霖电子流量池已使用了80%！！！";
                        mmsg.Body = "注意<br><br>截止" + time + "，本月上海葳霖电子流量池已使用了80%！！！"
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                    else if (shenyutrafficCTZJ >= 1)
                    {
                        mmsg.Subject = "本月上海葳霖电子流量池已用尽！！！";
                        mmsg.Body = "各部门注意<br><br>截止" + time + "，本月上海葳霖电子流量池已用尽！！！所有卡号将立即被关停"
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }
    }
}
