﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using Newtonsoft.Json;
using System.Net;
using System.Threading;
using System.Security.Cryptography;
using System.Net.Mail;

namespace WindowsServiceCTG_armani
{
    public partial class Service1 : ServiceBase
    {
        //定时器  
        //System.Timers.Timer t1 = null;
        System.Timers.Timer t2 = null;
        System.Timers.Timer t3 = null;
        System.Timers.Timer t4 = null;
        System.Timers.Timer t5 = null;
        System.Timers.Timer t6 = null;
        System.Timers.Timer t7 = null;
        System.Timers.Timer t8 = null;
        System.Timers.Timer t9 = null;
        //System.Timers.Timer t10 = null;
        System.Timers.Timer t11 = null;
        System.Timers.Timer t12 = null;
        System.Timers.Timer t13 = null;
        System.Timers.Timer t14 = null;
        System.Timers.Timer t15 = null;
        System.Timers.Timer t16 = null;
        //System.Timers.Timer t17 = null;
        //System.Timers.Timer t18 = null;
        //System.Timers.Timer t19 = null;

        //定义全局变量类Condition，其中的condition
        class Condition
        {
            //用来把sql语句赋值给下面的全局变量

            public static string conditionOther = "";
            public static string condition2Other = "";
            public static string condition = "";

            public static string account_error = "";
            public static List<Account> listData;
            public static string geturlvalue = "";
        }

        //定义json类
        public class Account
        {
            public string reason { get; set; }      //获取响应状态
            public string id { get; set; }          //获取ID号
            public string status { get; set; }      //获取卡状态
            public string imsi { get; set; }        //获取imsi号码
            public string msisdn { get; set; }      //获取msisdn号码
            public string IP { get; set; }          //获取IP地址
            public string error { get; set; }

        }

        //定义返回URL值
        private string GetContentFromUrll(string _requestUrl)
        {
            string _StrResponse = "";
            HttpWebRequest _WebRequest = (HttpWebRequest)WebRequest.Create(_requestUrl);
            _WebRequest.Method = "GET";
            WebResponse _WebResponse = _WebRequest.GetResponse();
            StreamReader _ResponseStream = new StreamReader(_WebResponse.GetResponseStream(), System.Text.Encoding.GetEncoding("gb2312"));
            _StrResponse = _ResponseStream.ReadToEnd();
            _WebResponse.Close();
            _ResponseStream.Close();
            return _StrResponse;
        }

        public Service1()
        {
            InitializeComponent();
            base.CanPauseAndContinue = true;

            //t1 = new System.Timers.Timer(120000);  //间隔1分钟运行一次
            //t1.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent1);
            //t1.AutoReset = true;
            //t1.Enabled = true;

            t2 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t2.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent2);
            t2.AutoReset = true;
            t2.Enabled = true;

            t3 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t3.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent3);
            t3.AutoReset = true;
            t3.Enabled = true;

            t4 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t4.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent4);
            t4.AutoReset = true;
            t4.Enabled = true;

            t5 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t5.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent5);
            t5.AutoReset = true;
            t5.Enabled = true;

            t6 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t6.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent6);
            t6.AutoReset = true;
            t6.Enabled = true;

            t7 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t7.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent7);
            t7.AutoReset = true;
            t7.Enabled = true;

            t8 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t8.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent8);
            t8.AutoReset = true;
            t8.Enabled = true;

            t9 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t9.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent9);
            t9.AutoReset = true;
            t9.Enabled = true;

            //t10 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            //t10.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent10);
            //t10.AutoReset = true;
            //t10.Enabled = true;

            t11 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t11.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent11);
            t11.AutoReset = true;
            t11.Enabled = true;

            t12 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t12.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent12);
            t12.AutoReset = true;
            t12.Enabled = true;

            t13 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t13.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent13);
            t13.AutoReset = true;
            t13.Enabled = true;

            t14 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t14.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent14);
            t14.AutoReset = true;
            t14.Enabled = true;

            t15 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t15.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent15);
            t15.AutoReset = true;
            t15.Enabled = true;

            t16 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t16.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent16);
            t16.AutoReset = true;
            t16.Enabled = true;

            //t17 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            //t17.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent17);
            //t17.AutoReset = true;
            //t17.Enabled = true;

            //t18 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            //t18.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent18);
            //t18.AutoReset = true;
            //t18.Enabled = true;

            //t19 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            //t19.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent19);
            //t19.AutoReset = true;
            //t19.Enabled = true;
        }

        protected override void OnStart(string[] args)
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "启动";
            WriteLog(state);
        }

        protected override void OnStop()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "停止";
            WriteLog(state);
        }
        //恢复服务执行  
        protected override void OnContinue()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "继续";
            WriteLog(state);
            //t1.Start();
            t2.Start();
            t3.Start();
            t4.Start();
            t5.Start();
            t6.Start();
            t7.Start();
            t8.Start();
            t9.Start();
            //t10.Start();
            t11.Start();
            t12.Start();
            t13.Start();
            t13.Start();
            t14.Start();
            t15.Start();
            t16.Start();
            //t17.Start();
            //t18.Start();
            //t19.Start();
        }

        //暂停服务执行  
        protected override void OnPause()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "暂停";
            WriteLog(state);
            //t1.Stop();
            t2.Stop();
            t3.Stop();
            t4.Stop();
            t5.Stop();
            t6.Stop();
            t7.Stop();
            t8.Stop();
            t9.Stop();
            //t10.Stop();
            t11.Stop();
            t12.Stop();
            t13.Stop();
            t14.Stop();
            t15.Stop();
            t16.Stop();
            //t17.Stop();
            //t18.Stop();
            //t19.Stop();
        }

        public void WriteLog(string str)
        {
            using (StreamWriter sw = File.AppendText(@"d:\AutoMailCTG Armani.txt"))
            {
                sw.WriteLine(str);
                sw.Flush();
            }
        }

        public void OnTimedEvent1(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;


            //Condition.conditionOther = " where (Traffic.source like '169.7.8.%' or Traffic.source like '169.6.2.%'  ) ";
            //Condition.condition2Other = " where (Traffic2.source like '169.7.8.%' or Traffic2.source like '169.6.2.%'  ) ";


            //    //定义连接字符串
            //    string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            //    SqlConnection conn = new SqlConnection(strconn);
            //    conn.Open();

            //    string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
            //           + " select source ,sum(traffic) as 流量  "
            //           + " from Traffic2 "
            //           + Condition.condition2Other
            //           + " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";




            //    sqlEK += string.Format("  group by source ")
            //        + " union "
            //        + " select source ,sum(traffic) as 流量 "
            //        + " from Traffic "
            //        + Condition.conditionOther
            //        + " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";



            //    sqlEK += string.Format("  group by source ")
            //        + " )Traffic2 inner join ClientInfo  ON source = IP "
            //            + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
            //        + " >= ClientInfo.Traffic   and State <> '关停' and State <> '忽略' and ClientInfo.ClientName  like '%阿玛尼%'   ";
            //    sqlEK += " order by 流量 DESC ";

            //    SqlCommand cmd = new SqlCommand(sqlEK, conn);
            //    cmd.ExecuteNonQuery();
            //    SqlDataReader myReader = cmd.ExecuteReader();
            //    while (myReader.Read())
            //    {
            //        string client = myReader["ClientName"].ToString();
            //        string source1 = myReader["source"].ToString();
            //        string card = myReader["Card"].ToString();
            //        string Traffictotal = myReader["Traffic"].ToString();
            //        string Trafficuse = myReader["流量"].ToString();
            //        string MailAddress = myReader["MailAddress"].ToString();
            //        string MailAddressCC = myReader["MailAddressCC"].ToString();
            //        string State = myReader["State"].ToString();
            //        //定义告警日期
            //        string time = System.DateTime.Now.ToString("MM月dd日HH时");

            //        /////////////////把流量字符转换为数字型，进行计算////////////
            //        decimal dectraffictotal = decimal.Parse(Traffictotal);
            //        decimal dectrafficuse = decimal.Parse(Trafficuse);
            //        decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
            /////////////////////////////////////////////////////////////
            string time = System.DateTime.Now.ToString("MM月dd日HH时");
            string time1 = System.DateTime.Now.ToString("HH");
            string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
            string time3 = "By " + time1 + " o'clock on " + time2;

            MailMessage mmsg = new MailMessage();//实例一个mailmessage
            mmsg.Priority = MailPriority.Normal;//设置优先级别
            mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
            //mmsg.To.Add("cwt@fashion-tele.com,noc@fashion-tele.com");//收件人
            mmsg.Bcc.Add("noc@fashion-tele.com");//暗抄送人
            mmsg.IsBodyHtml = true;
            mmsg.Subject = "CTG邮箱测试:【CTG Reminder Letter】Your（3G/4G）traffic has been exceed 80%!!!";
            mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. xxxxxxx has <b>5120MB</b>  data access of the package this month" + " ， out of which you have already used <b>4200MB</b>" + "，exceeding <b>80%</b> of the total data of the package."
                              + "<br>"
                              + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
                              + "<br><br>"
                              + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
                              + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> xxxxxxx" 
                              + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
                              + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been exceed 80%!!!</font>"
                              + "<br><br>尊敬的用户：<br>截止" + time + "，您卡号为 xxxxxxxx 本月套餐流量为 <b>5120MB</b>" + " ，現已使用 <b>4200MB</b>" + "，已达到套餐流量的<b>80%</b>，請知晓！！"
                              + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
                              + "<br>中国电信集团系统集成有限责任公司"
                              + "<br>深圳国际系统集成分公司"
                              + "<br>3G/4G流量监控服务小组"
                              + "<br><br><br>";

            
            SmtpClient smtpclient = new SmtpClient();
            smtpclient.EnableSsl = false;
            smtpclient.Port = 25;
            smtpclient.Host = "mail.ctsig.com";
            smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
            try
            {
                //SmtpMail.Send(mmsg);//发送邮件
                smtpclient.Send(mmsg);

            }
            catch (Exception ex)
            {
                WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
            }
        }

        //myReader.Dispose();
        //myReader.Close();
        //conn.Close();



        public void OnTimedEvent2(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.conditionOther = " where (Traffic.source like '169.5.20.%'  ) ";
            Condition.condition2Other = " where (Traffic2.source like '169.5.20.%'  ) ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2Other
                    //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.conditionOther
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 0.5 and sum(流量) < ClientInfo.Traffic  and State <> '关停' and State <> '忽略' and ClientInfo.ClientName  like '%阿玛尼%'  ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;
                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
                    //mmsg.To.Add(MailAddress);//收件人
                    //mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been exceed 50%!!!";
                    mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，exceeding <b>50%</b> of the total data of the package."
                              + "<br>"
                              + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
                              + "<br><br>"
                              + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
                              + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
                              + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
                              + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been exceed 50%!!!</font>"
                              + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>50%</b>，請知晓！！"
                              + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
                              + "<br>中国电信集团系统集成有限责任公司"
                              + "<br>深圳国际系统集成分公司"
                              + "<br>3G/4G流量监控服务小组"
                              + "<br><br><br>";
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "monitor@fashion-tele.com");//发件人邮箱信息
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "Feixin123!");//密码
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent3(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.conditionOther = " where (Traffic.source like '169.5.20.%'  ) ";
            Condition.condition2Other = " where (Traffic2.source like '169.5.20.%'  ) ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2Other
                    //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.conditionOther
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 1 and sum(流量) < ClientInfo.Traffic * 1.5 and State <> '关停' and State <> '忽略' and ClientInfo.ClientName  like '%阿玛尼%'  ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
                    //mmsg.To.Add(MailAddress);//收件人
                    //mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been exceed 100%!!!";
                    mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，exceeding <b>100%</b> of the total data of the package."
                              + "<br>"
                              + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
                              + "<br><br>"
                              + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
                              + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
                              + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
                              + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been exceed 100%!!!</font>"
                              + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>100%</b>，請知晓！！"
                              + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
                              + "<br>中国电信集团系统集成有限责任公司"
                              + "<br>深圳国际系统集成分公司"
                              + "<br>3G/4G流量监控服务小组"
                              + "<br><br><br>";
                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent4(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.conditionOther = " where (Traffic.source like '169.5.20.%'  ) ";
            Condition.condition2Other = " where (Traffic2.source like '169.5.20.%'  ) ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2Other
                    //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.conditionOther
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 1.5 and sum(流量) < ClientInfo.Traffic * 2 and State <> '关停' and State <> '忽略' and ClientInfo.ClientName  like '%阿玛尼%'  ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
                    //mmsg.To.Add(MailAddress);//收件人
                    //mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人

                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been exceed 150%!!!";
                    mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，exceeding <b>150%</b> of the total data of the package."
                              + "<br>"
                              + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
                              + "<br><br>"
                              + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
                              + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
                              + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
                              + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been exceed 150%!!!</font>"
                              + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>150%</b>，請知晓！！"
                              + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
                              + "<br>中国电信集团系统集成有限责任公司"
                              + "<br>深圳国际系统集成分公司"
                              + "<br>3G/4G流量监控服务小组"
                              + "<br><br><br>";
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "monitor@fashion-tele.com");//发件人邮箱信息
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "Feixin123!");//密码
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent5(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.conditionOther = " where (Traffic.source like '169.5.20.%'  ) ";
            Condition.condition2Other = " where (Traffic2.source like '169.5.20.%'  ) ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2Other
                    //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.conditionOther
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 2 and sum(流量) < ClientInfo.Traffic * 2.5 and State <> '关停' and State <> '忽略' and ClientInfo.ClientName  like '%阿玛尼%'  ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
                    //mmsg.To.Add(MailAddress);//收件人
                    //mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人

                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been exceed 200%!!!";
                    mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，exceeding <b>200%</b> of the total data of the package."
                              + "<br>"
                              + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
                              + "<br><br>"
                              + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
                              + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
                              + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
                              + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been exceed 200%!!!</font>"
                              + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>200%</b>，請知晓！！"
                              + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
                              + "<br>中国电信集团系统集成有限责任公司"
                              + "<br>深圳国际系统集成分公司"
                              + "<br>3G/4G流量监控服务小组"
                              + "<br><br><br>";
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "monitor@fashion-tele.com");//发件人邮箱信息
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "Feixin123!");//密码
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent6(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.conditionOther = " where (Traffic.source like '169.5.20.%'  ) ";
            Condition.condition2Other = " where (Traffic2.source like '169.5.20.%'  ) ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2Other
                    //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.conditionOther
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 2.5 and sum(流量) < ClientInfo.Traffic * 3 and State <> '关停' and State <> '忽略' and ClientInfo.ClientName  like '%阿玛尼%'  ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;
                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
                    //mmsg.To.Add(MailAddress);//收件人
                    //mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been exceed 250%!!!";
                    mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，exceeding <b>250%</b> of the total data of the package."
                              + "<br>"
                              + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
                              + "<br><br>"
                              + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
                              + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
                              + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
                              + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been exceed 250%!!!</font>"
                              + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>250%</b>，請知晓！！"
                              + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
                              + "<br>中国电信集团系统集成有限责任公司"
                              + "<br>深圳国际系统集成分公司"
                              + "<br>3G/4G流量监控服务小组"
                              + "<br><br><br>";
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "monitor@fashion-tele.com");//发件人邮箱信息
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "Feixin123!");//密码
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent7(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.conditionOther = " where (Traffic.source like '169.5.20.%'  ) ";
            Condition.condition2Other = " where (Traffic2.source like '169.5.20.%'  ) ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2Other
                    //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.conditionOther
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 3 and sum(流量) < ClientInfo.Traffic * 3.5 and State <> '关停' and State <> '忽略' and ClientInfo.ClientName  like '%阿玛尼%'  ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
                    //mmsg.To.Add(MailAddress);//收件人
                    //mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been exceed 300%!!!";
                    mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，exceeding <b>300%</b> of the total data of the package."
                              + "<br>"
                              + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
                              + "<br><br>"
                              + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
                              + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
                              + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
                              + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been exceed 300%!!!</font>"
                              + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>300%</b>，請知晓！！"
                              + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
                              + "<br>中国电信集团系统集成有限责任公司"
                              + "<br>深圳国际系统集成分公司"
                              + "<br>3G/4G流量监控服务小组"
                              + "<br><br><br>";
                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent8(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.conditionOther = " where (Traffic.source like '169.5.20.%'  ) ";
            Condition.condition2Other = " where (Traffic2.source like '169.5.20.%'  ) ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2Other
                    //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.conditionOther
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 3.5 and sum(流量) < ClientInfo.Traffic * 4 and State <> '关停' and State <> '忽略' and ClientInfo.ClientName  like '%阿玛尼%'  ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
                    //mmsg.To.Add(MailAddress);//收件人
                    //mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人

                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been exceed 350%!!!";
                    mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，exceeding <b>350%</b> of the total data of the package."
                              + "<br>"
                              + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
                              + "<br><br>"
                              + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
                              + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
                              + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
                              + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been exceed 350%!!!</font>"
                              + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>350%</b>，請知晓！！"
                              + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
                              + "<br>中国电信集团系统集成有限责任公司"
                              + "<br>深圳国际系统集成分公司"
                              + "<br>3G/4G流量监控服务小组"
                              + "<br><br><br>";
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "monitor@fashion-tele.com");//发件人邮箱信息
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "Feixin123!");//密码
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent9(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.conditionOther = " where (Traffic.source like '169.5.20.%'  ) ";
            Condition.condition2Other = " where (Traffic2.source like '169.5.20.%'  ) ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2Other
                    //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.conditionOther
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 4  and State <> '关停' and State <> '忽略' and ClientInfo.ClientName  like '%阿玛尼%'  ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
                    //mmsg.To.Add(MailAddress);//收件人
                    //mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人

                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been  finished!!!";
                    mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，The data has been finished this month, your number will be stopped service by system automatically！！"
                              + "<br>"
                              + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
                              + "<br><br>"
                              + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
                              + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
                              + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
                              + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been finished!!!</font>"
                              + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，本月套餐流量已用尽，现已被系统自动关停！！"
                              + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
                              + "<br>中国电信集团系统集成有限责任公司"
                              + "<br>深圳国际系统集成分公司"
                              + "<br>3G/4G流量监控服务小组"
                              + "<br><br><br>";


                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }


        }

        //public void OnTimedEvent10(object source, System.Timers.ElapsedEventArgs e)
        //{
        //    int inthour = e.SignalTime.Hour;
        //    int intminute = e.SignalTime.Minute;
        //    int iminute = 12;

        //    #region     周期计算
        //    string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
        //    string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
        //    string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
        //    #endregion

        //    Condition.conditionOther = " where (Traffic.source like '169.5.20.%'  ) ";
        //    Condition.condition2Other = " where (Traffic2.source like '169.5.20.%'  ) ";

        //    if ( intminute == iminute)
        //    {
        //        //定义连接字符串
        //        string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
        //        SqlConnection conn = new SqlConnection(strconn);
        //        conn.Open();

        //        string SqlClose = " select  ClientInfo.CardType,ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, AutoClose, ClientInfo.Traffic, sum(流量) as 流量, MailAddress, MailAddressCC, State from ("
        //               + " select source ,sum(traffic) as 流量  "
        //               + " from Traffic2 "
        //               + Condition.condition2Other
        //            //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
        //        + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



        //        SqlClose += string.Format("  group by source ")
        //            + " union "
        //            + " select source ,sum(traffic) as 流量 "
        //            + " from Traffic "
        //            + Condition.conditionOther
        //            //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
        //        + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";



        //        SqlClose += string.Format("  group by source ")
        //            + " )Traffic2 inner join ClientInfo  ON source = IP "
        //                + " group by ClientInfo.CardType, ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, Property, AutoClose  having sum(流量) "
        //            + " >= ClientInfo.Traffic * 4  and State <> '关停' and State <> '忽略' and Property = '包月' and AutoClose = '是'  ";
        //        SqlClose += " order by 流量 DESC ";

        //        SqlCommand cmd = new SqlCommand(SqlClose, conn);
        //        cmd.ExecuteNonQuery();
        //        SqlDataReader myReader = cmd.ExecuteReader();
        //        while (myReader.Read())
        //        {
        //            string CardType = myReader["CardType"].ToString();
        //            string client = myReader["ClientName"].ToString();
        //            string source1 = myReader["source"].ToString();
        //            string card = myReader["Card"].ToString();
        //            string Traffictotal = myReader["Traffic"].ToString();
        //            string Trafficuse = myReader["流量"].ToString();
        //            string MailAddress = myReader["MailAddress"].ToString();
        //            string MailAddressCC = myReader["MailAddressCC"].ToString();
        //            string State = myReader["State"].ToString();
        //            //定义告警日期
        //            string time = System.DateTime.Now.ToString("MM月dd日HH时");

        //            string sql = "";
        //            string sql2 = "";
        //            string StateOpen = "启用";
        //            string StateClose = "关停";

        //            string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        //            string Role;

        //            //声明数据库
        //            string strconn1 = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
        //            SqlConnection conn1 = new SqlConnection(strconn1);
        //            if (State.Equals("启用") && !CardType.Equals("4G卡"))
        //            {

        //                //string jsonText = "act=sms&mobile=&msg=短信平台测试短信";
        //                string sURL = "http://169.2.3.8:80/card/search/" + source1;

        //                WebRequest wrGETURL;
        //                wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

        //                string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
        //                Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
        //                string reason = account.reason;                                         //取出返回值名称为reason的数值
        //                string id = account.id;                                                 //取出返回值名称为id的数值
        //                string status = account.status;
        //                string msisdn = account.msisdn;
        //                string imsi = account.imsi;

        //                if (reason == "Success!" && status == "active")
        //                {
        //                    if (msisdn != null)
        //                    {
        //                        string sURL2 = "http://169.2.3.8:80/card/status/" + msisdn + "/" + "inactive";

        //                        WebRequest wrGETURL2;
        //                        wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

        //                        string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
        //                        Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
        //                        string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
        //                        string id2 = account2.id;                                                 //取出返回值名称为id的数值
        //                        string status2 = account2.status;

        //                        if (reason2 == "Success!" && status2 == "inactive")
        //                        {

        //                            //暂时更新此卡数据库状态信息为 开启/关停
        //                            sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
        //                            //打开数据库连接
        //                            conn1.Open();

        //                            //创建command对象
        //                            SqlCommand command = new SqlCommand(sql, conn1);
        //                            int result = command.ExecuteNonQuery();
        //                            conn1.Close();



        //                            Role = "自动系统";
        //                            //写入数据库日志
        //                            sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1}'  ,'将卡号为: {2} 关停')", logtime, Role, card);
        //                            //打开数据库连接
        //                            conn1.Open();

        //                            //创建command对象
        //                            SqlCommand command2 = new SqlCommand(sql2, conn1);
        //                            int result2 = command2.ExecuteNonQuery();
        //                            conn1.Close();

        //                            WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
        //                        }
        //                        else
        //                        {
        //                            WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
        //                        }
        //                    }

        //                    else if (imsi != null)
        //                    {
        //                        string sURL2 = "http://169.2.3.8:80/card/status/" + imsi + "/" + "inactive";

        //                        WebRequest wrGETURL2;
        //                        wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

        //                        string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
        //                        Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
        //                        string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
        //                        string id2 = account2.id;                                                 //取出返回值名称为id的数值
        //                        string status2 = account2.status;

        //                        if (reason2 == "Success!" && status2 == "inactive")
        //                        {

        //                            //暂时更新此卡数据库状态信息为 开启/关停
        //                            sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
        //                            //打开数据库连接
        //                            conn1.Open();

        //                            //创建command对象
        //                            SqlCommand command = new SqlCommand(sql, conn1);
        //                            int result = command.ExecuteNonQuery();
        //                            conn1.Close();



        //                            Role = "自动系统";
        //                            //写入数据库日志
        //                            sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} ','将卡号为: {2} 关停')", logtime, Role, card);
        //                            //打开数据库连接
        //                            conn1.Open();

        //                            //创建command对象
        //                            SqlCommand command2 = new SqlCommand(sql2, conn1);
        //                            int result2 = command2.ExecuteNonQuery();
        //                            conn1.Close();

        //                            WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡成功 ");
        //                        }
        //                        else
        //                        {
        //                            WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停卡失败 ");
        //                        }
        //                    }

        //                }
        //            }

                    
        //        }
        //        myReader.Dispose();
        //        myReader.Close();
        //        conn.Close();
        //    }
        //}

        public void OnTimedEvent11(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 10;
            int ihour = 12;


            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
            #endregion

            Condition.condition = " and  ( IP like '169.5.20.%'  )  ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  ClientName, IP, Card, CardType, Traffic, MailAddress, MailAddressCC,State, sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State  "
                         + " having sum(total) >= Traffic  and sum(total) < Traffic * 2  and ClientName not like '%闲置%'  and IP is not Null and State <> '关停' and State <> '忽略' and ClientName  like '%阿玛尼%'  "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;
                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
                    //mmsg.To.Add(MailAddress);//收件人
                    //mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been exceed 100%!!!";
                    mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，exceeding <b>100%</b> of the total data of the package."
                              + "<br>"
                              + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
                              + "<br><br>"
                              + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
                              + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
                              + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
                              + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been exceed 100%!!!</font>"
                              + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>100%</b>，請知晓！！"
                              + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
                              + "<br>中国电信集团系统集成有限责任公司"
                              + "<br>深圳国际系统集成分公司"
                              + "<br>3G/4G流量监控服务小组"
                              + "<br><br><br>";
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "monitor@fashion-tele.com");//发件人邮箱信息
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "Feixin123!");//密码
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent12(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 10;
            int ihour = 12;


            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
            #endregion

            Condition.condition = " and  ( IP like '169.5.20.%'  )  ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  ClientName, IP, Card, CardType, Traffic, MailAddress, MailAddressCC,State, sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State  "
                         + " having sum(total) >= Traffic * 2 and sum(total) < Traffic * 3  and ClientName not like '%闲置%'  and IP is not Null and State <> '关停' and State <> '忽略' and ClientName  like '%阿玛尼%'  "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
                    //mmsg.To.Add(MailAddress);//收件人
                    //mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been exceed 200%!!!";
                    mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，exceeding <b>200%</b> of the total data of the package."
                              + "<br>"
                              + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
                              + "<br><br>"
                              + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
                              + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
                              + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
                              + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been exceed 200%!!!</font>"
                              + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>200%</b>，請知晓！！"
                              + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
                              + "<br>中国电信集团系统集成有限责任公司"
                              + "<br>深圳国际系统集成分公司"
                              + "<br>3G/4G流量监控服务小组"
                              + "<br><br><br>";
                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent13(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 10;
            int ihour = 12;


            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
            #endregion

            Condition.condition = " and  ( IP like '169.5.20.%'  )  ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  ClientName, IP, Card, CardType, Traffic, MailAddress, MailAddressCC,State, sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State  "
                         + " having sum(total) >= Traffic * 3 and sum(total) < Traffic * 4  and ClientName not like '%闲置%'  and IP is not Null and State <> '关停' and State <> '忽略' and ClientName  like '%阿玛尼%'  "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
                    //mmsg.To.Add(MailAddress);//收件人
                    //mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人

                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been exceed 300%!!!";
                    mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，exceeding <b>300%</b> of the total data of the package."
                              + "<br>"
                              + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
                              + "<br><br>"
                              + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
                              + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
                              + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
                              + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been exceed 300%!!!</font>"
                              + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>300%</b>，請知晓！！"
                              + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
                              + "<br>中国电信集团系统集成有限责任公司"
                              + "<br>深圳国际系统集成分公司"
                              + "<br>3G/4G流量监控服务小组"
                              + "<br><br><br>";
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "monitor@fashion-tele.com");//发件人邮箱信息
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "Feixin123!");//密码
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent14(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 10;
            int ihour = 12;


            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
            #endregion

            Condition.condition = " and  ( IP like '169.5.20.%'  )  ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  ClientName, IP, Card, CardType, Traffic, MailAddress, MailAddressCC,State, sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State  "
                         + " having sum(total) >= Traffic * 4 and sum(total) < Traffic * 5   and ClientName not like '%闲置%'  and IP is not Null and State <> '关停' and State <> '忽略' and ClientName  like '%阿玛尼%'  "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;
                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
                    //mmsg.To.Add(MailAddress);//收件人
                    //mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been exceed 400%!!!";
                    mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，exceeding <b>400%</b> of the total data of the package."
                              + "<br>"
                              + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
                              + "<br><br>"
                              + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
                              + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
                              + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
                              + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been exceed 400%!!!</font>"
                              + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>400%</b>，請知晓！！"
                              + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
                              + "<br>中国电信集团系统集成有限责任公司"
                              + "<br>深圳国际系统集成分公司"
                              + "<br>3G/4G流量监控服务小组"
                              + "<br><br><br>";
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "monitor@fashion-tele.com");//发件人邮箱信息
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "Feixin123!");//密码
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent15(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 10;
            int ihour = 12;


            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
            #endregion

            Condition.condition = " and  ( IP like '169.5.20.%'  )  ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  ClientName, IP, Card, CardType, Traffic, MailAddress, MailAddressCC,State, sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State  "
                         + " having sum(total) >= Traffic * 5 and sum(total) < Traffic * 6  and ClientName not like '%闲置%'  and IP is not Null and State <> '关停' and State <> '忽略' and ClientName  like '%阿玛尼%'  "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;
                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
                    //mmsg.To.Add(MailAddress);//收件人
                    //mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been exceed 500%!!!";
                    mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，exceeding <b>500%</b> of the total data of the package."
                              + "<br>"
                              + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
                              + "<br><br>"
                              + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
                              + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
                              + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
                              + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been exceed 500%!!!</font>"
                              + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>500%</b>，請知晓！！"
                              + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
                              + "<br>中国电信集团系统集成有限责任公司"
                              + "<br>深圳国际系统集成分公司"
                              + "<br>3G/4G流量监控服务小组"
                              + "<br><br><br>";
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "monitor@fashion-tele.com");//发件人邮箱信息
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "Feixin123!");//密码
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent16(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 10;
            int ihour = 12;


            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
            #endregion

            Condition.condition = " and  ( IP like '169.5.20.%'  )  ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  ClientName, IP, Card, CardType, Traffic, MailAddress, MailAddressCC,State, sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State  "
                         + " having sum(total) >= Traffic * 6   and ClientName not like '%闲置%'  and IP is not Null and State <> '关停' and State <> '忽略' and ClientName  like '%阿玛尼%'  "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
                    //mmsg.To.Add(MailAddress);//收件人
                    //mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been  finished!!!";
                    mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，The data has been finished this month, your number will be stopped service by system automatically！！"
                              + "<br>"
                              + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
                              + "<br><br>"
                              + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
                              + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
                              + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
                              + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been finished!!!</font>"
                              + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，本月套餐流量已用尽，现已被系统自动关停！！"
                              + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
                              + "<br>中国电信集团系统集成有限责任公司"
                              + "<br>深圳国际系统集成分公司"
                              + "<br>3G/4G流量监控服务小组"
                              + "<br><br><br>";
                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        //public void OnTimedEvent17(object source, System.Timers.ElapsedEventArgs e)
        //{

        //    int inthour = e.SignalTime.Hour;
        //    int intminute = e.SignalTime.Minute;
        //    int iminute = 10;
        //    int ihour = 12;


        //    #region     周期计算
        //    string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
        //    string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
        //    string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
        //    #endregion

        //    Condition.condition = " and  ( IP like '169.5.20.%'  )  ";

        //    if (inthour == ihour && intminute == iminute)
        //    {
        //        //定义连接字符串
        //        string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
        //        SqlConnection conn = new SqlConnection(strconn);
        //        conn.Open();

        //        string sqlEK = " select  ClientName, IP, Card, CardType, Traffic, MailAddress, MailAddressCC,State, sum(total) as 流量 from TrafficL2 "
        //               + " inner join ClientInfo  ON L2user = TrafficL2.users  "
        //               + Condition.condition
        //               + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



        //        sqlEK += " group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State  "
        //                 + " having sum(total) >= Traffic * 3.5 and sum(total) < Traffic * 4  and ClientName not like '%闲置%'  and IP is not Null and State <> '关停' and State <> '忽略' and ClientName  like '%阿玛尼%'  "
        //                 + " order by 流量 DESC ";

        //        SqlCommand cmd = new SqlCommand(sqlEK, conn);
        //        cmd.ExecuteNonQuery();
        //        SqlDataReader myReader = cmd.ExecuteReader();
        //        while (myReader.Read())
        //        {
        //            string client = myReader["ClientName"].ToString();
        //            string source1 = myReader["IP"].ToString();
        //            string card = myReader["Card"].ToString();
        //            string Traffictotal = myReader["Traffic"].ToString();
        //            string Trafficuse = myReader["流量"].ToString();
        //            string MailAddress = myReader["MailAddress"].ToString();
        //            string MailAddressCC = myReader["MailAddressCC"].ToString();
        //            string State = myReader["State"].ToString();
        //            //定义告警日期
        //            string time = System.DateTime.Now.ToString("MM月dd日HH时");
        //            string time1 = System.DateTime.Now.ToString("HH");
        //            string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
        //            string time3 = "By " + time1 + " o'clock on " + time2;

        //            /////////////////把流量字符转换为数字型，进行计算////////////
        //            decimal dectraffictotal = decimal.Parse(Traffictotal);
        //            decimal dectrafficuse = decimal.Parse(Trafficuse);
        //            decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
        //            /////////////////////////////////////////////////////////////

        //            MailMessage mmsg = new MailMessage();//实例一个mailmessage
        //            mmsg.Priority = MailPriority.Normal;//设置优先级别
        //            mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
        //            //mmsg.To.Add(MailAddress);//收件人
        //            //mmsg.CC.Add(MailAddressCC);//抄送人
        //            mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人

        //            mmsg.IsBodyHtml = true;

        //            mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been exceed 350%!!!";
        //            mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，exceeding <b>350%</b> of the total data of the package."
        //                      + "<br>"
        //                      + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
        //                      + "<br><br>"
        //                      + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
        //                      + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
        //                      + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
        //                      + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been exceed 350%!!!</font>"
        //                      + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>350%</b>，請知晓！！"
        //                      + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
        //                      + "<br>中国电信集团系统集成有限责任公司"
        //                      + "<br>深圳国际系统集成分公司"
        //                      + "<br>3G/4G流量监控服务小组"
        //                      + "<br><br><br>";
        //            //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
        //            //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "monitor@fashion-tele.com");//发件人邮箱信息
        //            //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "Feixin123!");//密码
        //            //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器
        //            //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器

        //            SmtpClient smtpclient = new SmtpClient();
        //            smtpclient.Host = "mail.ctsig.com";
        //            smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
        //            smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
        //            try
        //            {
        //                smtpclient.Send(mmsg);

        //            }
        //            catch (Exception ex)
        //            {
        //                WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
        //            }
        //        }
        //        myReader.Dispose();
        //        myReader.Close();
        //        conn.Close();
        //    }
        //}

        //public void OnTimedEvent18(object source, System.Timers.ElapsedEventArgs e)
        //{

        //    int inthour = e.SignalTime.Hour;
        //    int intminute = e.SignalTime.Minute;
        //    int iminute = 10;


        //    #region     周期计算
        //    string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
        //    string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
        //    string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
        //    #endregion

        //    Condition.condition = " and  ( IP like '169.5.20.%'  )  ";

        //    if (intminute == iminute)
        //    {
        //        //定义连接字符串
        //        string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
        //        SqlConnection conn = new SqlConnection(strconn);
        //        conn.Open();

        //        string sqlEK = " select  ClientName, IP, Card, CardType, Traffic, MailAddress, MailAddressCC,State, sum(total) as 流量 from TrafficL2 "
        //               + " inner join ClientInfo  ON L2user = TrafficL2.users  "
        //               + Condition.condition
        //               + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



        //        sqlEK += " group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State  "
        //                 + " having sum(total) >= Traffic * 4  and ClientName not like '%闲置%'  and IP is not Null and State <> '关停' and State <> '忽略' and ClientName  like '%阿玛尼%'  "
        //                 + " order by 流量 DESC ";

        //        SqlCommand cmd = new SqlCommand(sqlEK, conn);
        //        cmd.ExecuteNonQuery();
        //        SqlDataReader myReader = cmd.ExecuteReader();
        //        while (myReader.Read())
        //        {
        //            string client = myReader["ClientName"].ToString();
        //            string source1 = myReader["IP"].ToString();
        //            string card = myReader["Card"].ToString();
        //            string Traffictotal = myReader["Traffic"].ToString();
        //            string Trafficuse = myReader["流量"].ToString();
        //            string MailAddress = myReader["MailAddress"].ToString();
        //            string MailAddressCC = myReader["MailAddressCC"].ToString();
        //            string State = myReader["State"].ToString();
        //            //定义告警日期
        //            string time = System.DateTime.Now.ToString("MM月dd日HH时");
        //            string time1 = System.DateTime.Now.ToString("HH");
        //            string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
        //            string time3 = "By " + time1 + " o'clock on " + time2;

        //            /////////////////把流量字符转换为数字型，进行计算////////////
        //            decimal dectraffictotal = decimal.Parse(Traffictotal);
        //            decimal dectrafficuse = decimal.Parse(Trafficuse);
        //            decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
        //            /////////////////////////////////////////////////////////////

        //            MailMessage mmsg = new MailMessage();//实例一个mailmessage
        //            mmsg.Priority = MailPriority.Normal;//设置优先级别
        //            mmsg.From = new MailAddress("\"CTG-流量监控服务小组\" <notification@ctsig.com>");//发件人
        //            //mmsg.To.Add(MailAddress);//收件人
        //            //mmsg.CC.Add(MailAddressCC);//抄送人
        //            mmsg.Bcc.Add(MailAddressCC + ",noc@fashion-tele.com");//暗抄送人

        //            mmsg.IsBodyHtml = true;

        //            mmsg.Subject = "【CTG Reminder Letter】" + "Your（3G/4G）traffic has been  finished!!!";
        //            mmsg.Body = "Dear Customers, <br><br>This notice alerts you that " + time3 + "，your 3G/4G Card No. " + card + " has <b>" + Traffictotal + "MB</b>  data access of the package this month" + " ， out of which you have already used <b>" + Trafficuse + "MB</b>" + "，The data has been finished this month, your number will be stopped service by system automatically！！"
        //                      + "<br>"
        //                      + "Please kindly note that if you exceed 30 gigabytes, your 3G/4G internet service will automatically shut down!"
        //                      + "<br><br>"
        //                      + "<b>Customer Name：</b>【Giorgio Armani Hong Kong Limited】"
        //                      + "<br><b>Product Type：</b>【Maintenance Service】" + "<br><b>Service：</b>【Monitoring of 3G/4G traffic】" + "<br><b>3G/4G Card No.:</b> " + card
        //                      + "<br><b>Package：</b>【5G/month data plan initially and with upper bound at 30G / month】"
        //                      + "<br><b>Stage:</b><font color=\"red\"> Your（3G/4G）traffic has been finished!!!</font>"
        //                      + "<br><br>尊敬的" + client + "：<br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，現已使用 <b>" + Trafficuse + "MB</b>" + "，本月套餐流量已用尽，现已被系统自动关停！！"
        //                      + "<br>煩請注意：如果您的流量卡超過30G，系統將自動關閉您的網絡服務，敬請知悉。"
        //                      + "<br>中国电信集团系统集成有限责任公司"
        //                      + "<br>深圳国际系统集成分公司"
        //                      + "<br>3G/4G流量监控服务小组"
        //                      + "<br><br><br>";


        //            SmtpClient smtpclient = new SmtpClient();
        //            smtpclient.Host = "mail.ctsig.com";
        //            smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
        //            smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
        //            try
        //            {
        //                smtpclient.Send(mmsg);

        //            }
        //            catch (Exception ex)
        //            {
        //                WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
        //            }
        //        }
        //        myReader.Dispose();
        //        myReader.Close();
        //        conn.Close();
        //    }


        //}

        //public void OnTimedEvent19(object source, System.Timers.ElapsedEventArgs e)
        //{
        //    int inthour = e.SignalTime.Hour;
        //    int intminute = e.SignalTime.Minute;
        //    int iminute = 12;

        //    #region     周期计算
        //    string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
        //    string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
        //    string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
        //    #endregion

        //    Condition.condition = " and IP like '169.5.20.%'  ";

        //    if (intminute == iminute)
        //    {
        //        //定义连接字符串
        //        string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
        //        SqlConnection conn = new SqlConnection(strconn);
        //        conn.Open();

        //        string SqlClose = " select  ClientName, IP, Card,  AutoClose, CardType, Traffic, MailAddress, MailAddressCC,State, sum(total) as 流量 from TrafficL2 "
        //               + " inner join ClientInfo  ON L2user = TrafficL2.users  "
        //               + Condition.condition
        //               + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



        //        SqlClose += " group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State, Property, AutoClose  "
        //                 + " having sum(total) >= Traffic * 4  and ClientName not like '%闲置%'  and IP is not Null and State <> '关停' and State <> '忽略' and Property = '包月' and AutoClose = '是'   "
        //                 + " order by 流量 DESC ";

        //        SqlCommand cmd = new SqlCommand(SqlClose, conn);
        //        cmd.ExecuteNonQuery();
        //        SqlDataReader myReader = cmd.ExecuteReader();
        //        while (myReader.Read())
        //        {
        //            string CardType = myReader["CardType"].ToString();
        //            string client = myReader["ClientName"].ToString();
        //            string source1 = myReader["IP"].ToString();
        //            string card = myReader["Card"].ToString();
        //            string Traffictotal = myReader["Traffic"].ToString();
        //            string Trafficuse = myReader["流量"].ToString();
        //            string MailAddress = myReader["MailAddress"].ToString();
        //            string MailAddressCC = myReader["MailAddressCC"].ToString();
        //            string State = myReader["State"].ToString();
        //            //定义告警日期
        //            string time = System.DateTime.Now.ToString("MM月dd日HH时");

        //            string sql = "";
        //            string sql2 = "";
        //            string StateOpen = "启用";
        //            string StateClose = "关停";

        //            string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        //            string Role;

        //            //声明数据库
        //            string strconn1 = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
        //            SqlConnection conn1 = new SqlConnection(strconn1);



        //            #region 状态为启用的4G卡执行
        //            //if (State.Equals("启用") && CardType.Equals("4G卡"))
        //            //{


        //            string sURL = "http://169.2.3.8:80/l2tp/search/" + source1;

        //            WebRequest wrGETURL;
        //            wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

        //            string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
        //            Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
        //            string reason = account.reason;
        //            string status = account.status;

        //            if (reason == "Success!" && status == "active")
        //            {

        //                string sURL2 = "http://169.2.3.8:80/l2tp/inactive/" + source1;

        //                WebRequest wrGETURL2;
        //                wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

        //                string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
        //                Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
        //                string error2 = account2.error;                                           //取出返回值名称为id的数值
        //                string reason2 = account2.reason;

        //                //if (reason2 == "Success!" && error2 == "False")
        //                //{

        //                //暂时更新此卡数据库状态信息为 开启/关停
        //                sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, source1, card);
        //                //打开数据库连接
        //                conn1.Open();

        //                //创建command对象
        //                SqlCommand command = new SqlCommand(sql, conn1);
        //                int result = command.ExecuteNonQuery();
        //                conn1.Close();



        //                Role = "自动系统";
        //                //写入数据库日志
        //                sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} ','将卡号为: {2} 关停')", logtime, Role, card);                                //打开数据库连接
        //                conn1.Open();

        //                //创建command对象
        //                SqlCommand command2 = new SqlCommand(sql2, conn1);
        //                int result2 = command2.ExecuteNonQuery();
        //                conn1.Close();

        //                WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停4G卡成功 ");
        //                //}
        //                //else
        //                //{
        //                //WriteLog("提示:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + card + " 自动关停3G卡失败 ");
        //                //}


        //            }
        //            //}
        //            #endregion
        //        }

        //        myReader.Dispose();
        //        myReader.Close();
        //        conn.Close();
        //    }
        //}
    }
}
