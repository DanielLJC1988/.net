﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using Newtonsoft.Json;
using System.Net;
using System.Threading;
using System.Security.Cryptography;

namespace WindowsServiceAuto1
{
    public partial class Service1 : ServiceBase
    {
        //定时器  
        System.Timers.Timer t = null;

        //定义全局变量类Condition，其中的condition
        class Condition
        {
            //用全局变量
            public static string account_error = "";
            public static List<Account> listData;
            public static string geturlvalue = "";
        }

        //定义json类
        public class Account
        {
            public string error { get; set; }       //获取是否错误
            public string reason { get; set; }      //获取错误原因
            public List<Account> data { get; set; } //获取data下的JSON类型数据
            public string src { get; set; }         //获取源地址
            public string dst { get; set; }         //获取目的地址
            public string octets { get; set; }      //获取流量


        }

        //定义返回URL值
        private static string GetContentFromUrll(string _requestUrl)
        {
            string _StrResponse = "";
            HttpWebRequest _WebRequest = (HttpWebRequest)WebRequest.Create(_requestUrl);
            _WebRequest.Method = "GET";
            WebResponse _WebResponse = _WebRequest.GetResponse();
            StreamReader _ResponseStream = new StreamReader(_WebResponse.GetResponseStream(), System.Text.Encoding.GetEncoding("UTF-8"));  //gb2312
            _StrResponse = _ResponseStream.ReadToEnd();
            _WebResponse.Close();
            _ResponseStream.Close();
            return _StrResponse;
        }

        //定义URL编码
        public static string UrlEncode(string str)
        {
            //StringBuilder sb = new StringBuilder();
            string sb = "";
            byte[] byStr = System.Text.Encoding.UTF8.GetBytes(str); //默认是System.Text.Encoding.Default.GetBytes(str)
            //for (int i = 0; i < byStr.Length; i++)
            //{
            //sb.Append(@"%" + Convert.ToString(byStr[i], 16));

            sb = str.Replace("+", "%2B");
            sb = sb.Replace("/", "%2F");
            sb = sb.Replace("=", "%3D");
            //}

            return (sb.ToString());
        }


        //定义加密
        private static string CreateToken(string message, string secret)
        {
            secret = secret ?? "";
            var encoding = new System.Text.ASCIIEncoding();
            byte[] keyByte = encoding.GetBytes(secret);
            byte[] messageBytes = encoding.GetBytes(message);
            using (var hmacsha256 = new HMACSHA256(keyByte))
            {
                byte[] hashmessage = hmacsha256.ComputeHash(messageBytes);
                return Convert.ToBase64String(hashmessage);
            }
        }

        public Service1()
        {
            InitializeComponent();
            //启用暂停恢复  
            base.CanPauseAndContinue = true;

            t = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent);
            t.AutoReset = true;
            t.Enabled = true;

            
        }

        //启动服务执行 
        protected override void OnStart(string[] args)
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "启动";
            WriteLog(state);  
        }

        //停止服务执行  
        protected override void OnStop()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "停止";
            WriteLog(state);
        }

        //恢复服务执行  
        protected override void OnContinue()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "继续";
            WriteLog(state);
            t.Start();
        }

        //暂停服务执行  
        protected override void OnPause()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "暂停";
            WriteLog(state);
            t.Stop();
        }

        public void WriteLog(string str)
        {
            using (StreamWriter sw = File.AppendText(@"d:\AutoTrafficLog.txt"))
            {
                sw.WriteLine(str);
                sw.Flush();
            }
        }

        

        public void OnTimedEvent(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour_0 = 23;
            int ihour_12 = 12;

            int iminute = 57;
            int iminute_12 = 00;
            //if (inthour == ihour_1 || inthour == ihour_3 || inthour == ihour_5 || inthour == ihour_7 || inthour == ihour_9 || inthour == ihour_11 || inthour == ihour_13 || inthour == ihour_15 || inthour == ihour_17 || inthour == ihour_19 || inthour == ihour_21 || inthour == ihour_23 && intminute == iminute)

            if ((inthour == ihour_0 && intminute == iminute) || (inthour == ihour_12 && intminute == iminute_12) )
            {
                try
                {

                    //计算运算时间
                    System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                    sw.Start();

                    do
                    {
                        Thread.Sleep(100);
                        //选择设备名称
                        //string import_device = "SH_QH_WT01";
                        string import_device = "SH_ZPP4_APN_PE01";
                        //string import_device = "SH_ZPP3_VPN_PE02";
                        DateTime dtn = DateTime.Now;


                        //当前分钟的时间戳
                        string strdtn = dtn.ToString("yyyy/MM/dd HH:mm");
                        DateTime dtnN = DateTime.Parse(strdtn);
                        var epochn = (dtnN.ToUniversalTime().Ticks - 621355968000000000) / 10000000;
                        string DtN = epochn.ToString();

                        //定义日期开始时间
                        DateTime dts = dtn.AddDays(0).AddHours(-12);
                        string strdts = dts.ToString("yyyy/MM/dd  HH:mm");
                        DateTime dtsC = DateTime.Parse(strdts);
                        var epochs = (dtsC.ToUniversalTime().Ticks - 621355968000000000) / 10000000;
                        string Dts = epochs.ToString();

                        //定义日期结束时间
                        DateTime dte = dtn.AddDays(0).AddHours(0).AddSeconds(-1);
                        string strdte = dte.ToString("yyyy/MM/dd  HH:mm");
                        DateTime dteC = DateTime.Parse(strdte);
                        var epoche = (dteC.ToUniversalTime().Ticks - 621355968000000000) / 10000000;
                        string Dte = epoche.ToString();

                        //定义导入数据日期格式为
                        string date = dts.ToString("yyyy/MM/dd");

                        //url，开始日期与结束日期顺序颠倒，加强保密性
                        //key值
                        string key = CreateToken(Dte + Dts + DtN, "fashion@123");




                        //定义URL字符串
                        string sURL = "http://169.2.3.9:8080/plugins/flowget/?d=" + import_device + "&f=json" + "&s=" + Dts + "&e=" + Dte + "&k=" + UrlEncode(key);

                        WebRequest wrGETURL;
                        //发起WEB请求
                        wrGETURL = WebRequest.Create(sURL);
                        //URL值转成string类型                         
                        Condition.geturlvalue = GetContentFromUrll(sURL);

                        Account account = JsonConvert.DeserializeObject<Account>(Condition.geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                        string error = account.error;                                                   //取出返回值名称为error的数值
                        List<Account> data = (List<Account>)account.data;                               //取出返回值名称为data下的json类型数据
                        Condition.listData = data;                                                      //把取到的json数据赋值给全局变量 listData
                        Condition.account_error = error;                                                //赋值给公共变量account_error
                        string reason = account.reason;                                                 //取出返回值名称为reason的数值

                        //if (Condition.geturlvalue == "参数传递无效, 请检查!")
                        if (error == "True")
                        {
                            WriteLog("自动导入1失败: 原因：返回error值为True "  + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                            continue;
                        }
                        else if (data == null || data.Count == 0)
                        {
                            WriteLog("自动导入1失败：原因：List值为空 " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                            continue;
                        }
                        else
                        {

                            //声明数据库
                            string sqldel = "";
                            string sqlset1 = "";
                            string sqlset2 = "";
                            //string sqlclear = "";
                            string sqlinfo = "";
                            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                            SqlConnection conn = new SqlConnection(strconn);
                            //打开数据库连接
                            conn.Open();
                            //现清除临时表导入1和导入2
                            sqldel = string.Format("delete from 导入1  delete from 导入2 ");
                            SqlCommand deleteset = new SqlCommand(sqldel, conn);
                            int deletesetresult = deleteset.ExecuteNonQuery();


                            ////////////////////////////////////循环读取JSON并插入数据库////////////////////////////////

                            //List<Account> AccountList = JsonConvert.DeserializeObject<List<Account>>(Condition.geturlvalue);
                            List<Account> AccountList = Condition.listData;
                            foreach (Account accountList in AccountList)        //循环读取json数据
                            {
                                string src = accountList.src;
                                string dst = accountList.dst;

                                string octets = accountList.octets;
                                long octetsl = long.Parse(octets) / 1024 / 1024;
                                if (octetsl >= 0.0045)
                                {
                                    string traffic = octetsl.ToString();


                                    //插入导入1表
                                    sqlset1 = string.Format("insert into 导入1 VALUES ('{0}','{1}','{2}') ", date, src, traffic);
                                    SqlCommand commandset1 = new SqlCommand(sqlset1, conn);
                                    int resultset1 = commandset1.ExecuteNonQuery();



                                    //插入导入2表
                                    sqlset2 = string.Format("insert into 导入2 VALUES ('{0}','{1}','{2}') ", date, dst, traffic);
                                    SqlCommand commandset2 = new SqlCommand(sqlset2, conn);
                                    int resultset2 = commandset2.ExecuteNonQuery();
                                }

                            }

                            ///////////////////////////////////////////////////////////////////////////////////////////

                            Thread.Sleep(5);
                            //把导入1数据放入主表1中
                            sqlset1 = "insert into Traffic(date,source,traffic) select date,source,traffic from 导入1 ";
                            SqlCommand commandmain1 = new SqlCommand(sqlset1, conn);
                            int resulmain1 = commandmain1.ExecuteNonQuery();

                            Thread.Sleep(5);
                            //把导入2数据放入主表2中
                            sqlset2 = "insert into Traffic2(date,source,traffic) select date,source,traffic from 导入2 ";
                            SqlCommand commandmain2 = new SqlCommand(sqlset2, conn);
                            int resulmain2 = commandmain2.ExecuteNonQuery();

                            Thread.Sleep(5);
                            //清除护镖数据为0的数据
                            //sqlclear = "delete Traffic where Traffic = 0  delete Traffic2 where Traffic = 0 ";
                            //SqlCommand commandclear = new SqlCommand(sqlclear, conn);
                            //int resulclear = commandclear.ExecuteNonQuery();

                            sw.Stop();
                            //lbltime.Text = "耗时：" + sw.Elapsed.TotalSeconds.ToString() + "秒"; //代码运行时间  
                            sqlinfo = string.Format("insert into InfoLog values('{0}' , '{1}' , '{2}')", strdtn, "自动系统1", "自动导入数据成功" + "时间段从" + dts + "到" + dte + "，耗时：" + sw.Elapsed.TotalSeconds.ToString() + "秒");
                            SqlCommand commandinfo = new SqlCommand(sqlinfo, conn);
                            int resulinfo = commandinfo.ExecuteNonQuery();

                            conn.Close();
                            WriteLog("自动导入1成功:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                        }
                    

                    } while (Condition.account_error == "True" || Condition.listData.Count == 0 );
                    
                }
                catch (Exception ex)
                {
                    WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                }
            }
            
        }  

        
    }
}
