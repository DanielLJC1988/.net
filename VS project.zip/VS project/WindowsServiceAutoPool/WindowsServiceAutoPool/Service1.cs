﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using Newtonsoft.Json;
using System.Net;
using System.Threading;
using System.Security.Cryptography;
using System.Net.Mail;

namespace WindowsServiceAutoPool
{
    public partial class Service1 : ServiceBase
    {
        //定时器  
        System.Timers.Timer t1 = null;
        System.Timers.Timer t2 = null;
        System.Timers.Timer t3 = null;
        System.Timers.Timer t4 = null;
        System.Timers.Timer t5 = null;
        System.Timers.Timer t6 = null;
        //System.Timers.Timer t7 = null;
        System.Timers.Timer t8 = null;

        //定义全局变量类Condition，其中的condition
        class Condition
        {
            //用来把sql语句赋值给下面的全局变量

            public static string conditionPool = "";
            public static string condition2Pool = "";
            public static string condition3Pool = "";
            public static string condition4Pool = "";
            public static string condition5Pool = "";
            public static string conditionPoolXBK = "";
            public static int contrafficCT4G = 0;
            public static int contrafficCT4Guse = 0;
            public static int contrafficCTZJ = 0;
            public static int contrafficCTZJuse = 0;
            public static int contrafficCU = 0;
            public static int contrafficCUuse = 0;
            public static int contrafficYD = 0;
            public static int contrafficYDuse = 0;
            public static int contrafficQX = 0;
            public static int contrafficQXuse = 0;

            public static int contrafficWC = 0;
            public static int contrafficWCuse = 0;
            public static int contraffic3GWC = 0;
            public static int contraffic3GWCuse = 0;

            public static int contrafficXBK = 0;
            public static int contrafficXBKuse = 0;
        }

        public Service1()
        {
            InitializeComponent();
            //启用暂停恢复  
            base.CanPauseAndContinue = true;

            t1 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t1.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent1);
            t1.AutoReset = true;
            t1.Enabled = true;

            t2 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t2.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent2);
            t2.AutoReset = true;
            t2.Enabled = true;

            t3 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t3.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent3);
            t3.AutoReset = true;
            t3.Enabled = true;

            t4 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t4.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent4);
            t4.AutoReset = true;
            t4.Enabled = true;

            t5 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t5.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent5);
            t5.AutoReset = true;
            t5.Enabled = true;

            t6 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t6.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent6);
            t6.AutoReset = true;
            t6.Enabled = true;

            //t7 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            //t7.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent7);
            //t7.AutoReset = true;
            //t7.Enabled = true;

            t8 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t8.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent8);
            t8.AutoReset = true;
            t8.Enabled = true;

            
        }

        protected override void OnStart(string[] args)
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "启动";
            WriteLog(state);
        }

        //停止服务执行  
        protected override void OnStop()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "停止";
            WriteLog(state);
        }

        //恢复服务执行  
        protected override void OnContinue()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "继续";
            WriteLog(state);
            t1.Start();
            t2.Start();
            t3.Start();
            t4.Start();
            t5.Start();
            t6.Start();
            //t7.Start();
            t8.Start();
        }

        //暂停服务执行  
        protected override void OnPause()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "暂停";
            WriteLog(state);
            t1.Stop();
            t2.Stop();
            t3.Stop();
            t4.Stop();
            t5.Stop();
            t6.Stop();
            //t7.Stop();
            t8.Stop();
        }

        public void WriteLog(string str)
        {
            using (StreamWriter sw = File.AppendText(@"d:\AutoTrafficPool.txt"))
            {
                sw.WriteLine(str);
                sw.Flush();
            }
        }

        public void OnTimedEvent1(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 30;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd");
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd");
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd");
            #endregion

            Condition.condition3Pool = " and IP like '169.%' ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition3Pool
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " and CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null and OperatorType = '电信' and ClientInfo.Card  like '106%' "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string strtraffic = myReader["流量"].ToString();
                    double doubletraffic = double.Parse(strtraffic);
                    int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型
                    Condition.contrafficCTZJuse = inttraffic;
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    //5月份 50张1024MB + 1张500MB + 192张50MB  = 118998MB ≈ 116GB
                    //7月17日加了50张500M的     =25000MB
                    //7月21日加了50张50M的      =2500MB
                    //10月28日加了50张50M的     =2500MB
                    //12月10日加了32张50M的     =1600MB
                    //16年1月22日加了40张50M的  =2000MB 
                    //16年3月2日加了30张50M的   =1500MB
                    //16年3月21日加了10张1G的，30张50M的   =10240 + 1500 = 11740MB
                    //16年4月19日加了30张1024M的   = 30720MB
                    //16年6月7日加入30张50M的   = 1500MB
                    //总共197844MB ≈ 193GB
                    //开会讨论后修正为174080MB = 170GB

                    //16年7月6日加入30张50M的   =1500MB
                    //总共175580  =171.46GB
                    //17年4月14日拆机89张，总共18.5G , 总共=156636  =152.96GB
                    float shenyutrafficCTZJ = (float)inttraffic / 156636;

                    //double shenyutrafficCTZJ = Convert.ToDouble(inttraffic / 130098);

                    /////////////////////////////////////////////////////////////
                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.High;//设置优先级别
                    mmsg.From = new MailAddress("\"流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("sunxp@fashion-tele.com,xiaoy@fashion-tele.com,service@fashion-tele.com,technology@fashion-tele.com");//收件人
                    mmsg.CC.Add("business@fashion-tele.com,sales1@fashion-tele.com");//抄送人
                    mmsg.IsBodyHtml = true;

                    if (shenyutrafficCTZJ >= 0.6 && shenyutrafficCTZJ < 0.8)
                    {
                        mmsg.Subject = "本月公司电信智机通流量池已使用了60%！！！请各部门注意";
                        mmsg.Body = "各部门注意<br><br>截止" + time + "，本月公司电信智机通流量池已使用了60%！！！请各部门注意"
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                    else if (shenyutrafficCTZJ >= 0.8 && shenyutrafficCTZJ < 1)
                    {
                        mmsg.Subject = "本月公司电信智机通流量池已使用了80%！！！请各部门注意";
                        mmsg.Body = "各部门注意<br><br>截止" + time + "，本月公司电信智机通流量池已使用了80%！！！请各部门注意"
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                    else if (shenyutrafficCTZJ >= 1)
                    {
                        mmsg.Subject = "本月公司电信智机通流量池已用尽！！！请各部门注意";
                        mmsg.Body = "各部门注意<br><br>截止" + time + "，本月公司电信智机通流量池已用尽！！！已开始使用额外费用！！请各部门注意"
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent2(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 30;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd");
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") ;
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") ;
            #endregion

            Condition.condition3Pool = " and IP like '169.%' ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition3Pool
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " and CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null and OperatorType = '联通'  "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string strtraffic = myReader["流量"].ToString();
                    double doubletraffic = double.Parse(strtraffic);
                    int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型
                    Condition.contrafficCUuse = inttraffic;
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    float shenyutrafficCU = (float)inttraffic / 1689600;
                    //double shenyutrafficCU = Convert.ToDouble(aaa);

                    /////////////////////////////////////////////////////////////
                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.High;//设置优先级别
                    mmsg.From = new MailAddress("\"流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("sunxp@fashion-tele.com,xiaoy@fashion-tele.com,service@fashion-tele.com,technology@fashion-tele.com");//收件人
                    mmsg.CC.Add("business@fashion-tele.com,sales1@fashion-tele.com");//抄送人
                    mmsg.IsBodyHtml = true;

                    if (shenyutrafficCU >= 0.6 && shenyutrafficCU < 0.8)
                    {
                        mmsg.Subject = "本月公司联通流量池已使用了60%！！！请各部门注意";
                        mmsg.Body = "各部门注意<br><br>截止" + time + "，本月公司联通流量池已使用了60%！！！请各部门注意"
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                    else if (shenyutrafficCU >= 0.8 && shenyutrafficCU < 1)
                    {
                        mmsg.Subject = "本月公司联通流量池已使用了80%！！！请各部门注意";
                        mmsg.Body = "各部门注意<br><br>截止" + time + "，本月公司联通流量池已使用了80%！！！请各部门注意"
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                    else if (shenyutrafficCU >= 1)
                    {
                        mmsg.Subject = "本月公司联通流量池已用尽！！！请各部门注意";
                        mmsg.Body = "各部门注意<br><br>截止" + time + "，本月公司联通流量池已用尽！！！已开始产生额外费用！！请各部门注意"
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent3(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 30;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd");
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd");
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd");
            #endregion

            Condition.condition3Pool = " where IP like '169.%' ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlCT = " select sum(traffic)as 流量 from ClientInfo where OperatorType = '移动' ";



                SqlCommand cmdCT = new SqlCommand(sqlCT, conn);
                cmdCT.ExecuteNonQuery();
                SqlDataReader myReaderCT = cmdCT.ExecuteReader();
                while (myReaderCT.Read())
                {
                    //dr = dt.NewRow();
                    string strtraffic = myReaderCT["流量"].ToString();
                    double doubletraffic = double.Parse(strtraffic);
                    int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计总流量转换为int类型
                    //Condition.contrafficCT = inttraffic;              //有问题改成固定的了 目前152张移动卡,8月15日增加30张1G的，9月增加40张1G,10月11日增加40张1G =262张
                    Condition.contrafficYD = 268288;
                }

                myReaderCT.Close();

                string sqlEK = " select  sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition3Pool
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " and CardType = '4G卡' and ClientName not like '%闲置%'  and IP is not Null and OperatorType = '移动'  "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string strtraffic = myReader["流量"].ToString();
                    double doubletraffic = double.Parse(strtraffic);
                    int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型
                    Condition.contrafficYDuse = inttraffic;
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    float shenyutrafficCT = (float)Condition.contrafficYDuse / (float)Condition.contrafficYD;
                    //double shenyutrafficCU = Convert.ToDouble(aaa);

                    /////////////////////////////////////////////////////////////
                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.High;//设置优先级别
                    mmsg.From = new MailAddress("\"流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("sunxp@fashion-tele.com,xiaoy@fashion-tele.com,service@fashion-tele.com,technology@fashion-tele.com");//收件人
                    mmsg.CC.Add("business@fashion-tele.com,sales1@fashion-tele.com");//抄送人
                    mmsg.IsBodyHtml = true;

                    if (shenyutrafficCT >= 0.6 && shenyutrafficCT < 0.8)
                    {
                        mmsg.Subject = "本月公司移动流量池已使用了60%！！！请各部门注意";
                        mmsg.Body = "各部门注意<br><br>截止" + time + "，本月公司移动流量池已使用了60%！！！请各部门注意"
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                    else if (shenyutrafficCT >= 0.8 && shenyutrafficCT < 1)
                    {
                        mmsg.Subject = "本月公司移动流量池已使用了80%！！！请各部门注意";
                        mmsg.Body = "各部门注意<br><br>截止" + time + "，本月公司移动流量池已使用了80%！！！请各部门注意"
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                    else if (shenyutrafficCT >= 1)
                    {
                        mmsg.Subject = "本月公司移动流量池已用尽！！！已开始使用额外费用！！请各部门注意";
                        mmsg.Body = "各部门注意<br><br>截止" + time + "，本月公司移动流量池已用尽！！！请各部门注意"
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent4(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 30;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd");
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd");
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd");
            #endregion

            Condition.condition3Pool = " and IP like '169.%' ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition3Pool
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " and CardType = '4G卡' and ClientName not like '%闲置%'  and IP is not Null and OperatorType = '深圳电信'  "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string strtraffic = myReader["流量"].ToString();
                    double doubletraffic = double.Parse(strtraffic);
                    int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型
                    Condition.contrafficCT4Guse = inttraffic;
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    float shenyutrafficCU = (float)inttraffic / 1024000;
                    //double shenyutrafficCU = Convert.ToDouble(aaa);

                    /////////////////////////////////////////////////////////////
                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.High;//设置优先级别
                    mmsg.From = new MailAddress("\"流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("sunxp@fashion-tele.com,xiaoy@fashion-tele.com,service@fashion-tele.com,technology@fashion-tele.com");//收件人
                    mmsg.CC.Add("business@fashion-tele.com,sales1@fashion-tele.com");//抄送人
                    mmsg.IsBodyHtml = true;

                    if (shenyutrafficCU >= 0.6 && shenyutrafficCU < 0.8)
                    {
                        mmsg.Subject = "本月公司电信4G流量池已使用了60%！！！请各部门注意";
                        mmsg.Body = "各部门注意<br><br>截止" + time + "，本月公司电信4G流量池已使用了60%！！！请各部门注意"
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                    else if (shenyutrafficCU >= 0.8 && shenyutrafficCU < 1)
                    {
                        mmsg.Subject = "本月公司电信4G流量池已使用了80%！！！请各部门注意";
                        mmsg.Body = "各部门注意<br><br>截止" + time + "，本月公司电信4G流量池已使用了80%！！！请各部门注意"
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                    else if (shenyutrafficCU >= 1)
                    {
                        mmsg.Subject = "本月公司电信4G流量池已用尽！！！请各部门注意";
                        mmsg.Body = "各部门注意<br><br>截止" + time + "，本月公司电信4G流量池已用尽！！！已开始产生额外费用！！请各部门注意"
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent5(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 30;
            int ihour = 9;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
            #endregion

            Condition.condition3Pool = " where IP like '169.%' ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlCT = " select sum(traffic)as 流量 from ClientInfo where ClientName like  '%千寻%' ";



                SqlCommand cmdCT = new SqlCommand(sqlCT, conn);
                cmdCT.ExecuteNonQuery();
                SqlDataReader myReaderCT = cmdCT.ExecuteReader();
                while (myReaderCT.Read())
                {
                    //dr = dt.NewRow();
                    string strtraffic = myReaderCT["流量"].ToString();
                    double doubletraffic = double.Parse(strtraffic);
                    int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计总流量转换为int类型
                    Condition.contrafficQX = inttraffic;              //
                    //Condition.contrafficCT = 268288;
                }

                myReaderCT.Close();

                string sqlEK = " select  sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition3Pool
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " and CardType = '4G卡' and ClientName  like '%千寻%'  and IP is not Null   "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string strtraffic = myReader["流量"].ToString();
                    double doubletraffic = double.Parse(strtraffic);
                    int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型
                    Condition.contrafficQXuse = inttraffic;
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    float shenyutrafficCU = (float)inttraffic / Condition.contrafficQX;
                    //double shenyutrafficCU = Convert.ToDouble(aaa);

                    /////////////////////////////////////////////////////////////
                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.High;//设置优先级别
                    mmsg.From = new MailAddress("\"流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("chen.zhou@wz-inc.com,service@fashion-tele.com,technology@fashion-tele.com");//收件人
                    mmsg.CC.Add("yichuan.wyc@wz-inc.com,qiang.hua@wz-inc.com,gujp@fashion-tele.com");//抄送人
                    mmsg.IsBodyHtml = true;

                    if (shenyutrafficCU >= 0.8 && shenyutrafficCU < 1)
                    {
                        mmsg.Subject = "尊敬的千寻位置网络 ：截止" + time +  " 本月贵司的流量池已使用80% ";
                        mmsg.Body = "尊敬的千寻位置网络:<br><br>截止" + time + "，本月贵司的流量池已使用80% "
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                    
                    else if (shenyutrafficCU >= 1)
                    {
                        mmsg.Subject = "尊敬的千寻位置网络 ：截止" + time + " 本月贵司的流量池已用尽！！ ";
                        mmsg.Body = "尊敬的千寻位置网络:<br><br>截止" + time + "，本月贵司的流量池已用尽,继续使用将产生额外费用！！ "
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent6(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 30;
            int ihour = 9;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
            #endregion

            Condition.condition3Pool = " where IP like '169.%' ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlCT = " select sum(traffic)as 流量 from ClientInfo where ClientName like  '%文骋%' and CardType = '4G卡' ";



                SqlCommand cmdCT = new SqlCommand(sqlCT, conn);
                cmdCT.ExecuteNonQuery();
                SqlDataReader myReaderCT = cmdCT.ExecuteReader();
                while (myReaderCT.Read())
                {
                    //dr = dt.NewRow();
                    string strtraffic = myReaderCT["流量"].ToString();
                    double doubletraffic = double.Parse(strtraffic);
                    int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计总流量转换为int类型
                    Condition.contrafficWC = inttraffic;              //
                    //Condition.contrafficCT = 268288;
                }

                myReaderCT.Close();

                string sqlEK = " select  sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition3Pool
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " and CardType = '4G卡' and ClientName  like '%文骋%'  and IP is not Null   "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string strtraffic = myReader["流量"].ToString();
                    double doubletraffic = double.Parse(strtraffic);
                    int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型
                    Condition.contrafficWCuse = inttraffic;
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    float shenyutrafficCU = (float)inttraffic / Condition.contrafficWC;
                    //double shenyutrafficCU = Convert.ToDouble(aaa);

                    /////////////////////////////////////////////////////////////
                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.High;//设置优先级别
                    mmsg.From = new MailAddress("\"4G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("wj.xu@venture-tech.net,service@venture-tech.net");//收件人
                    mmsg.CC.Add("gbh@fashion-tele.com,service@fashion-tele.com,noc@fashion-tele.com");//抄送人
                    mmsg.IsBodyHtml = true;

                    if (shenyutrafficCU >= 0.8 && shenyutrafficCU < 1)
                    {
                        mmsg.Subject = "尊敬的上海文骋科技发展有限公司 ：截止" + time + " 本月贵司4G卡流量池已使用80% ";
                        mmsg.Body = "尊敬的上海文骋科技发展有限公司:<br><br>截止" + time + "，本月贵司4G卡流量池已使用80% "
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }

                    else if (shenyutrafficCU >= 1)
                    {
                        mmsg.Subject = "尊敬的上海文骋科技发展有限公司 ：截止" + time + " 本月贵司4G卡流量池已用尽！！ ";
                        mmsg.Body = "尊敬的上海文骋科技发展有限公司:<br><br>截止" + time + "，本月贵司4G卡流量池已用尽,继续使用将产生额外费用！！ "
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        //public void OnTimedEvent7(object source, System.Timers.ElapsedEventArgs e)
        //{
        //    int inthour = e.SignalTime.Hour;
        //    int intminute = e.SignalTime.Minute;
        //    int iminute = 30;
        //    int ihour = 9;

        //    #region     周期计算
        //    string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd");
        //    string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd");
        //    string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd");
        //    #endregion

        //    Condition.condition4Pool = " where (Traffic.source like '169.5.18.%'  ) ";
        //    Condition.condition5Pool = " where (Traffic2.source like '169.5.18.%'  ) ";

        //    if (inthour == ihour && intminute == iminute)
        //    {
        //        //定义连接字符串
        //        string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
        //        SqlConnection conn = new SqlConnection(strconn);
        //        conn.Open();

        //        string sqlCT = " select sum(traffic)as 流量 from ClientInfo where ClientName like  '%文骋%' and CardType = '3G卡' ";



        //        SqlCommand cmdCT = new SqlCommand(sqlCT, conn);
        //        cmdCT.ExecuteNonQuery();
        //        SqlDataReader myReaderCT = cmdCT.ExecuteReader();
        //        while (myReaderCT.Read())
        //        {
        //            //dr = dt.NewRow();
        //            string strtraffic = myReaderCT["流量"].ToString();
        //            double doubletraffic = double.Parse(strtraffic);
        //            int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计总流量转换为int类型
        //            Condition.contraffic3GWC = inttraffic;              //
        //            //Condition.contrafficCT = 268288;
        //        }

        //        myReaderCT.Close();

        //        string sqlEK = " select sum(流量) as 流量 from ("
        //                + " select source ,sum(traffic) as 流量  "
        //                + " from Traffic2 "
        //                + Condition.condition5Pool
        //                + " and (Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "') "
        //                + " group by source "
        //                + " union "
        //                + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
        //                + " from Traffic "
        //                + Condition.condition4Pool
        //                + " and (Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "') "
        //                + " group by source "
        //                + " )Traffic2 left join ClientInfo  ON source = IP where ClientName  like '%文骋%'   "
        //                + " order by 流量 DESC ";

        //        SqlCommand cmd = new SqlCommand(sqlEK, conn);
        //        cmd.ExecuteNonQuery();
        //        SqlDataReader myReader = cmd.ExecuteReader();
        //        while (myReader.Read())
        //        {
        //            string strtraffic = myReader["流量"].ToString();
        //            double doubletraffic = double.Parse(strtraffic);
        //            int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型
        //            Condition.contraffic3GWCuse = inttraffic;
        //            //定义告警日期
        //            string time = System.DateTime.Now.ToString("MM月dd日HH时");

        //            float shenyutrafficCU = (float)inttraffic / Condition.contraffic3GWC;
        //            //double shenyutrafficCU = Convert.ToDouble(aaa);

        //            /////////////////////////////////////////////////////////////
        //            MailMessage mmsg = new MailMessage();//实例一个mailmessage
        //            mmsg.Priority = MailPriority.High;//设置优先级别
        //            mmsg.From = new MailAddress("\"3G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
        //            mmsg.To.Add("wj.xu@venture-tech.net,service@venture-tech.net");//收件人
        //            mmsg.CC.Add("gbh@fashion-tele.com,service@fashion-tele.com,noc@fashion-tele.com");//抄送
        //            mmsg.IsBodyHtml = true;

                    
        //            if (shenyutrafficCU >= 0.8 && shenyutrafficCU < 1)
        //            {
        //                mmsg.Subject = "尊敬的上海文骋科技发展有限公司 ：截止" + time + " 本月贵司3G卡流量池已使用80% ";
        //                mmsg.Body = "尊敬的上海文骋科技发展有限公司:<br><br>截止" + time + "，本月贵司3G卡流量池已使用80% "
        //                          + "<br><br>";
        //                SmtpClient smtpclient = new SmtpClient();
        //                smtpclient.Host = "smtp.exmail.qq.com";
        //                smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
        //                smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
        //                try
        //                {
        //                    //SmtpMail.Send(mmsg);//发送邮件
        //                    smtpclient.Send(mmsg);

        //                }
        //                catch (Exception ex)
        //                {
        //                    WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
        //                }
        //            }
        //            else if (shenyutrafficCU >= 1)
        //            {
        //                mmsg.Subject = "尊敬的上海文骋科技发展有限公司 ：截止" + time + " 本月贵司3G卡流量池已用尽！！ ";
        //                mmsg.Body = "尊敬的上海文骋科技发展有限公司:<br><br>截止" + time + "，本月贵司3G卡流量池已用尽,继续使用将产生额外费用！！ "
        //                          + "<br><br>";
        //                SmtpClient smtpclient = new SmtpClient();
        //                smtpclient.Host = "smtp.exmail.qq.com";
        //                smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
        //                smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
        //                try
        //                {
        //                    //SmtpMail.Send(mmsg);//发送邮件
        //                    smtpclient.Send(mmsg);

        //                }
        //                catch (Exception ex)
        //                {
        //                    WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
        //                }
        //            }
        //        }
        //        myReader.Dispose();
        //        myReader.Close();
        //        conn.Close();
        //    }
        //}

        public void OnTimedEvent8(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 34;
            int ihour = 9;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
            #endregion

            //星巴克流量池可以3G和4G混合组池，原因是3G卡也启用了L2TP
            Condition.conditionPoolXBK = " where IP like '169.5.21.%' ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlCT = " select sum(traffic)as 流量 from ClientInfo where ClientName like  '%星巴克%'  ";



                SqlCommand cmdCT = new SqlCommand(sqlCT, conn);
                cmdCT.ExecuteNonQuery();
                SqlDataReader myReaderCT = cmdCT.ExecuteReader();
                while (myReaderCT.Read())
                {
                    //dr = dt.NewRow();
                    string strtraffic = myReaderCT["流量"].ToString();
                    double doubletraffic = double.Parse(strtraffic);
                    int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计总流量转换为int类型
                    Condition.contrafficXBK = inttraffic;              //
                    
                }

                myReaderCT.Close();

                string sqlEK = " select  sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.conditionPoolXBK
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += "  and ClientName  like '%星巴克%'  and IP is not Null   "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string strtraffic = myReader["流量"].ToString();
                    double doubletraffic = double.Parse(strtraffic);
                    int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型
                    Condition.contrafficXBKuse = inttraffic;
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    float shenyutrafficCU = (float)inttraffic / Condition.contrafficXBK;
                    //double shenyutrafficCU = Convert.ToDouble(aaa);

                    /////////////////////////////////////////////////////////////
                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.High;//设置优先级别
                    mmsg.From = new MailAddress("\"流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("shiy@fashion-tele.com,gujp@fashion-tele.com,wangli@fashion-tele.com");//收件人
                    mmsg.CC.Add("service@fashion-tele.com,noc@fashion-tele.com");//抄送人
                    mmsg.IsBodyHtml = true;

                    if (shenyutrafficCU >= 0.8 && shenyutrafficCU < 1)
                    {
                        mmsg.Subject = "尊敬的星巴克 ：截止" + time + " 本月贵司卡流量池已使用80% ";
                        mmsg.Body = "尊敬的星巴克:<br><br>截止" + time + "，本月贵司卡流量池已使用80% "
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }

                    else if (shenyutrafficCU >= 1)
                    {
                        mmsg.Subject = "尊敬的星巴克 ：截止" + time + " 本月贵司卡流量池已用尽！！ ";
                        mmsg.Body = "尊敬的星巴克:<br><br>截止" + time + "，本月贵司卡流量池已用尽,继续使用将产生额外费用！！ "
                                  + "<br><br>";
                        SmtpClient smtpclient = new SmtpClient();
                        smtpclient.Host = "smtp.exmail.qq.com";
                        smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                        try
                        {
                            //SmtpMail.Send(mmsg);//发送邮件
                            smtpclient.Send(mmsg);

                        }
                        catch (Exception ex)
                        {
                            WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                        }
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }
    }
}
