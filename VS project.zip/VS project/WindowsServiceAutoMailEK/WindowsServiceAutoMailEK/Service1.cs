﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using Newtonsoft.Json;
using System.Net;
using System.Threading;
using System.Security.Cryptography;
using System.Net.Mail;

namespace WindowsServiceAutoMailEK
{
    public partial class Service1 : ServiceBase
    {
        //定时器  
        System.Timers.Timer t1 = null;

        //定义全局变量类Condition，其中的condition
        class Condition
        {
            //用来把sql语句赋值给下面的全局变量

            public static string conditionEK = "";
        }

        public Service1()
        {
            InitializeComponent();
            //启用暂停恢复  
            base.CanPauseAndContinue = true;

            t1 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t1.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent1);
            t1.AutoReset = true;
            t1.Enabled = true;
        }

        protected override void OnStart(string[] args)
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "启动";
            WriteLog(state);  
        }

        //停止服务执行  
        protected override void OnStop()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "停止";
            WriteLog(state);
        }

        //恢复服务执行  
        protected override void OnContinue()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "继续";
            WriteLog(state);
            t1.Start();
        }

        //暂停服务执行  
        protected override void OnPause()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "暂停";
            WriteLog(state);
            t1.Stop();
        }

        public void WriteLog(string str)
        {
            using (StreamWriter sw = File.AppendText(@"d:\AutoMailEK.txt"))
            {
                sw.WriteLine(str);
                sw.Flush();
            }
        }

        

        public void OnTimedEvent1(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 00;
            int ihour = 11;

            Condition.conditionEK = " and ( IP like  '169.1.58.%'  or IP like '169.6.11.%' ) ";


            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  datediff(day,OutDate,getdate()) as 使用天数, ClientName, IP, Card,  CardType, Traffic, MailAddress, MailAddressCC,State, Property, sum(total) as 流量 from TrafficL2 "
                        + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                        + Condition.conditionEK
                        + " and date > = Outdate and datediff(day,OutDate,getdate()) < 365 ";


                sqlEK += " group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State,Property,OutDate  "
                       + " having sum(total) <= Traffic * 0.8  and sum(total) < Traffic   and State <> '关停' and IP is not Null  and State <> '忽略'  and Property = '包年' "
                       + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"3G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("1686334988@qq.com," + MailAddress);//收件人
                    mmsg.CC.Add("service@fashion-tele.com,wangli@fashion-tele.com,wangy@fashion-tele.com,technology@fashion-tele.com,1686334988@qq.com," + MailAddressCC);//抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月已使用套餐流量的80%，马上将要超过套餐流量！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>80%</b>，马上将要超过套餐流量！！"
                              + "<br><br>";
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "nocmonitor@fashon-crop.com");//发件人邮箱信息
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "ihz49DXj5Lx5F3sj");//密码
                    //SmtpMail.SmtpServer = "smtp.exmail.qq.com";//指定smtp服务器
                    //SmtpMail.SmtpServer = "smtp.exmail.qq.com";//指定smtp服务器

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "smtp.exmail.qq.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }






    }
}
