﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Net;
using System.Threading;
using System.Security.Cryptography;
using System.Net.Mail;

namespace WindowsServiceAutoMailAWS
{
    public partial class Service1 : ServiceBase
    {

        //定时器  
        System.Timers.Timer t1 = null;
        System.Timers.Timer t2 = null;
        System.Timers.Timer t3 = null;
        System.Timers.Timer t4 = null;
        System.Timers.Timer t5 = null;
        System.Timers.Timer t6 = null;

        //定义全局变量类Condition，其中的condition
        class Condition
        {
            //用来把sql语句赋值给下面的全局变量

            public static string condition = "";
            public static string condition2 = "";
        }

        public Service1()
        {
            InitializeComponent();
            //启用暂停恢复  
            base.CanPauseAndContinue = true;

            t1 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t1.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent1);
            t1.AutoReset = true;
            t1.Enabled = true;

            t2 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t2.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent2);
            t2.AutoReset = true;
            t2.Enabled = true;

            t3 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t3.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent3);
            t3.AutoReset = true;
            t3.Enabled = true;

            t4 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t4.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent4);
            t4.AutoReset = true;
            t4.Enabled = true;

            t5 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t5.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent5);
            t5.AutoReset = true;
            t5.Enabled = true;

            t6 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t6.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent6);
            t6.AutoReset = true;
            t6.Enabled = true;
        }

        protected override void OnStart(string[] args)
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "启动";
            WriteLog(state);
        }

        //停止服务执行  
        protected override void OnStop()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "停止";
            WriteLog(state);
        }

        //恢复服务执行  
        protected override void OnContinue()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "继续";
            WriteLog(state);
            t1.Start();
            t2.Start();
            t3.Start();
            t4.Start();
            t5.Start();
            t6.Start();
        }

        //暂停服务执行  
        protected override void OnPause()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "暂停";
            WriteLog(state);
            t1.Stop();
            t2.Stop();
            t3.Stop();
            t4.Stop();
            t5.Stop();
            t6.Stop();
        }

        public void WriteLog(string str)
        {
            using (StreamWriter sw = File.AppendText(@"d:\AutoMailAWS.txt"))
            {
                sw.WriteLine(str);
                sw.Flush();
            }
        }

        public void OnTimedEvent1(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 00;
            int ihour = 11;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.condition = " where (Traffic.source like  '169.5.1.%' or Traffic.source like '169.1.57.%' ) ";
            Condition.condition2 = " where (Traffic2.source like  '169.5.1.%' or Traffic2.source like '169.1.57.%' ) ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2
                       //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic  and sum(流量) < ClientInfo.Traffic * 2 and State <> '关停' and State <> '忽略' and ClientName = '上海埃纬斯通信技术有限公司' ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"3G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("technology@fashion-tele.com," + MailAddress);//收件人
                    mmsg.CC.Add("service@fashion-tele.com,sales1@fashion-tele.com," + MailAddressCC);//抄送人
                    mmsg.IsBodyHtml = true;
                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月已使用超过套餐流量，继续使用将产生额外费用！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，已超额使用了 <b>" + dectrafficshenyu + "MB</b>" + "，本月已使用超过套餐流量，继续使用将产生额外费用！！"
                              + "<br><br>";


                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "smtp.exmail.qq.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                    try
                    {
                        //SmtpMail.Send(mmsg);//发送邮件
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent2(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 00;
            int ihour = 11;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.condition = " where (Traffic.source like  '169.5.1.%' or Traffic.source like '169.1.57.%' ) ";
            Condition.condition2 = " where (Traffic2.source like  '169.5.1.%' or Traffic2.source like '169.1.57.%' ) ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2
                       //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 0.8 and sum(流量) < ClientInfo.Traffic  and State <> '关停' and State <> '忽略'  and ClientName = '上海埃纬斯通信技术有限公司' ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"3G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("technology@fashion-tele.com," + MailAddress);//收件人
                    mmsg.CC.Add("service@fashion-tele.com,sales1@fashion-tele.com," + MailAddressCC);//抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月已使用套餐流量的80%，马上将要超过套餐流量！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>80%</b>，马上将要超过套餐流量！！"
                              + "<br><br>";
                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "smtp.exmail.qq.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent3(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 00;
            int ihour = 11;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.condition = " where (Traffic.source like  '169.5.1.%' or Traffic.source like '169.1.57.%' ) ";
            Condition.condition2 = " where (Traffic2.source like  '169.5.1.%' or Traffic2.source like '169.1.57.%' ) ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2
                       //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 2 and sum(流量) < ClientInfo.Traffic * 3 and State <> '关停' and State <> '忽略' and ClientName = '上海埃纬斯通信技术有限公司' ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"3G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("technology@fashion-tele.com," + MailAddress);//收件人
                    mmsg.CC.Add("service@fashion-tele.com,sales1@fashion-tele.com," + MailAddressCC);//抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月已使用超过套餐流量的200%！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，已使用超过套餐流量的<b>200%</b>，继续使用将产生额外费用！！"
                              + "<br><br>";
                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "smtp.exmail.qq.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent4(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 00;
            int ihour = 11;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.condition = " where (Traffic.source like  '169.5.1.%' or Traffic.source like '169.1.57.%' ) ";
            Condition.condition2 = " where (Traffic2.source like  '169.5.1.%' or Traffic2.source like '169.1.57.%' ) ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2
                       //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 3 and sum(流量) < ClientInfo.Traffic * 4 and State <> '关停' and State <> '忽略' and ClientName = '上海埃纬斯通信技术有限公司' ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"3G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("technology@fashion-tele.com," + MailAddress);//收件人
                    mmsg.CC.Add("service@fashion-tele.com,sales1@fashion-tele.com," + MailAddressCC);//抄送人
                    mmsg.IsBodyHtml = true;
                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月已使用超过套餐流量的300%！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，已超额使用了 <b>" + dectrafficshenyu + "MB</b>" + "，已使用超过套餐流量的<b>300%</b>，继续使用将产生额外费用！！"
                              + "<br><br>";
                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "smtp.exmail.qq.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent5(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 00;
            int ihour = 11;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.condition = " where (Traffic.source like  '169.5.1.%' or Traffic.source like '169.1.57.%' ) ";
            Condition.condition2 = " where (Traffic2.source like  '169.5.1.%' or Traffic2.source like '169.1.57.%' ) ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2
                       //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 4 and sum(流量) < ClientInfo.Traffic * 5 and State <> '关停' and State <> '忽略' and ClientName = '上海埃纬斯通信技术有限公司' ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"3G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("technology@fashion-tele.com," + MailAddress);//收件人
                    mmsg.CC.Add("service@fashion-tele.com,sales1@fashion-tele.com," + MailAddressCC);//抄送人
                    mmsg.IsBodyHtml = true;
                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月已使用超过套餐流量的400%！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，已超额使用了 <b>" + dectrafficshenyu + "MB</b>" + "，已使用超过套餐流量的<b>400%</b>，继续使用将产生额外费用！！"
                              + "<br><br>";
                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "smtp.exmail.qq.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent6(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 00;
            int ihour = 11;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.condition = " where (Traffic.source like  '169.5.1.%' or Traffic.source like '169.1.57.%' ) ";
            Condition.condition2 = " where (Traffic2.source like  '169.5.1.%' or Traffic2.source like '169.1.57.%' ) ";

            if (inthour == ihour && intminute == iminute)
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2
                       //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 5  and State <> '关停' and State <> '忽略'  and ClientName = '上海埃纬斯通信技术有限公司' ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"3G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("technology@fashion-tele.com," + MailAddress);//收件人
                    mmsg.CC.Add("service@fashion-tele.com,sales1@fashion-tele.com," + MailAddressCC);//抄送人
                    mmsg.IsBodyHtml = true;
                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月已使用超过套餐流量的500%！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，已超额使用了 <b>" + dectrafficshenyu + "MB</b>" + "，已使用超过套餐流量的<b>500%</b>，继续使用将产生额外费用！！"
                              + "<br><br>";
                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "smtp.exmail.qq.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }






    }
}
