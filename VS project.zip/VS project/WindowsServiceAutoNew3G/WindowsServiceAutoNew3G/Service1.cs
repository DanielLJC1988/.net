﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using Newtonsoft.Json;
using System.Net;
using System.Threading;
using System.Security.Cryptography;

namespace WindowsServiceAutoNew3G
{
    public partial class Service1 : ServiceBase
    {

        //定时器  
        System.Timers.Timer t = null;

        //定义全局变量类Condition，其中的condition
        class Condition
        {
            //用全局变量
            public static List<Account> listData;
            public static string geturlvalue = "";
            public static string url = "http://169.2.3.9:1816/api/acct";
        }

        //定义json类
        public class Account
        {
            public List<Account> accts { get; set; } //获取data下的JSON类型数据
            public string total { get; set; }         //获取总流量
            public string user { get; set; }         //获取目的地址


        }

        //定义返回URL值
        private static string GetContentFromUrll(string _requestUrl)
        {
            string _StrResponse = "";
            HttpWebRequest _WebRequest = (HttpWebRequest)WebRequest.Create(_requestUrl);
            _WebRequest.Method = "GET";
            string username = "fashion";
            string password = "acctant";
            string usernamePassword = username + ":" + password;
            CredentialCache mycache = new CredentialCache();
            mycache.Add(new Uri(Condition.url), "Basic", new NetworkCredential(username, password));

            _WebRequest.Credentials = mycache;
            _WebRequest.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(new ASCIIEncoding().GetBytes(usernamePassword)));

            WebResponse _WebResponse = _WebRequest.GetResponse();
            StreamReader _ResponseStream = new StreamReader(_WebResponse.GetResponseStream(), System.Text.Encoding.GetEncoding("UTF-8"));  //gb2312
            _StrResponse = _ResponseStream.ReadToEnd();
            _WebResponse.Close();
            _ResponseStream.Close();
            return _StrResponse;
        }

        //定义URL编码
        public static string UrlEncode(string str)
        {
            //StringBuilder sb = new StringBuilder();
            string sb = "";
            byte[] byStr = System.Text.Encoding.UTF8.GetBytes(str); //默认是System.Text.Encoding.Default.GetBytes(str)
            //for (int i = 0; i < byStr.Length; i++)
            //{
            //sb.Append(@"%" + Convert.ToString(byStr[i], 16));

            sb = str.Replace("+", "%2B");
            sb = sb.Replace("/", "%2F");
            sb = sb.Replace("=", "%3D");
            //}

            return (sb.ToString());
        }


        public Service1()
        {
            InitializeComponent();
            //启用暂停恢复  
            base.CanPauseAndContinue = true;

            t = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent);
            t.AutoReset = true;
            t.Enabled = true;
        }

        //启动服务执行 
        protected override void OnStart(string[] args)
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "启动";
            WriteLog(state);
        }

        //停止服务执行  
        protected override void OnStop()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "停止";
            WriteLog(state);
        }

        //恢复服务执行  
        protected override void OnContinue()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "继续";
            WriteLog(state);
            t.Start();
        }

        //暂停服务执行  
        protected override void OnPause()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "暂停";
            WriteLog(state);
            t.Stop();
        }

        public void WriteLog(string str)
        {
            using (StreamWriter sw = File.AppendText(@"d:\AutoTrafficLog3GNEW.txt"))
            {
                sw.WriteLine(str);
                sw.Flush();
            }
        }



        public void OnTimedEvent(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;

            int iminute = 04;

            if (intminute == iminute)
            {
                try
                {

                    //计算运算时间
                    System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                    sw.Start();

                    //定义导入数据日期格式为
                    string date = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

                    WebRequest wrGETURL;
                    //发起WEB请求
                    wrGETURL = WebRequest.Create(Condition.url);
                    //URL值转成string类型                         
                    Condition.geturlvalue = GetContentFromUrll(Condition.url);

                    Account account = JsonConvert.DeserializeObject<Account>(Condition.geturlvalue);  //反序列化string类型的URL值，变为JSON类型



                    List<Account> data = (List<Account>)account.accts;                       //取出返回值名称为data下的json类型数据
                    Condition.listData = data;                                              //把取到的json数据赋值给全局变量 listData

                    //声明数据库
                    string sqldel = "";
                    string sqlset1 = "";
                    string sqlclear = "";
                    string sqlinfo = "";
                    string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                    SqlConnection conn = new SqlConnection(strconn);
                    //打开数据库连接
                    conn.Open();
                    //现清除临时表导入1和导入2
                    sqldel = string.Format("delete from 导入13 ");
                    SqlCommand deleteset = new SqlCommand(sqldel, conn);
                    int deletesetresult = deleteset.ExecuteNonQuery();


                    ////////////////////////////////////循环读取JSON并插入数据库////////////////////////////////

                    //List<Account> AccountList = JsonConvert.DeserializeObject<List<Account>>(Condition.geturlvalue);
                    List<Account> AccountList = Condition.listData;
                    foreach (Account accountList in AccountList)        //循环读取json数据
                    {
                        string user = accountList.user;
                        string total = accountList.total;

                        //插入导入1表
                        sqlset1 = string.Format("insert into 导入13 VALUES ('{0}','{1}','{2}') ", date, user, total);
                        SqlCommand commandset1 = new SqlCommand(sqlset1, conn);
                        int resultset1 = commandset1.ExecuteNonQuery();






                    }

                    ///////////////////////////////////////////////////////////////////////////////////////////

                    Thread.Sleep(5);
                    //把导入1数据放入主表1中
                    sqlset1 = "insert into TrafficL2(date,users,total) select date,users,total from 导入13 ";
                    SqlCommand commandmain1 = new SqlCommand(sqlset1, conn);
                    int resulmain1 = commandmain1.ExecuteNonQuery();



                    sw.Stop();
                    //lbltime.Text = "耗时：" + sw.Elapsed.TotalSeconds.ToString() + "秒"; //代码运行时间  
                    sqlinfo = string.Format("insert into InfoLog values('{0}' , '{1}' , '{2}')", DateTime.Now.ToString(), "自动系统3GNEW", "自动导入数据成功，耗时：" + sw.Elapsed.TotalSeconds.ToString() + "秒");
                    SqlCommand commandinfo = new SqlCommand(sqlinfo, conn);
                    int resulinfo = commandinfo.ExecuteNonQuery();

                    conn.Close();
                    WriteLog("自动导入3GNEW成功:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                }
                catch (Exception ex)
                {
                    WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                }
            }

        }


    }
}
