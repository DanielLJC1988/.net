﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using Newtonsoft.Json;
using System.Net;
using System.Threading;
using System.Security.Cryptography;
using System.Net.Mail;

namespace WindowsServiceCTG
{
    public partial class Service1 : ServiceBase
    {
        //定时器  
        //System.Timers.Timer t1 = null;
        //System.Timers.Timer t2 = null;
        //System.Timers.Timer t3 = null;
        //System.Timers.Timer t4 = null;
        //System.Timers.Timer t5 = null;
        //System.Timers.Timer t10 = null;
        System.Timers.Timer t6 = null;
        System.Timers.Timer t7 = null;
        System.Timers.Timer t8 = null;
        System.Timers.Timer t9 = null;        //2017年6月14日，针对法因图尔做的修改
        System.Timers.Timer t11 = null;

        //定义全局变量类Condition，其中的condition
        class Condition
        {
            //用来把sql语句赋值给下面的全局变量

            public static string conditionOther = "";
            public static string condition2Other = "";
            public static string condition = "";
        }

        public Service1()
        {
            InitializeComponent();
            //启用暂停恢复  
            base.CanPauseAndContinue = true;

            //t1 = new System.Timers.Timer(120000);  //间隔1分钟运行一次
            //t1.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent1);
            //t1.AutoReset = true;
            //t1.Enabled = true;

            //t2 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            //t2.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent2);
            //t2.AutoReset = true;
            //t2.Enabled = true;

            //t3 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            //t3.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent3);
            //t3.AutoReset = true;
            //t3.Enabled = true;

            //t4 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            //t4.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent4);
            //t4.AutoReset = true;
            //t4.Enabled = true;

            //t5 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            //t5.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent5);
            //t5.AutoReset = true;
            //t5.Enabled = true;

            //t10 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            //t10.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent10);
            //t10.AutoReset = true;
            //t10.Enabled = true;

            t6 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t6.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent6);
            t6.AutoReset = true;
            t6.Enabled = true;

            t7 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t7.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent7);
            t7.AutoReset = true;
            t7.Enabled = true;

            t8 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t8.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent8);
            t8.AutoReset = true;
            t8.Enabled = true;

            t9 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t9.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent9);
            t9.AutoReset = true;
            t9.Enabled = true;

            t11 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t11.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent11);
            t11.AutoReset = true;
            t11.Enabled = true;
        }

        protected override void OnStart(string[] args)
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "启动";
            WriteLog(state);
        }

        //停止服务执行  
        protected override void OnStop()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "停止";
            WriteLog(state);
        }

        //恢复服务执行  
        protected override void OnContinue()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "继续";
            WriteLog(state);
            //t1.Start();
            //t2.Start();
            //t3.Start();
            //t4.Start();
            //t5.Start();
            //t10.Start();
            t6.Start();
            t7.Start();
            t8.Start();
            t9.Start();
            t11.Start();
        }

        //暂停服务执行  
        protected override void OnPause()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "暂停";
            WriteLog(state);
            //t1.Stop();
            //t2.Stop();
            //t3.Stop();
            //t4.Stop();
            //t5.Stop();
            //t10.Stop();
            t6.Stop();
            t7.Stop();
            t8.Stop();
            t9.Stop();
            t11.Stop();
        }

        public void WriteLog(string str)
        {
            using (StreamWriter sw = File.AppendText(@"d:\AutoMailCTG.txt"))
            {
                sw.WriteLine(str);
                sw.Flush();
            }
        }

        public void OnTimedEvent1(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;


            //Condition.conditionOther = " where (  Traffic.source like '169.6.2.%' or Traffic.source like 169.5.20.%' ) ";
            //Condition.condition2Other = " where (  Traffic2.source like '169.6.2.%' or Traffic2.source like 169.5.20.%' ) ";


            //    //定义连接字符串
            //    string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            //    SqlConnection conn = new SqlConnection(strconn);
            //    conn.Open();

            //    string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
            //           + " select source ,sum(traffic) as 流量  "
            //           + " from Traffic2 "
            //           + Condition.condition2Other
            //           + " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";




            //    sqlEK += string.Format("  group by source ")
            //        + " union "
            //        + " select source ,sum(traffic) as 流量 "
            //        + " from Traffic "
            //        + Condition.conditionOther
            //        + " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";



            //    sqlEK += string.Format("  group by source ")
            //        + " )Traffic2 inner join ClientInfo  ON source = IP "
            //            + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
            //        + " >= ClientInfo.Traffic   and State <> '关停' and State <> '忽略' and ( ClientInfo.ClientName  like '迪卡侬%' or ClientInfo.ClientName like '%法因图尔%' )   ";
            //    sqlEK += " order by 流量 DESC ";

            //    SqlCommand cmd = new SqlCommand(sqlEK, conn);
            //    cmd.ExecuteNonQuery();
            //    SqlDataReader myReader = cmd.ExecuteReader();
            //    while (myReader.Read())
            //    {
            //        string client = myReader["ClientName"].ToString();
            //        string source1 = myReader["source"].ToString();
            //        string card = myReader["Card"].ToString();
            //        string Traffictotal = myReader["Traffic"].ToString();
            //        string Trafficuse = myReader["流量"].ToString();
            //        string MailAddress = myReader["MailAddress"].ToString();
            //        string MailAddressCC = myReader["MailAddressCC"].ToString();
            //        string State = myReader["State"].ToString();
            //        //定义告警日期
            //        string time = System.DateTime.Now.ToString("MM月dd日HH时");

            //        /////////////////把流量字符转换为数字型，进行计算////////////
            //        decimal dectraffictotal = decimal.Parse(Traffictotal);
            //        decimal dectrafficuse = decimal.Parse(Trafficuse);
            //        decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
            /////////////////////////////////////////////////////////////

            string time1 = System.DateTime.Now.ToString("HH");
            string time2 = System.DateTime.Now.ToString("MMMM dd ",System.Globalization.DateTimeFormatInfo.InvariantInfo);
            string time = "By " + time1 + " o'clock on " + time2;

            MailMessage mmsg = new MailMessage();//实例一个mailmessage
            mmsg.Priority = MailPriority.Normal;//设置优先级别
            mmsg.From = new MailAddress("\"CTG-流量监控系统\" <notification@ctsig.com>");//发件人
            //mmsg.To.Add("cwt@fashion-tele.com,noc@fashion-tele.com");//收件人
            mmsg.Bcc.Add("noc@fashion-tele.com");//暗抄送人
            mmsg.IsBodyHtml = true;
            mmsg.Subject = "CTG邮箱测试";
            mmsg.Body = time + " ,your number xxxxxxxxxxx has 3072MB data access of the package this month,out of whick you have already used 1705MB exceeding 50% of the total data of the package"
                      + "<br><br>"
                      + "<div><img  src=\"../WindowsServiceCTG/WindowsServiceCTG/pic/ctlogo.png />\" </div> ";

            //string htmlBodyContent = "<img src=\"cid:weblogo\">";   //注意此处嵌入的图片资源
            //AlternateView htmlBody = AlternateView.CreateAlternateViewFromString(htmlBodyContent, null, "text/html");

            //LinkedResource lrImage = new LinkedResource(@"d:\1.jpg", "image/gif");
            //lrImage.ContentId = "weblogo"; //此处的ContentId 对应 htmlBodyContent 内容中的 cid: ，如果设置不正确，请不会显示图片
            //htmlBody.LinkedResources.Add(lrImage);

            //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
            //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "monitor@fashion-tele.com");//发件人邮箱信息
            //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "Feixin123!");//密码
            //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器

            SmtpClient smtpclient = new SmtpClient();
            //smtpclient.EnableSsl = false;
            //smtpclient.Port = 25;
            smtpclient.Host = "mail.ctsig.com";
            smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
            try
            {
                //SmtpMail.Send(mmsg);//发送邮件
                smtpclient.Send(mmsg);

            }
            catch (Exception ex)
            {
                WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
            }
        }
                
                //myReader.Dispose();
                //myReader.Close();
                //conn.Close();
            
        

        public void OnTimedEvent2(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.conditionOther = " where (  Traffic.source like '169.6.2.%' or Traffic.source like 169.5.20.%' ) ";
            Condition.condition2Other = " where (  Traffic2.source like '169.6.2.%' or Traffic2.source like 169.5.20.%' ) ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2Other
                       //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.conditionOther
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 0.8 and sum(流量) < ClientInfo.Traffic  and State <> '关停' and State <> '忽略' and ( ClientInfo.ClientName  like '迪卡侬%' or ClientInfo.ClientName like '%法因图尔%' )  ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;
                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控系统\" <notification@ctsig.com>");//发件人
                    mmsg.To.Add(MailAddress);//收件人
                    mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add("cwt@fashion-tele.com,zhuyj@fashion-tele.com,noc@fashion-tele.com");//暗抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月已达到套餐流量的80%！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>80%</b>，请知晓！！"
                              + "<br><br><br>"
                              + time3 + ", your number " + card + " has <b>" + Traffictotal + "MB</b>" + " data access of the package this month,out of which you have already used <b>" + Trafficuse + "MB</b>" + ",exceeding<b>80%</b>of the total data of the package."
                              + "<br><br><br>";
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "monitor@fashion-tele.com");//发件人邮箱信息
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "Feixin123!");//密码
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent3(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.conditionOther = " where (  Traffic.source like '169.6.2.%' or Traffic.source like 169.5.20.%' ) ";
            Condition.condition2Other = " where (  Traffic2.source like '169.6.2.%' or Traffic2.source like 169.5.20.%' ) ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2Other
                       //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.conditionOther
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 0.6 and sum(流量) < ClientInfo.Traffic * 0.8 and State <> '关停' and State <> '忽略' and ( ClientInfo.ClientName  like '迪卡侬%' or ClientInfo.ClientName like '%法因图尔%' )  ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控系统\" <notification@ctsig.com>");//发件人
                    mmsg.To.Add(MailAddress);//收件人
                    mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add("cwt@fashion-tele.com,zhuyj@fashion-tele.com,noc@fashion-tele.com" );//暗抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月已达到套餐流量的60%！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>60%</b>，请知晓！！"
                              + "<br><br><br>"
                              + time3 + ", your number " + card + " has <b>" + Traffictotal + "MB</b>" + " data access of the package this month,out of which you have already used <b>" + Trafficuse + "MB</b>" + ",exceeding<b>60%</b>of the total data of the package."
                              + "<br><br><br>";
                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent4(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.conditionOther = " where (  Traffic.source like '169.6.2.%' or Traffic.source like 169.5.20.%' ) ";
            Condition.condition2Other = " where (  Traffic2.source like '169.6.2.%' or Traffic2.source like 169.5.20.%' ) ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2Other
                       //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.conditionOther
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic * 0.5 and sum(流量) < ClientInfo.Traffic * 0.6 and State <> '关停' and State <> '忽略' and ( ClientInfo.ClientName  like '迪卡侬%' or ClientInfo.ClientName like '%法因图尔%' )  ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控系统\" <notification@ctsig.com>");//发件人
                    mmsg.To.Add(MailAddress);//收件人
                    mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add("cwt@fashion-tele.com,zhuyj@fashion-tele.com,noc@fashion-tele.com");//暗抄送人

                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月已使用套餐流量的50%！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>50%</b>，请知晓！！"
                              + "<br><br><br>"
                              + time3 + ", your number " + card + " has <b>" + Traffictotal + "MB</b>" + " data access of the package this month,out of which you have already used <b>" + Trafficuse + "MB</b>" + ",exceeding<b>50%</b>of the total data of the package."
                              + "<br><br><br>";
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "monitor@fashion-tele.com");//发件人邮箱信息
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "Feixin123!");//密码
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent5(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.conditionOther = " where (  Traffic.source like '169.6.2.%' or Traffic.source like 169.5.20.%' ) ";
            Condition.condition2Other = " where (  Traffic2.source like '169.6.2.%' or Traffic2.source like 169.5.20.%' ) ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2Other
                       //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.conditionOther
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.AutoClose, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic   and State <> '关停' and State <> '忽略' and ClientInfo.AutoClose = '否' and ( ClientInfo.ClientName  like '迪卡侬%' or ClientInfo.ClientName like '%法因图尔%' )  ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控系统\" <notification@ctsig.com>");//发件人
                    mmsg.To.Add(MailAddress);//收件人
                    mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add("cwt@fashion-tele.com,zhuyj@fashion-tele.com,noc@fashion-tele.com");//暗抄送人

                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月套餐流量已用尽！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>"  + "，本月套餐流量已用尽！！"
                              + "<br><br><br>"
                              + time3 + ", your number " + card + " has <b>" + Traffictotal + "MB</b>" + " data access of the package this month. The data has been finished this month！！"
                              + "<br><br><br>";
                    

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
            
            
        }

        public void OnTimedEvent10(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;

            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            #endregion

            Condition.conditionOther = " where (  Traffic.source like '169.6.2.%' or Traffic.source like 169.5.20.%' ) ";
            Condition.condition2Other = " where (  Traffic2.source like '169.6.2.%' or Traffic2.source like 169.5.20.%' ) ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
                       + " select source ,sum(traffic) as 流量  "
                       + " from Traffic2 "
                       + Condition.condition2Other
                    //+ " and Traffic2.date >= '2016-8-1 00:00:00.000' and Traffic2.date <= '2016-8-31 00:00:00.000' ";
                       + " and Traffic2.date >= '" + strStart + "' and Traffic2.date <= '" + strEnd + "' ";



                sqlEK += string.Format("  group by source ")
                    + " union "
                    + " select source ,sum(traffic) as 流量 "
                    + " from Traffic "
                    + Condition.conditionOther
                    //+ " and Traffic.date >= '2016-8-1 00:00:00.000' and Traffic.date <= '2016-8-31 00:00:00.000' ";
                    + " and Traffic.date >= '" + strStart + "' and Traffic.date <= '" + strEnd + "' ";


                sqlEK += string.Format("  group by source ")
                    + " )Traffic2 inner join ClientInfo  ON source = IP "
                        + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.AutoClose, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
                    + " >= ClientInfo.Traffic   and State <> '关停' and State <> '忽略' and ClientInfo.AutoClose = '是' and ( ClientInfo.ClientName  like '迪卡侬%' or ClientInfo.ClientName like '%法因图尔%' )  ";
                sqlEK += " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["source"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控系统\" <notification@ctsig.com>");//发件人
                    mmsg.To.Add(MailAddress);//收件人
                    mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add("cwt@fashion-tele.com,zhuyj@fashion-tele.com,noc@fashion-tele.com");//暗抄送人

                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月套餐流量已用尽，现已被系统自动关停！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + "，本月套餐流量已用尽，现已被系统自动关停！！"
                              + "<br><br><br>"
                              + time3 + ", your number " + card + " has <b>" + Traffictotal + "MB</b>" + " data access of the package this month. The data has been finished this month, your number will be stopped service by system automatically！！"
                              + "<br><br><br>";


                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }


        }










        public void OnTimedEvent6(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;


            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
            #endregion

            Condition.condition = " and  (  IP like '169.6.2.%' or IP like '169.5.20.%' )  ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  ClientName, IP, Card, CardType, Traffic, MailAddress, MailAddressCC,State, sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State  "
                         + " having sum(total) >= Traffic * 0.8 and  sum(total) < Traffic   and ClientName not like '%闲置%'  and IP is not Null and State <> '关停' and State <> '忽略' and ( ClientName  like '迪卡侬%' or ClientName like '%法因图尔%')  "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;
                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控系统\" <notification@ctsig.com>");//发件人
                    mmsg.To.Add(MailAddress);//收件人
                    mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add("cwt@fashion-tele.com,zhuyj@fashion-tele.com,noc@fashion-tele.com");//暗抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月已达到套餐流量的80%！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>80%</b>，请知晓！！"
                              + "<br><br><br>"
                              + time3 + ", your number " + card + " has <b>" + Traffictotal + "MB</b>" + " data access of the package this month,out of which you have already used <b>" + Trafficuse + "MB</b>" + ",exceeding<b>80%</b>of the total data of the package."
                              + "<br><br><br>";
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "monitor@fashion-tele.com");//发件人邮箱信息
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "Feixin123!");//密码
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent7(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;


            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
            #endregion

            Condition.condition = " and  (  IP like '169.6.2.%' or IP like '169.5.20.%' )  ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  ClientName, IP, Card, CardType, Traffic, MailAddress, MailAddressCC,State, sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State  "
                         + " having sum(total) >= Traffic * 0.6 and sum(total) < Traffic * 0.8  and ClientName not like '%闲置%'  and IP is not Null and State <> '关停' and State <> '忽略' and ( ClientName  like '迪卡侬%' or ClientName like '%法因图尔%')  "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控系统\" <notification@ctsig.com>");//发件人
                    mmsg.To.Add(MailAddress);//收件人
                    mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add("cwt@fashion-tele.com,zhuyj@fashion-tele.com,noc@fashion-tele.com");//暗抄送人
                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月已达到套餐流量的60%！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>60%</b>，请知晓！！"
                              + "<br><br><br>"
                              + time3 + ", your number " + card + " has <b>" + Traffictotal + "MB</b>" + " data access of the package this month,out of which you have already used <b>" + Trafficuse + "MB</b>" + ",exceeding<b>60%</b>of the total data of the package."
                              + "<br><br><br>";
                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent8(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;


            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
            #endregion

            Condition.condition = " and  (  IP like '169.6.2.%' or IP like '169.5.20.%' )  ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  ClientName, IP, Card, CardType, Traffic, MailAddress, MailAddressCC,State, sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State  "
                         + " having sum(total) >= Traffic * 0.5 and sum(total) < Traffic * 0.6  and ClientName not like '%闲置%'  and IP is not Null and State <> '关停' and State <> '忽略' and ( ClientName  like '迪卡侬%' or ClientName like '%法因图尔%')  "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控系统\" <notification@ctsig.com>");//发件人
                    mmsg.To.Add(MailAddress);//收件人
                    mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add("cwt@fashion-tele.com,zhuyj@fashion-tele.com,noc@fashion-tele.com");//暗抄送人

                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月已使用套餐流量的50%！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>50%</b>，请知晓！！"
                              + "<br><br><br>"
                              + time3 + ", your number " + card + " has <b>" + Traffictotal + "MB</b>" + " data access of the package this month,out of which you have already used <b>" + Trafficuse + "MB</b>" + ",exceeding<b>50%</b>of the total data of the package."
                              + "<br><br><br>";
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "monitor@fashion-tele.com");//发件人邮箱信息
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "Feixin123!");//密码
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器
                    //SmtpMail.SmtpServer = "smtp.fashion-tele.com";//指定smtp服务器

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        public void OnTimedEvent9(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;


            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
            #endregion

            Condition.condition = " and  (  IP like '169.6.2.%' or IP like '169.5.20.%' )  ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  ClientName, IP, Card, CardType, Traffic, MailAddress, MailAddressCC,State, sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " group by ClientName,CardType,AutoClose,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State  "
                         + " having sum(total) >= Traffic  and ClientName not like '%闲置%' and AutoClose = '否' and IP is not Null and State <> '关停' and State <> '忽略' and ( ClientName  like '迪卡侬%' or ClientName like '%法因图尔%')  "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控系统\" <notification@ctsig.com>");//发件人
                    mmsg.To.Add(MailAddress);//收件人
                    mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add("cwt@fashion-tele.com,zhuyj@fashion-tele.com,noc@fashion-tele.com");//暗抄送人

                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月套餐流量已用尽！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，本月套餐流量已用尽！！"
                              + "<br><br><br>"
                              + time3 + ", your number " + card + " has <b>" + Traffictotal + "MB</b>" + " data access of the package this month. The data has been finished this month！！"
                              + "<br><br><br>";


                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }


        }

        public void OnTimedEvent11(object source, System.Timers.ElapsedEventArgs e)
        {

            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int ihour12 = 00;
            int iminute12 = 20;
            int iminute = 10;
            int ihour = 12;


            #region     周期计算
            string strStartYear = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strStart = e.SignalTime.AddDays(1 - e.SignalTime.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
            string strEnd = e.SignalTime.AddDays(1 - e.SignalTime.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
            #endregion

            Condition.condition = " and  (  IP like '169.6.2.%' or IP like '169.5.20.%' )  ";

            if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select  ClientName, IP, Card, CardType, Traffic, MailAddress, MailAddressCC,State, sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.condition
                       + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";



                sqlEK += " group by ClientName,CardType,AutoClose,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State  "
                         + " having sum(total) >= Traffic  and ClientName not like '%闲置%' and AutoClose = '是' and IP is not Null and State <> '关停' and State <> '忽略' and ( ClientName  like '迪卡侬%' or ClientName like '%法因图尔%')  "
                         + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string source1 = myReader["IP"].ToString();
                    string card = myReader["Card"].ToString();
                    string Traffictotal = myReader["Traffic"].ToString();
                    string Trafficuse = myReader["流量"].ToString();
                    string MailAddress = myReader["MailAddress"].ToString();
                    string MailAddressCC = myReader["MailAddressCC"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");
                    string time1 = System.DateTime.Now.ToString("HH");
                    string time2 = System.DateTime.Now.ToString("MMMM dd ", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    string time3 = "By " + time1 + " o'clock on " + time2;

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    decimal dectraffictotal = decimal.Parse(Traffictotal);
                    decimal dectrafficuse = decimal.Parse(Trafficuse);
                    decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"CTG-流量监控系统\" <notification@ctsig.com>");//发件人
                    mmsg.To.Add(MailAddress);//收件人
                    mmsg.CC.Add(MailAddressCC);//抄送人
                    mmsg.Bcc.Add("cwt@fashion-tele.com,zhuyj@fashion-tele.com,noc@fashion-tele.com");//暗抄送人

                    mmsg.IsBodyHtml = true;

                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月套餐流量已用尽，现已被系统自动关停！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，本月套餐流量已用尽，现已被系统自动关停！！"
                              + "<br><br><br>"
                              + time3 + ", your number " + card + " has <b>" + Traffictotal + "MB</b>" + " data access of the package this month. The data has been finished this month, your number will be stopped service by system automatically！！"
                              + "<br><br><br>";


                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "mail.ctsig.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("notification", "notification");
                    try
                    {
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }


        }
    }
}
