﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using Newtonsoft.Json;
using System.Net;
using System.Threading;
using System.Security.Cryptography;
using System.Net.Mail;

namespace WindowsServiceAutoCardTime
{
    public partial class Service1 : ServiceBase
    {
        //定时器  
        System.Timers.Timer t1 = null;
        //System.Timers.Timer t2 = null;

        //定义全局变量类Condition，其中的condition
        class Condition
        {
            //用来把sql语句赋值给下面的全局变量

            public static string conditionOther = "";
            public static string condition2Other = "";
        }

        public Service1()
        {
            InitializeComponent();
            //启用暂停恢复  
            base.CanPauseAndContinue = true;

            t1 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            t1.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent1);
            t1.AutoReset = true;
            t1.Enabled = true;

            //t2 = new System.Timers.Timer(60000);  //间隔1分钟运行一次
            //t2.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent2);
            //t2.AutoReset = true;
            //t2.Enabled = true;
        }

        protected override void OnStart(string[] args)
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "启动";
            WriteLog(state);
        }

        //停止服务执行  
        protected override void OnStop()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "停止";
            WriteLog(state);
        }

        //恢复服务执行  
        protected override void OnContinue()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "继续";
            WriteLog(state);
            t1.Start();
            //t2.Start();
        }

        //暂停服务执行  
        protected override void OnPause()
        {
            string state = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "暂停";
            WriteLog(state);
            t1.Stop();
            //t2.Stop();
        }

        public void WriteLog(string str)
        {
            using (StreamWriter sw = File.AppendText(@"d:\AutoCardTime.txt"))
            {
                sw.WriteLine(str);
                sw.Flush();
            }
        }

        public void OnTimedEvent1(object source, System.Timers.ElapsedEventArgs e)
        {
            int inthour = e.SignalTime.Hour;
            int intminute = e.SignalTime.Minute;
            int iminute = 00;
            int ihour = 7;


            Condition.conditionOther = " where (IP like '10.32%' or IP like '10.255.217.251%' or IP like '10.255.217.255%' or IP like '172.16%'  or IP like '169.%' or IP like '10.3%' or IP like '130.130.1%' or IP like '192.168.254.%' ) ";
            Condition.condition2Other = " where (IP like '10.32%' or IP like '10.255.217.251%' or IP like '10.255.217.255%' or IP like '172.16%'  or IP like '169.%' or IP like '10.3%' or IP like '130.130.1%' or IP like '192.168.254.%' ) ";

            if (inthour == ihour && intminute == iminute )
            {
                //定义连接字符串
                string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
                SqlConnection conn = new SqlConnection(strconn);
                conn.Open();

                string sqlEK = " select datediff(day,OutDate,getdate()) as 使用天数,ClientName, IP, Card, Outdate,State  from ClientInfo  "
                   + Condition.conditionOther
                   + " and State <> '关停' and State <> '忽略' and ClientName <> '闲置在库' and Property = '包年' and datediff(day,Outdate,getdate()) >= 360 and datediff(day,Outdate,getdate()) <= 364 ";
                sqlEK += "  order by 使用天数 DESC ";


                SqlCommand cmd = new SqlCommand(sqlEK, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    string client = myReader["ClientName"].ToString();
                    string CardTime = myReader["使用天数"].ToString();
                    string card = myReader["Card"].ToString();
                    string State = myReader["State"].ToString();
                    //定义告警日期
                    string time = System.DateTime.Now.ToString("MM月dd日HH时");

                    /////////////////把流量字符转换为数字型，进行计算////////////
                    //decimal dectraffictotal = decimal.Parse(Traffictotal);
                    //decimal dectrafficuse = decimal.Parse(Trafficuse);
                    //decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
                    /////////////////////////////////////////////////////////////

                    MailMessage mmsg = new MailMessage();//实例一个mailmessage
                    mmsg.Priority = MailPriority.Normal;//设置优先级别
                    mmsg.From = new MailAddress("\"3G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
                    mmsg.To.Add("sales1@fashion-tele.com,business@fashion-tele.com");//收件人
                    mmsg.CC.Add("service@fashion-tele.com,noc@fashion-tele.com");//抄送人
                    mmsg.IsBodyHtml = true;
                    mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 的包年卡，从开通日起已经使用了" + CardTime + " 天，马上将被系统自动关停，请相关部门及时续费并调整出库日期！！！";
                    mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 的包年卡，从开通日起已经使用了 <b>" + CardTime + " 天</b> ，周期满1年后将被系统自动关停，请相关部门核对出库日期是否有误，并及时续费调整出库日期，以免此卡被自动关停影响用户使用！！！"
                              + "<br><br>";
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "nocmonitor@fashon-crop.com");//发件人邮箱信息
                    //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "ihz49DXj5Lx5F3sj");//密码
                    //SmtpMail.SmtpServer = "smtp.exmail.qq.com";//指定smtp服务器

                    SmtpClient smtpclient = new SmtpClient();
                    smtpclient.Host = "smtp.exmail.qq.com";
                    smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
                    try
                    {
                        //SmtpMail.Send(mmsg);//发送邮件
                        smtpclient.Send(mmsg);

                    }
                    catch (Exception ex)
                    {
                        WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
                    }
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
            }
        }

        //public void OnTimedEvent2(object source, System.Timers.ElapsedEventArgs e)
        //{

        //    int inthour = e.SignalTime.Hour;
        //    int intminute = e.SignalTime.Minute;
        //    int ihour12 = 00;
        //    int iminute12 = 20;
        //    int iminute = 10;
        //    int ihour = 12;

        //    Condition.conditionOther = " where (Traffic.source like '169.7.8.%' or Traffic.source like '169.6.2.%'  ) ";
        //    Condition.condition2Other = " where (Traffic2.source like '169.7.8.%' or Traffic2.source like '169.6.2.%'  ) ";

        //    if ((inthour == ihour && intminute == iminute) || (inthour == ihour12 && intminute == iminute12))
        //    {
        //        //定义连接字符串
        //        string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
        //        SqlConnection conn = new SqlConnection(strconn);
        //        conn.Open();

        //        string sqlEK = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State, sum(流量) as 流量 from ("
        //               + " select source ,sum(traffic) as 流量  "
        //               + " from Traffic2 "
        //               + Condition.condition2Other
        //               + " and Traffic2.date >= '2016-5-1 00:00:00.000' and Traffic2.date <= '2016-5-31 00:00:00.000' ";




        //        sqlEK += string.Format("  group by source ")
        //            + " union "
        //            + " select source ,sum(traffic) as 流量 "
        //            + " from Traffic "
        //            + Condition.conditionOther
        //            + " and Traffic.date >= '2016-5-1 00:00:00.000' and Traffic.date <= '2016-5-31 00:00:00.000' ";



        //        sqlEK += string.Format("  group by source ")
        //            + " )Traffic2 inner join ClientInfo  ON source = IP "
        //                + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic, MailAddress, MailAddressCC, State  having sum(流量) "
        //            + " >= ClientInfo.Traffic * 0.8 and sum(流量) < ClientInfo.Traffic  and State <> '关停' and State <> '忽略' and ClientInfo.ClientName  like '%ctg%'  ";
        //        sqlEK += " order by 流量 DESC ";

        //        SqlCommand cmd = new SqlCommand(sqlEK, conn);
        //        cmd.ExecuteNonQuery();
        //        SqlDataReader myReader = cmd.ExecuteReader();
        //        while (myReader.Read())
        //        {
        //            string client = myReader["ClientName"].ToString();
        //            string source1 = myReader["source"].ToString();
        //            string card = myReader["Card"].ToString();
        //            string Traffictotal = myReader["Traffic"].ToString();
        //            string Trafficuse = myReader["流量"].ToString();
        //            string MailAddress = myReader["MailAddress"].ToString();
        //            string MailAddressCC = myReader["MailAddressCC"].ToString();
        //            string State = myReader["State"].ToString();
        //            //定义告警日期
        //            string time = System.DateTime.Now.ToString("MM月dd日HH时");

        //            /////////////////把流量字符转换为数字型，进行计算////////////
        //            decimal dectraffictotal = decimal.Parse(Traffictotal);
        //            decimal dectrafficuse = decimal.Parse(Trafficuse);
        //            decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
        //            /////////////////////////////////////////////////////////////

        //            MailMessage mmsg = new MailMessage();//实例一个mailmessage
        //            mmsg.Priority = MailPriority.Normal;//设置优先级别
        //            mmsg.From = new MailAddress("\"3G流量监控系统\" <nocmonitor@fashon-crop.com>");//发件人
        //            mmsg.To.Add("cocoli@chinatelecomglobal.com");//收件人
        //            mmsg.Bcc.Add("service@fashion-tele.com,noc@fashion-tele.com," + MailAddressCC);//暗抄送人
        //            mmsg.IsBodyHtml = true;

        //            mmsg.Subject = "尊敬的" + client + "：截止" + time + "，卡号为 " + card + " 本月已使用套餐流量的百分之80，马上将要超过套餐流量！！";
        //            mmsg.Body = "尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 <b>" + Traffictotal + "MB</b>" + " ，现已使用 <b>" + Trafficuse + "MB</b>" + "，已达到套餐流量的<b>百分之80</b>，马上将要超过套餐流量！！"
        //                      + "<br><br>";
        //            //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", 1);
        //            //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", "nocmonitor@fashon-crop.com");//发件人邮箱信息
        //            //mmsg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", "ihz49DXj5Lx5F3sj");//密码
        //            //SmtpMail.SmtpServer = "smtp.exmail.qq.com";//指定smtp服务器
        //            //SmtpMail.SmtpServer = "smtp.exmail.qq.com";//指定smtp服务器

        //            SmtpClient smtpclient = new SmtpClient();
        //            smtpclient.Host = "smtp.exmail.qq.com";
        //            smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
        //            smtpclient.Credentials = new System.Net.NetworkCredential("nocmonitor@fashon-crop.com", "ihz49DXj5Lx5F3sj");
        //            try
        //            {
        //                smtpclient.Send(mmsg);

        //            }
        //            catch (Exception ex)
        //            {
        //                WriteLog("theout:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ex.Message);
        //            }
        //        }
        //        myReader.Dispose();
        //        myReader.Close();
        //        conn.Close();
        //    }
        //}

        
        
    }
}
