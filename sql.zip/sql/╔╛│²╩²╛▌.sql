--select * from Traffic2 where source = '169.1.53.190'
--and date <= '2016-12-1'
--
--delete from Traffic2 where source = '169.6.12.5'
--and date <= '2017-6-27'

select * from TrafficL2 where users = 'ruanyinA111'
and date <= '2017-8-8'
delete from TrafficL2 where users = 'ruanyinA111'
and date <= '2017-8-8'

select * from ClientInfo
where ClientName like '%�����%'
