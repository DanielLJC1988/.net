--select * from TrafficL2 a
--where (a.date,a.total) in  
--(select date,total from TrafficL2  group by date,total  
--having count(*) > 1)
--and users = '8614540721241'

Select date,total,Count(*) From TrafficL2 Group By date,total ,users
Having Count(*) > 1 and users = '8614540721241'
order by date