SELECT subject from test
where DATEDIFF(mi,time,getdate()) <= 120
and subject in (select subject from test group by subject having count(1) >= 5)
group by subject

select id from  test where id  in (4,6,9,10)

