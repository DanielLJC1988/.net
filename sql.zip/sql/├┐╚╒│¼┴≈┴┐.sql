


 select  ClientName, IP, Card,  CardType, Traffic, MailAddress, MailAddressCC,State, sum(total) as ���� from TrafficL2 
  inner join ClientInfo  ON L2user = TrafficL2.users  
 and  ( IP like '169.7.14.%'  )
and date >= '2017-01-17 00:00:00' and date <= '2017-01-17 23:59:00' 
group by ClientName,CardType,IP,Card,TrfficType,Traffic,MailAddress,MailAddressCC,State  
 having sum(total) >= Traffic / 30  and sum(total) < Traffic * 2 / 30  and CardType = '4G��' and State <> '��ͣ' and IP is not Null  and State <> '����' and ClientName not like '%ctg%'  and ClientName not like '%�����ڿ�%' 
 order by ���� DESC 


