


--����������λΪMB
--update ����1 set traffic = traffic / 1024 
--where traffic > 100
--
--update ����2 set traffic = traffic / 1024 
--where traffic > 100


--����������
--insert into Traffic(date,source,traffic)
--select date,source,traffic from ����1
--
--insert into Traffic2(date,source,traffic)
--select date,source,traffic from ����2



--����ͼ��ѯ���

select top 50 ClientInfo.Card,Traffic2.source,ClientInfo.Traffic,Property,sum(����) as ���� from (
select source ,sum(traffic) as ���� 
from Traffic2 
where (Traffic2.source like '10.32%' or Traffic2.source like '172.16%'  or Traffic2.source like '169.1.%' or Traffic2.source like '169.5.%' or Traffic2.source like '169.7.%' or Traffic2.source like '10.3%' or Traffic2.source like '130.130.1%' or Traffic2.source like '192.168.254.10' ) 
and Traffic2.date >= '2015-8-1 00:00:00.000' and Traffic2.date <= '2015-8-31 00:00:00.000'
group by source
union
select source ,sum(traffic) as ����
from Traffic 
where (Traffic.source like '10.32%' or Traffic.source like '172.16%'  or Traffic.source like '169.1.%' or Traffic.source like '169.5.%' or Traffic.source like '169.7.%' or Traffic.source like '10.3%' or Traffic.source like '130.130.1%' or Traffic.source like '192.168.254.10' )
and Traffic.date >= '2015-8-1 00:00:00.000' and Traffic.date <= '2015-8-31 00:00:00.000'
group by  source
) Traffic2 inner join ClientInfo  ON source = IP 
group by Traffic2.source ,ClientInfo.Card ,ClientInfo.Traffic,Property
--having sum(����) > ClientInfo.Traffic
having Property = '����'
order by ���� DESC





select  Traffic2.date,OutDate,ClientInfo.Card,ClientInfo.OperatorType,ClientInfo.ClientName,Traffic2.source,TrfficType,MAXTrfficType,State,sum(����) as ���� from (
select Traffic2.date,Traffic2.source ,sum(Traffic2.traffic) as ���� 
from Traffic2
where (Traffic2.source like '169.1.53%' )
and Traffic2.date = '2015-3-13 00:00:00.000'
group by Traffic2.source,Traffic2.date
union
select Traffic.date,Traffic.source ,sum(Traffic.traffic) as ����
from Traffic
where (Traffic.source like '169.1.53%' )
and Traffic.date = '2015-3-13 00:00:00.000'
group by  Traffic.source,Traffic.date
)Traffic2 inner join ClientInfo  ON source = IP  and ClientInfo.ClientName = '�����ղ�ͨ��' 
group by Traffic2.source,Traffic2.date,ClientInfo.Card,ClientInfo.OperatorType,ClientInfo.ClientName,OutDate,TrfficType,MAXTrfficType,State
order by ���� DESC


--��������������ѯ
select sum(����) as ���� from (
                        select source ,sum(traffic) as ���� 
                         from Traffic2 
                         where (Traffic2.source like '10.32%' or Traffic2.source like '172.16%'  or Traffic2.source like '169.1.31%' or Traffic2.source like '169.1.46%' or Traffic2.source like '169.1.255%' or Traffic2.source like '169.1.41%' or Traffic2.source like '169.1.43%' or Traffic2.source like '169.1.45%' or Traffic2.source like '169.1.47%' or Traffic2.source like '169.1.48%' or Traffic2.source like '169.1.49%' or Traffic2.source like '169.1.50%' or Traffic2.source like '169.1.51%' or Traffic2.source like '169.1.53%' or Traffic2.source like '169.1.56%' or Traffic2.source like '10.3%' or Traffic2.source like '169.1.57%') 

                         and (Traffic2.date >= '2014-12-01' and Traffic2.date <= '2014-12-31') group by source 
                         union 
                         select Traffic.source ,sum(Traffic.traffic) as ���� 
                         from Traffic 
                         where (Traffic.source like '10.32%' or Traffic.source like '172.16%'  or Traffic.source like '169.1.31%' or Traffic.source like '169.1.46%' or Traffic.source like '169.1.255%' or Traffic.source like '169.1.41%' or Traffic.source like '169.1.43%' or Traffic.source like '169.1.45%' or Traffic.source like '169.1.47%' or Traffic.source like '169.1.48%' or Traffic.source like '169.1.49%' or Traffic.source like '169.1.50%' or Traffic.source like '169.1.51%' or Traffic.source like '169.1.53%' or Traffic.source like '169.1.56%' or Traffic.source like '10.3%' or Traffic.source like '169.1.57%') 

                         and (Traffic.date >= '2014-12-01' and Traffic.date <= '2014-12-31') 
                         group by source 
                         )Traffic2 left join ClientInfo  ON source = IP  where ClientInfo.Card  like '106%' 
                        order by ���� DESC 




--����������λΪMB
--update ����1 set traffic = traffic / 1024 
--where traffic > 100
--
--update ����2 set traffic = traffic / 1024 
--where traffic > 100


--����������
--insert into TrafficCosta(date,source,destination,traffic)
--select date,source,destination,traffic from ����1
--
--insert into TrafficCosta2(date,source,destination,traffic)
--select date,source,destination,traffic from ����2



--costa�Ĳ�ѯ��������������������
select  ClientInfo.Card,TrafficCosta2.source,sum(����) as ���� from (
select source ,sum(traffic)  as ���� 
from TrafficCosta2 
where TrafficCosta2.source like '192.168.254.10' 
and TrafficCosta2.date >= '2014-12-30 00:00:00.000'
group by source
union
select source ,sum(traffic) as ����
from TrafficCosta 
where (TrafficCosta.destination like '192.168.254.10' )
and TrafficCosta.date >= '2014-12-30 00:00:00.000'
group by  source
) TrafficCosta2 left join ClientInfo  ON source = IP   
group by TrafficCosta2.source ,ClientInfo.Card
order by ���� DESC



---------------------�������������ܺ�---------------------
select sum(traffic) as ���� from TrafficCosta
where source = '192.168.254.10' and destination like '10%' 


select sum(traffic) as ���� from TrafficCosta
where destination = '192.168.254.10' and source like '10%'
-----------------------------------------------------------


---------------------��������������ܺ�---------------------
select sum(traffic) as ���� from TrafficCosta
where source = '192.168.254.10' and destination not like '10%'


select sum(traffic) as ���� from TrafficCosta
where destination = '192.168.254.10' and source not like '10%'
-----------------------------------------------------------


--select dfdf = sum( select traffic  from TrafficCosta where source = '192.168.254.10' and destination like '10%' ) 
--            + sum( select traffic  from TrafficCosta where source = '192.168.254.10' and destination like '10%')
--from TrafficCosta

--����ʼ������
--select * from aaa where ClientName is null
--delete aaa where ClientName is null
--insert into ClientInfo(ClientName,InDate,CardType,OperatorType,TrfficType,Operator,IP,Card,IMSI,ICCID,PackageContent,Traffic,OutDate,ContractNo,users,memo)
--select ClientName,InDate,CardType,OperatorType,TrfficType,Operator,IP,Card,IMSI,ICCID,PackageContent,Traffic,OutDate,ContractNo,users,memo
-- from aaa

--���ݻָ�����
--insert into TrafficL2(date,users,total)
--select date,users,total
--from bbb

--�������IP��ַ���--
select IPAddress from IPTable
left join ClientInfo on IP = IPAddress
where IP is null
order by convert(numeric(20),replace(IPAddress,'.',''))


-----�������Ӱ�Ѳ������������---------
select  ClientInfo.ClientName,ClientInfo.Card,Traffic2.source,ClientInfo.Traffic,MAXTraffic,State,sum(����) as ���� from (
select source ,sum(traffic) as ���� 
from Traffic2 
where (Traffic2.source like '169.1.63%' )
and Traffic2.date >= '2015-1-01 00:00:00.000' and Traffic2.date <= '2015-12-31 00:00:00.000'
group by source
union
select source ,sum(traffic) as ����
from Traffic 
where (Traffic.source like '169.1.63%' )
and Traffic.date >= '2015-1-01 00:00:00.000' and Traffic.date <= '2015-12-30 00:00:00.000'
group by  source
) Traffic2 inner join ClientInfo  ON source = IP  
group by Traffic2.source ,ClientInfo.Card ,ClientInfo.Traffic,ClientInfo.ClientName,MAXTraffic,State
having sum(����) <> 0
order by ���� DESC
------------------------------------------------


-------����ÿ�³�����ͳ�����--------
 select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic,State, sum(����) as ���� from (
select source ,sum(traffic) as ����  
from Traffic2 
 where (Traffic2.source like  '169.1.53%' )
 and Traffic2.date >= '2015-4-1 00:00:00.000' and Traffic2.date <= '2015-4-30 00:00:00.000' 
group by source 
union 
 select source ,sum(traffic) as ���� 
from Traffic 
 where (Traffic.source like  '169.1.53%' )
 and Traffic.date >= '2015-4-1 00:00:00.000' and Traffic.date <= '2015-4-30 00:00:00.000' 
 group by source 
 ) Traffic2 inner join ClientInfo  ON source = IP 
group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic,State having sum(����) 
 >= ClientInfo.Traffic  
order by ���� DESC 
-----------------------------------



--------------------���꿨�Ʒ�����----------------------------------------------------
select datediff(day,OutDate,getdate()) as aaa,* from ClientInfo
where datediff(day,Outdate,getdate()) > 1 and Property = '����' and IP like '169.1.53.%'
order by datediff(day,Outdate,getdate())
---------------------------------------------------------------------------------------