select Card,* from ClientInfo 
where MailAddressCC like '%/;%'   ESCAPE   '/'