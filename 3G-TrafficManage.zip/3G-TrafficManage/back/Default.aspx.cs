﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class back_Default : System.Web.UI.Page
{
    //定义全局变量类Condition，其中的condition
    class Condition
    {
        //用来把sql语句赋值给下面的全局变量
        public static string condition = "";
        public static string condition2 = "";
    }

    //声明数据库
    string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";


    protected string username;
    protected string password;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (PreviousPage != null)
        {
            string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");

            TextBox pp_UserName;
            TextBox pp_Password;

            pp_UserName = ((TextBox)(PreviousPage.FindControl("TextBox1")));
            pp_Password = ((TextBox)(PreviousPage.FindControl("TextBox2")));

            username = pp_UserName.Text;
            password = pp_Password.Text;

            Session["loginname"] = username;
            Session["loginpsd"] = password;

            //定义角色
            string Role = "";
            //获取当前登陆用户IP
            string anonymity = Request.UserHostAddress;
            string anonymityHostName = Request.UserHostName;


            //定义连接字符串
            //string strconn = ConfigurationManager.ConnectionStrings["3GTrafficConnectionString"].ConnectionString;
            SqlConnection conn = new SqlConnection(strconn);

            string sql = "";

            if (Session["loginname"].ToString() == "admin" && Session["loginpsd"].ToString() == "fashion@123")
            {
                Role = "管理员";
                Session["loginname"] = Role;

                //写入数据库日志
                sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'登陆系统')", logtime, Role, anonymity);
                //打开数据库连接
                conn.Open();

                //创建command对象
                SqlCommand command = new SqlCommand(sql, conn);
                int result = command.ExecuteNonQuery();
                conn.Close();


                Response.Redirect("/web/TrafficLognew.aspx");
            }

            else if (Session["loginname"].ToString() == "service" && Session["loginpsd"].ToString() == "service@123")
            {
                Role = "客服部";
                Session["loginname"] = Role;

                //写入数据库日志
                sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'登陆系统')", logtime, Role, anonymity);
                //打开数据库连接
                conn.Open();

                //创建command对象
                SqlCommand command = new SqlCommand(sql, conn);
                int result = command.ExecuteNonQuery();
                conn.Close();


                Response.Redirect("/web/TrafficLognew.aspx");
            }

            else if (Session["loginname"].ToString() == "serviceadmin" && Session["loginpsd"].ToString() == "fxservice@123")
            {
                Role = "客服部管理员";
                Session["loginname"] = Role;

                //写入数据库日志
                sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'登陆系统')", logtime, Role, anonymity);
                //打开数据库连接
                conn.Open();

                //创建command对象
                SqlCommand command = new SqlCommand(sql, conn);
                int result = command.ExecuteNonQuery();
                conn.Close();


                Response.Redirect("/web/TrafficLognew.aspx");
            }

            else if (Session["loginname"].ToString() == "TECH" && Session["loginpsd"].ToString() == "tech@123")
            {
                Role = "技术部";
                Session["loginname"] = Role;

                //写入数据库日志
                sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'登陆系统')", logtime, Role, anonymity);
                //打开数据库连接
                conn.Open();

                //创建command对象
                SqlCommand command = new SqlCommand(sql, conn);
                int result = command.ExecuteNonQuery();
                conn.Close();


                Response.Redirect("/web/TrafficLognew.aspx");
            }

            else if (Session["loginname"].ToString() == "business" && Session["loginpsd"].ToString() == "business@123")
            {
                Role = "业务部";
                Session["loginname"] = Role;

                //写入数据库日志
                sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'登陆系统')", logtime, Role, anonymity);
                //打开数据库连接
                conn.Open();

                //创建command对象
                SqlCommand command = new SqlCommand(sql, conn);
                int result = command.ExecuteNonQuery();
                conn.Close();


                Response.Redirect("/web/TrafficLognew.aspx");
            }

            else if (Session["loginname"].ToString() == "softbank" && Session["loginpsd"].ToString() == "test@123")
            {
                Role = "软银";
                Session["loginname"] = Role;
                //Response.Redirect("/softbank/TrafficLog.aspx");

                //写入数据库日志
                sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'登陆系统')", logtime, Role, anonymity);
                //打开数据库连接
                conn.Open();

                //创建command对象
                SqlCommand command = new SqlCommand(sql, conn);
                int result = command.ExecuteNonQuery();
                conn.Close();


                Response.Redirect("/web/TrafficLognew.aspx");
            }


            else
            {
                //写入数据库日志
                sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','匿名用户 IP:' + '{1}'  ,'尝试登陆系统')", logtime, anonymity);
                //打开数据库连接
                conn.Open();

                //创建command对象
                SqlCommand command = new SqlCommand(sql, conn);
                int result = command.ExecuteNonQuery();
                conn.Close();
                //清除Session，弹出到登陆页面
                Session.Clear();
                Response.Write("<script languge='javascript'>alert('验证失败，请与管理员联系'); window.location.href='../Login.aspx'</script>");
            }
        }

    }

    #region  点击注销的事件
    protected void btnExit_Click(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'注销登陆')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }


        Session.Clear();
        Response.Write("<script languge='javascript'>alert('注销成功'); window.location.href='../Login.aspx'</script>");
    }
    #endregion

    #region 网页报错事件
    protected void Page_Error(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'网页报错弹出error页面')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }
    }
    #endregion
}
