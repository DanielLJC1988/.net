﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using Newtonsoft.Json;
using System.Net;

public partial class client_ClientCardAdd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    #region  点击注销的事件
    protected void btnExit_Click(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'注销登陆')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }


        Session.Clear();
        Response.Write("<script languge='javascript'>alert('注销成功'); window.location.href='../Login.aspx'</script>");
    }
    #endregion


    #region 网页报错事件
    protected void Page_Error(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'网页报错弹出error页面')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }
    }
    #endregion
}
