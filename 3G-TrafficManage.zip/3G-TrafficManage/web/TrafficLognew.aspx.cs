﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class web_TrafficLognew : System.Web.UI.Page
{
    //定义全局变量类Condition，其中的condition
    class Condition
    {
        //用来把sql语句赋值给下面的全局变量
        public static string condition = "";
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["loginname"] == null)
        {
            //Response.Redirect("/Login.aspx");
            //Response.Write("非法登陆，请重新登陆");

            Response.Write("<script languge='javascript'>alert('非法登陆，请重新登陆'); window.location.href='../Login.aspx'</script>");
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Calendar1.Visible = true;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Calendar2.Visible = true;
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        TextBox1.Text = Calendar1.SelectedDate.ToString("yyyy/MM/dd") + "  00:00:00.000";
        Calendar1.Visible = false;
    }
    protected void Calendar2_SelectionChanged(object sender, EventArgs e)
    {
        TextBox2.Text = Calendar2.SelectedDate.ToString("yyyy/MM/dd") + "  23:59:59.000";
        Calendar2.Visible = false;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        GridView2.DataBind();
        btnExport0.Visible = true;  //点击查询之后，弹出此button
        btnExport.Visible = false;  //点击查询之后，弹出此button

        string starttime = TextBox1.Text;
        string endtime = TextBox2.Text;
        string IP = TextBox3.Text;



        //判断身份，区分查询条件，没有权限则把此用户提出到登陆页面
        //if (Session["loginname"].ToString() == "")
        //{
        //    Response.Write("登陆超时，请重新登陆");
        //    Response.Redirect("/Login.aspx");
        //}

        if ((Session["loginname"].ToString() == "管理员") || (Session["loginname"].ToString() == "客服部") || (Session["loginname"].ToString() == "技术部") || (Session["loginname"].ToString() == "业务部") || (Session["loginname"].ToString() == "客服部管理员"))
        {
            Condition.condition = " and 1 = 1 ";
        }
        else
        {
            //清除Session，弹出到登陆页面
            Session.Clear();
            Response.Write("<script languge='javascript'>alert('权限不足无法查询数据，请与管理员联系'); window.location.href='../Login.aspx'</script>");
        }



        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add(new DataColumn("日期", typeof(string)));
        dt.Columns.Add(new DataColumn("开通日期", typeof(string)));
        dt.Columns.Add(new DataColumn("用户名称", typeof(string)));
        dt.Columns.Add(new DataColumn("IP", typeof(string)));
        dt.Columns.Add(new DataColumn("卡号", typeof(string)));
        dt.Columns.Add(new DataColumn("运营商", typeof(string)));
        dt.Columns.Add(new DataColumn("合同容量", typeof(string)));
        dt.Columns.Add(new DataColumn("状态", typeof(string)));
        dt.Columns.Add(new DataColumn("流量(MB)", typeof(string)));

        //定义连接字符串
        string strconn = ConfigurationManager.ConnectionStrings["3GTrafficConnectionString"].ConnectionString;
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();
        #region      //如果开始日期和结束日期都不为空并且日期相同
        if (!starttime.Equals("") && !endtime.Equals("") && (TextBox1.Text == TextBox2.Text))
        {


            string sql = " select   Card, ClientName, IP, OutDate, OperatorType, TrfficType, State, sum(total) as 流量 from TrafficL2 "
                   + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                   + Condition.condition;


                sql += string.Format(" and date >= '{0}' and date <= '{1}'  ", starttime, endtime);

                if (!IP.Equals(""))
                {
                    sql += string.Format(" and IP like '{0}%'  ", IP);
                }
                sql += " group by ClientName,CardType,OperatorType,IP,Card,L2user,OutDate,TrfficType,State "
                    +  " having CardType = '4G卡' or CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null "
                    +  " order by 流量 DESC ";


                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    dr = dt.NewRow();
                    //dr[0] = " ";

                    if (myReader["OutDate"] is DBNull)
                    {
                        dr[1] = myReader["OutDate"].ToString();
                    }
                    else
                    {
                        dr[1] = Convert.ToDateTime(myReader["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr[2] = myReader["ClientName"].ToString();
                    dr[3] = myReader["IP"].ToString();
                    dr[4] = myReader["Card"].ToString();
                    dr[5] = myReader["OperatorType"].ToString();
                    dr[6] = myReader["TrfficType"].ToString();
                    dr[7] = myReader["State"].ToString();
                    dr[8] = myReader["流量"].ToString();
                    dt.Rows.Add(dr);//把这一行插入到表格dt中
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
                GridView1.DataSource = new DataView(dt);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView1.DataBind();//绑定数据
            
            




        }
        #endregion


        #region  //其他情况不显示日期
        else
        {
             

                string sql = " select   Card, ClientName, IP, OutDate, OperatorType, TrfficType, State, sum(total) as 流量 from TrafficL2 "
                   + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                   + Condition.condition;

                if (!IP.Equals(""))
                {
                    sql += string.Format(" and IP like '{0}%'  ", IP);
                }

                if (starttime.Equals("") && endtime.Equals(""))    //没有输入日期
                {
                    sql += " group by ClientName,CardType,OperatorType,IP,Card,L2user,OutDate,TrfficType,State "
                    + " having CardType = '4G卡' or CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null "
                    + " order by 流量 DESC ";

                }

                else if (starttime.Equals("") && !endtime.Equals(""))    //输入了结束日期
                {


                    sql += string.Format(" and date <= '{0}'  ", endtime);

                    sql += " group by ClientName,CardType,OperatorType,IP,Card,L2user,OutDate,TrfficType,State "
                    +  " having CardType = '4G卡' or CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null "
                    +  " order by 流量 DESC ";
                }

                else if (!starttime.Equals("") && endtime.Equals(""))    //输入了开始日期，没有结束日期
                {
                    sql += string.Format(" and date >= '{0}'  ", starttime);

                    sql += " group by ClientName,CardType,OperatorType,IP,Card,L2user,OutDate,TrfficType,State "
                    +  " having CardType = '4G卡' or CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null "
                    +  " order by 流量 DESC ";



                }

                else if (!starttime.Equals("") && !endtime.Equals(""))    //输入了开始及结束日期
                {

                    sql += string.Format(" and date >= '{0}' and date <= '{1}'  ", starttime, endtime);

                    sql += " group by ClientName,CardType,OperatorType,IP,Card,L2user,OutDate,TrfficType,State "
                    +  " having CardType = '4G卡' or CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null "
                    +  " order by 流量 DESC ";
                    

                }


                conn.Close();
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    dr = dt.NewRow();
                    //dr[0] = myReader["date"].ToString().Substring(0, 10);
                    if (myReader["OutDate"] is DBNull)
                    {
                        dr[1] = myReader["OutDate"].ToString();
                    }
                    else
                    {
                        dr[1] = Convert.ToDateTime(myReader["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr[2] = myReader["ClientName"].ToString();
                    dr[3] = myReader["IP"].ToString();
                    dr[4] = myReader["Card"].ToString();
                    dr[5] = myReader["OperatorType"].ToString();
                    dr[6] = myReader["TrfficType"].ToString();
                    dr[7] = myReader["State"].ToString();
                    dr[8] = myReader["流量"].ToString();
                    dt.Rows.Add(dr);//把这一行插入到表格dt中
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
                GridView1.DataSource = new DataView(dt);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView1.DataBind();//绑定数据
            

            


        }
        #endregion





    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("ChartAnalyze.aspx");
    }


    #region 导出Excel
    protected void btnExport_Click(object sender, EventArgs e)
    {
        {
            //DateTime dt = System.DateTime.Now;
            //string str = dt.ToString("yyyyMMddhhmmss");

            Button4.Visible = true;
            btnExport0.Visible = false;
            GridView2.AllowPaging = false;

            string str = "Traffic";
            str = str + ".xls";

            GridViewToExcel(GridView2, "application/ms-excel", str);

            // Export(gvRecord, "application/ms-excel", str);



        }
    }

    /// <summary>
    /// 将网格数据导出到Excel
    /// </summary>
    /// <param name="ctrl">网格名称(如GridView1)</param>
    /// <param name="FileType">要导出的文件类型(Excel:application/ms-excel)</param>
    /// <param name="FileName">要保存的文件名</param>
    public static void GridViewToExcel(Control ctrl, string FileType, string FileName)
    {
        HttpContext.Current.Response.Charset = "GB2312";
        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.UTF8;//注意编码
        HttpContext.Current.Response.AppendHeader("Content-Disposition",
            "attachment;filename=" + HttpUtility.UrlEncode(FileName, System.Text.Encoding.UTF8).ToString());
        HttpContext.Current.Response.ContentType = FileType;//image/JPEG;text/HTML;image/GIF;vnd.ms-excel/msword
        ctrl.Page.EnableViewState = false;
        StringWriter tw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(tw);
        ctrl.RenderControl(hw);
        HttpContext.Current.Response.Write(tw.ToString());
        HttpContext.Current.Response.End();
    }

    public override void VerifyRenderingInServerForm(Control control)
    {

    }
    #endregion


    #region 分页功能
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        string starttime = TextBox1.Text;
        string endtime = TextBox2.Text;
        string IP = TextBox3.Text;

        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add(new DataColumn("日期", typeof(string)));
        dt.Columns.Add(new DataColumn("开通日期", typeof(string)));
        dt.Columns.Add(new DataColumn("用户名称", typeof(string)));
        dt.Columns.Add(new DataColumn("IP", typeof(string)));
        dt.Columns.Add(new DataColumn("卡号", typeof(string)));
        dt.Columns.Add(new DataColumn("运营商", typeof(string)));
        dt.Columns.Add(new DataColumn("合同容量", typeof(string)));
        dt.Columns.Add(new DataColumn("状态", typeof(string)));
        dt.Columns.Add(new DataColumn("流量(MB)", typeof(string)));

        //定义连接字符串
        string strconn = ConfigurationManager.ConnectionStrings["3GTrafficConnectionString"].ConnectionString;
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();
        #region      //如果开始日期和结束日期都不为空并且日期相同
        if (!starttime.Equals("") && !endtime.Equals("") && (TextBox1.Text == TextBox2.Text))
        {


            string sql = " select   Card, ClientName, IP, OutDate, OperatorType, TrfficType, State, sum(total) as 流量 from TrafficL2 "
                   + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                   + Condition.condition;


            sql += string.Format(" and date >= '{0}' and date <= '{1}'  ", starttime, endtime);

            if (!IP.Equals(""))
            {
                sql += string.Format(" and IP like '{0}%'  ", IP);
            }
            sql += " group by ClientName,CardType,OperatorType,IP,Card,L2user,OutDate,TrfficType,State "
                + " having CardType = '4G卡' or CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null "
                + " order by 流量 DESC ";


                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    dr = dt.NewRow();
                    //dr[0] = " ";

                    if (myReader["OutDate"] is DBNull)
                    {
                        dr[1] = myReader["OutDate"].ToString();
                    }
                    else
                    {
                        dr[1] = Convert.ToDateTime(myReader["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr[2] = myReader["ClientName"].ToString();
                    dr[3] = myReader["IP"].ToString();
                    dr[4] = myReader["Card"].ToString();
                    dr[5] = myReader["OperatorType"].ToString();
                    dr[6] = myReader["TrfficType"].ToString();
                    dr[7] = myReader["State"].ToString();
                    dr[8] = myReader["流量"].ToString();
                    dt.Rows.Add(dr);//把这一行插入到表格dt中
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
                GridView1.DataSource = new DataView(dt);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView1.DataBind();//绑定数据
            




        }
        #endregion


        #region  //其他情况不显示日期
        else
        {

            string sql = " select   Card, ClientName, IP, OutDate, OperatorType, TrfficType, State, sum(total) as 流量 from TrafficL2 "
               + " inner join ClientInfo  ON L2user = TrafficL2.users  "
               + Condition.condition;

            if (!IP.Equals(""))
            {
                sql += string.Format(" and IP like '{0}%'  ", IP);
            }

            if (starttime.Equals("") && endtime.Equals(""))    //没有输入日期
            {
                sql += " group by ClientName,CardType,OperatorType,IP,Card,L2user,OutDate,TrfficType,State "
                + " having CardType = '4G卡' or CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null "
                + " order by 流量 DESC ";

            }

                else if (starttime.Equals("") && !endtime.Equals(""))    //输入了结束日期
                {
                    sql += string.Format(" and date <= '{0}' ", endtime);

                    sql += " group by ClientName,CardType,OperatorType,IP,Card,L2user,OutDate,TrfficType,State "
                        + " having CardType = '4G卡' or CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null "
                        + " order by 流量 DESC ";

                }

                else if (!starttime.Equals("") && endtime.Equals(""))    //输入了开始日期，没有结束日期
                {
                    sql += string.Format(" and date >= '{0}'  ", starttime);

                    sql += " group by ClientName,CardType,OperatorType,IP,Card,L2user,OutDate,TrfficType,State "
                        + " having CardType = '4G卡' or CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null "
                        + " order by 流量 DESC ";


                }

                else if (!starttime.Equals("") && !endtime.Equals(""))    //输入了开始及结束日期
                {
                    sql += string.Format(" and date >= '{0}' and date <= '{1}'   ", starttime, endtime);

                    sql += " group by ClientName,CardType,OperatorType,IP,Card,L2user,OutDate,TrfficType,State "
                        + " having CardType = '4G卡' or CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null "
                        + " order by 流量 DESC ";


                }


                conn.Close();
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    dr = dt.NewRow();
                    //dr[0] = myReader["date"].ToString().Substring(0, 10);
                    if (myReader["OutDate"] is DBNull)
                    {
                        dr[1] = myReader["OutDate"].ToString();
                    }
                    else
                    {
                        dr[1] = Convert.ToDateTime(myReader["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr[2] = myReader["ClientName"].ToString();
                    dr[3] = myReader["IP"].ToString();
                    dr[4] = myReader["Card"].ToString();
                    dr[5] = myReader["OperatorType"].ToString();
                    dr[6] = myReader["TrfficType"].ToString();
                    dr[7] = myReader["State"].ToString();
                    dr[8] = myReader["流量"].ToString();
                    dt.Rows.Add(dr);//把这一行插入到表格dt中
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
                GridView1.DataSource = new DataView(dt);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView1.DataBind();//绑定数据
            


        }
        #endregion


    }
    #endregion


    #region 显示全部数据，准备导出
    protected void btnExport0_Click(object sender, EventArgs e)
    {


        GridView1.DataBind();
        btnExport.Visible = true;

        #region 隐藏的gridview

        string starttime = TextBox1.Text;
        string endtime = TextBox2.Text;
        string IP = TextBox3.Text;

        DataTable dt2 = new DataTable();
        DataRow dr2;
        dt2.Columns.Add(new DataColumn("日期", typeof(string)));
        dt2.Columns.Add(new DataColumn("开通日期", typeof(string)));
        dt2.Columns.Add(new DataColumn("用户名称", typeof(string)));
        dt2.Columns.Add(new DataColumn("IP", typeof(string)));
        dt2.Columns.Add(new DataColumn("卡号", typeof(string)));
        dt2.Columns.Add(new DataColumn("运营商", typeof(string)));
        dt2.Columns.Add(new DataColumn("合同容量", typeof(string)));
        dt2.Columns.Add(new DataColumn("状态", typeof(string)));
        dt2.Columns.Add(new DataColumn("流量(MB)", typeof(string)));

        //定义连接字符串
        string strconn2 = ConfigurationManager.ConnectionStrings["3GTrafficConnectionString"].ConnectionString;
        SqlConnection conn2 = new SqlConnection(strconn2);
        conn2.Open();
        #region      //如果开始日期和结束日期都不为空并且日期相同
        if (!starttime.Equals("") && !endtime.Equals("") && (TextBox1.Text == TextBox2.Text))
        {

            string sql2 = " select   Card, ClientName, IP, OutDate, OperatorType, TrfficType, State, sum(total) as 流量 from TrafficL2 "
                   + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                   + Condition.condition;


            sql2 += string.Format(" and date >= '{0}' and date <= '{1}'  ", starttime, endtime);

            if (!IP.Equals(""))
            {
                sql2 += string.Format(" and IP like '{0}%'  ", IP);
            }
            sql2 += " group by ClientName,CardType,OperatorType,IP,Card,L2user,OutDate,TrfficType,State "
                + " having CardType = '4G卡' or CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null "
                + " order by 流量 DESC ";


                SqlCommand cmd2 = new SqlCommand(sql2, conn2);
                cmd2.ExecuteNonQuery();
                SqlDataReader myReader2 = cmd2.ExecuteReader();
                while (myReader2.Read())
                {
                    dr2 = dt2.NewRow();
                    //dr2[0] = " ";

                    if (myReader2["OutDate"] is DBNull)
                    {
                        dr2[1] = myReader2["OutDate"].ToString();
                    }
                    else
                    {
                        dr2[1] = Convert.ToDateTime(myReader2["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr2[2] = myReader2["ClientName"].ToString();
                    dr2[3] = myReader2["IP"].ToString();
                    dr2[4] = myReader2["Card"].ToString();
                    dr2[5] = myReader2["OperatorType"].ToString();
                    dr2[6] = myReader2["TrfficType"].ToString();
                    dr2[7] = myReader2["State"].ToString();
                    dr2[8] = myReader2["流量"].ToString();
                    dt2.Rows.Add(dr2);//把这一行插入到表格dt中
                }
                myReader2.Dispose();
                myReader2.Close();
                conn2.Close();
                GridView2.DataSource = new DataView(dt2);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView2.DataBind();//绑定数据
           




        }
        #endregion


        #region  //其他情况不显示日期
        else
        {
            string sql2 = " select   Card, ClientName, IP, OutDate, OperatorType, TrfficType, State, sum(total) as 流量 from TrafficL2 "
               + " inner join ClientInfo  ON L2user = TrafficL2.users  "
               + Condition.condition;

            if (!IP.Equals(""))
            {
                sql2 += string.Format(" and IP like '{0}%'  ", IP);
            }

                if (starttime.Equals("") && endtime.Equals(""))    //没有输入日期
                {
                    sql2 += " group by ClientName,CardType,OperatorType,IP,Card,L2user,OutDate,TrfficType,State "
                        + " having CardType = '4G卡' or CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null "
                        + " order by 流量 DESC ";

                }

                else if (starttime.Equals("") && !endtime.Equals(""))    //输入了结束日期
                {
                    sql2 += string.Format(" and date <= '{0}'   ", endtime);

                    sql2 += " group by ClientName,CardType,OperatorType,IP,Card,L2user,OutDate,TrfficType,State "
                        + " having CardType = '4G卡' or CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null "
                        + " order by 流量 DESC ";
                }

                else if (!starttime.Equals("") && endtime.Equals(""))    //输入了开始日期，没有结束日期
                {
                    sql2 += string.Format(" and date >= '{0}'   ", starttime);

                    sql2 += " group by ClientName,CardType,OperatorType,IP,Card,L2user,OutDate,TrfficType,State "
                        + " having CardType = '4G卡' or CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null "
                        + " order by 流量 DESC ";


                }

                else if (!starttime.Equals("") && !endtime.Equals(""))    //输入了开始及结束日期
                {
                    sql2 += string.Format(" and date >= '{0}' and date <= '{1}'  ", starttime, endtime);

                    sql2 += " group by ClientName,CardType,OperatorType,IP,Card,L2user,OutDate,TrfficType,State "
                        + " having CardType = '4G卡' or CardType = '3G卡' and ClientName not like '%闲置%'  and IP is not Null "
                        + " order by 流量 DESC ";

                }


                conn2.Close();
                conn2.Open();
                SqlCommand cmd2 = new SqlCommand(sql2, conn2);
                cmd2.ExecuteNonQuery();
                SqlDataReader myReader2 = cmd2.ExecuteReader();
                while (myReader2.Read())
                {
                    dr2 = dt2.NewRow();
                    //dr[0] = myReader["date"].ToString().Substring(0, 10);
                    if (myReader2["OutDate"] is DBNull)
                    {
                        dr2[1] = myReader2["OutDate"].ToString();
                    }
                    else
                    {
                        dr2[1] = Convert.ToDateTime(myReader2["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr2[2] = myReader2["ClientName"].ToString();
                    dr2[3] = myReader2["IP"].ToString();
                    dr2[4] = myReader2["Card"].ToString();
                    dr2[5] = myReader2["OperatorType"].ToString();
                    dr2[6] = myReader2["TrfficType"].ToString();
                    dr2[7] = myReader2["State"].ToString();
                    dr2[8] = myReader2["流量"].ToString();
                    dt2.Rows.Add(dr2);//把这一行插入到表格dt中
                }
                myReader2.Dispose();
                myReader2.Close();
                conn2.Close();
                GridView2.DataSource = new DataView(dt2);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView2.DataBind();//绑定数据
            


        }
        #endregion


        #endregion

    }

    #endregion


    #region  鼠标悬停在gridview1列上时触发的事件
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //首先判断是否是数据行
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //当鼠标停留时更改背景色
                e.Row.Attributes.Add("onmouseover", "c=this.style.backgroundColor;this.style.backgroundColor='#CCCCCC'");
                //当鼠标移开时还原背景色
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=c");
                e.Row.Attributes["style"] = "Cursor:pointer ";
            }

        }
    }
    #endregion


    #region  鼠标悬停在gridview2列上时触发的事件
    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //首先判断是否是数据行
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //当鼠标停留时更改背景色
                e.Row.Attributes.Add("onmouseover", "c=this.style.backgroundColor;this.style.backgroundColor='#CCCCCC'");
                //当鼠标移开时还原背景色
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=c");
                e.Row.Attributes["style"] = "Cursor:pointer ";
            }

        }
    }
    #endregion


    #region  点击注销的事件
    protected void btnExit_Click(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'注销登陆')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }


        Session.Clear();
        Response.Write("<script languge='javascript'>alert('注销成功'); window.location.href='../Login.aspx'</script>");
    }
    #endregion


    #region 网页报错事件
    protected void Page_Error(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'网页报错弹出error页面')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }
    }
    #endregion
}


