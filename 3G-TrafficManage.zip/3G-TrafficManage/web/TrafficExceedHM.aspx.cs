﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using Newtonsoft.Json;
using System.Net;

public partial class web_TrafficExceedHM : System.Web.UI.Page
{
    //定义全局变量类Condition，其中的condition
    class Condition
    {
        //用来把sql语句赋值给下面的全局变量
        public static string condition = "";
        public static string condition2 = "";
    }

    //定义json类
    public class Account
    {
        public string reason { get; set; }      //获取响应状态
        public string id { get; set; }          //获取ID号
        public string status { get; set; }      //获取卡状态
        public string imsi { get; set; }        //获取imsi号码
        public string msisdn { get; set; }      //获取msisdn号码
    }

    //定义返回URL值
    private string GetContentFromUrll(string _requestUrl)
    {
        string _StrResponse = "";
        HttpWebRequest _WebRequest = (HttpWebRequest)WebRequest.Create(_requestUrl);
        _WebRequest.Method = "GET";
        WebResponse _WebResponse = _WebRequest.GetResponse();
        StreamReader _ResponseStream = new StreamReader(_WebResponse.GetResponseStream(), System.Text.Encoding.GetEncoding("gb2312"));
        _StrResponse = _ResponseStream.ReadToEnd();
        _WebResponse.Close();
        _ResponseStream.Close();
        return _StrResponse;
    }



    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["loginname"] == null)
        {

            Response.Write("<script languge='javascript'>alert('非法登陆，请重新登陆'); window.location.href='../Login.aspx'</script>");
        }
    }

    #region 提交按钮方法
    private void btnclickMethod()
    {
        //判断身份，区分查询条件，没有权限则把此用户提出到登陆页面


        if ((Session["loginname"].ToString() == "管理员") || (Session["loginname"].ToString() == "客服部") || (Session["loginname"].ToString() == "技术部") || (Session["loginname"].ToString() == "业务部"))
        {
            Condition.condition = " where (Traffic.source like  '169.1.63%' or Traffic.source like '169.5.2%' ) ";
            Condition.condition2 = " where (Traffic2.source like  '169.1.63%' or Traffic2.source like '169.5.2%' ) ";

        }
        else
        {
            //清除Session，弹出到登陆页面
            Session.Clear();
            Response.Write("<script languge='javascript'>alert('权限不足无法查询数据，请与管理员联系'); window.location.href='../Login.aspx'</script>");
        }

        string fazhi = DropDownList1.Text;


        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add(new DataColumn("日期", typeof(string)));
        dt.Columns.Add(new DataColumn("阀值信息", typeof(string)));
        dt.Columns.Add(new DataColumn("用户名称", typeof(string)));
        dt.Columns.Add(new DataColumn("IP", typeof(string)));
        dt.Columns.Add(new DataColumn("卡号", typeof(string)));
        dt.Columns.Add(new DataColumn("套餐流量(MB)", typeof(string)));
        dt.Columns.Add(new DataColumn("已使用流量(MB)", typeof(string)));
        dt.Columns.Add(new DataColumn("状态", typeof(string)));

        //定义连接字符串
        string strconn = ConfigurationManager.ConnectionStrings["3GTrafficConnectionString"].ConnectionString;
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();

        string sql = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic,State, sum(流量) as 流量 from ("
                   + " select source ,sum(traffic) as 流量  "
                   + " from Traffic2 "
                   + Condition.condition2
                   + " and Traffic2.date >= '2017-10-1 00:00:00.000' and Traffic2.date <= '2017-7-31 00:00:00.000' ";




        sql += string.Format("  group by source ")
            + " union "
            + " select source ,sum(traffic) as 流量 "
            + " from Traffic "
            + Condition.condition
            + " and Traffic.date >= '2017-10-1 00:00:00.000' and Traffic.date <= '2017-7-31 00:00:00.000' ";



        sql += string.Format("  group by source ")
            + " )Traffic2 inner join ClientInfo  ON source = IP "
            + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic,State  having  ";

        //根据选择的状态，设置不同的判断条件
        if (fazhi == "已启用并告警一次")
        {
            sql += "  State = '已启用并告警一次' ";
        }
        else if (fazhi == "还未启用")
        {
            sql += "  State <> '已启用并告警一次' ";
        }
        else if (fazhi == "全部")
        {
            sql += "  State <> '' ";
        }
        sql += " order by 流量 DESC ";



        //conn.Close();
        //conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.ExecuteNonQuery();
        SqlDataReader myReader = cmd.ExecuteReader();
        while (myReader.Read())
        {
            dr = dt.NewRow();
            //dr[0] = myReader["date"].ToString().Substring(0, 10);
            dr[0] = "2017年7月";
            dr[1] = fazhi;
            dr[2] = myReader["ClientName"].ToString();
            dr[3] = myReader["source"].ToString();
            dr[4] = myReader["Card"].ToString();
            dr[5] = myReader["Traffic"].ToString();
            dr[6] = myReader["流量"].ToString();
            dr[7] = myReader["State"].ToString();
            dt.Rows.Add(dr);//把这一行插入到表格dt中
        }
        myReader.Dispose();
        myReader.Close();
        conn.Close();
        GridView1.DataSource = new DataView(dt);
        //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
        GridView1.DataBind();//绑定数据
    }
    #endregion
    protected void Button3_Click(object sender, EventArgs e)
    {
        //调用按钮方法
        btnclickMethod();
    }

    #region  鼠标悬停在列上时触发的事件
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //首先判断是否是数据行
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //当鼠标停留时更改背景色
                e.Row.Attributes.Add("onmouseover", "c=this.style.backgroundColor;this.style.backgroundColor='#CCCCCC'");
                //当鼠标移开时还原背景色
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=c");
                e.Row.Attributes["style"] = "Cursor:pointer ";
            }

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //第二行的第一个控件
                Button b = e.Row.Cells[1].Controls[0] as Button;
                b.Attributes.Add("onclick", "if(confirm('确定要进行开启或关停操作吗？')){ __doPostBack('GridView1','$" + e.Row.RowIndex + "')}else{return false;}");
                //第三行的第一个控件
                Button c = e.Row.Cells[2].Controls[0] as Button;
                c.Attributes.Add("onclick", "if(confirm('确定要进行忽略或还原操作吗？')){ __doPostBack('GridView1','$" + e.Row.RowIndex + "')}else{return false;}");
            }
        }



    }
    #endregion


    #region  点击注销的事件
    protected void btnExit_Click(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'注销登陆')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }


        Session.Clear();
        Response.Write("<script languge='javascript'>alert('注销成功'); window.location.href='../Login.aspx'</script>");
    }
    #endregion


    #region 网页报错事件
    protected void Page_Error(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'网页报错弹出error页面')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }
    }
    #endregion
}
