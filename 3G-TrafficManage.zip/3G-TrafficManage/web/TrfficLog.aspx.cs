﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;


public partial class web_TrfficLog : System.Web.UI.Page
{
    //定义全局变量类Condition，其中的condition
    class Condition
    {
        //用来把sql语句赋值给下面的全局变量
        public static string condition = "";
        public static string condition2 = "";
        public static string conditionYD = "";
        public static string conditionUser = "";
        public static int contrafficCT = 0;
        public static int contrafficCTuse = 0;
        public static int contrafficCTZJ = 0;
        public static int contrafficCTZJuse = 0;
        public static int contrafficCU = 0;
        public static int contrafficCUuse = 0;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //Chart1.Visible = false;
        //Chart2.Visible = false;
        //Chart3.Visible = false;

        if (Session["loginname"] == null)
        {
            //Response.Redirect("/Login.aspx");
            //Response.Write("非法登陆，请重新登陆");

            Response.Write("<script languge='javascript'>alert('非法登陆，请重新登陆'); window.location.href='../Login.aspx'</script>");
        }

        Chart1.ChartAreas[0].BackColor = System.Drawing.Color.LightGray;
        Chart2.ChartAreas[0].BackColor = System.Drawing.Color.LightGray;

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Calendar1.Visible = true;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Calendar2.Visible = true;
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        TextBox1.Text = Calendar1.SelectedDate.ToString("yyyy/MM/dd");
        Calendar1.Visible = false;
    }
    protected void Calendar2_SelectionChanged(object sender, EventArgs e)
    {
        TextBox2.Text = Calendar2.SelectedDate.ToString("yyyy/MM/dd");
        Calendar2.Visible = false;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        GridView2.DataBind();
        btnExport0.Visible = true;  //点击查询之后，弹出此button
        btnExport.Visible = false;  //点击查询之后，弹出此button

        string starttime = TextBox1.Text;
        string endtime = TextBox2.Text;
        string TOP = DropDownList1.Text;
        string IP = TextBox3.Text;



        //判断身份，区分查询条件，没有权限则把此用户提出到登陆页面
        //if (Session["loginname"].ToString() == "")
        //{
        //    Response.Write("登陆超时，请重新登陆");
        //    Response.Redirect("/Login.aspx");
        //}

        if ((Session["loginname"].ToString() == "管理员") || (Session["loginname"].ToString() == "客服部") || (Session["loginname"].ToString() == "技术部") || (Session["loginname"].ToString() == "业务部") || (Session["loginname"].ToString() == "客服部管理员"))
        {
            Condition.condition = " where (Traffic.source like '180.153.254.%' or Traffic.source like '121.46.224.%' or Traffic.source like '10.32%' or Traffic.source like '10.255.217.251%' or Traffic.source like '10.255.217.255%' or Traffic.source like '172.16%'  or Traffic.source like '169.%' or Traffic.source like '10.3%' or Traffic.source like '130.130.1%' or Traffic.source like '192.168.254.%' ) ";
            Condition.condition2 = " where (Traffic2.source like '180.153.254.%' or Traffic2.source like '121.46.224.%' or Traffic2.source like '10.32%' or Traffic2.source like '10.255.217.251%' or Traffic2.source like '10.255.217.255%' or Traffic2.source like '172.16%'  or Traffic2.source like '169.%' or Traffic2.source like '10.3%' or Traffic2.source like '130.130.1%' or Traffic2.source like '192.168.254.%' ) ";
            Condition.conditionUser = " ";
            Condition.conditionYD = " where IP like '169.%' ";
        }
        else if (Session["loginname"].ToString() == "软银")
        {
            Condition.condition = " where (Traffic.source like  '169.1.53%' or Traffic.source like '169.6.6.%' or Traffic.source like '169.6.7.%' ) ";
            Condition.condition2 = " where (Traffic2.source like  '169.1.53%' or Traffic2.source like '169.6.6.%' or Traffic2.source like '169.6.7.%' ) ";
            Condition.conditionUser = " and ClientInfo.ClientName <> '浦发' and ClientInfo.ClientName not like '%哈希%' ";
        }
        else
        {
            //清除Session，弹出到登陆页面
            Session.Clear();
            Response.Write("<script languge='javascript'>alert('权限不足无法查询数据，请与管理员联系'); window.location.href='../Login.aspx'</script>");
        }



        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add(new DataColumn("日期", typeof(string)));
        dt.Columns.Add(new DataColumn("开通日期", typeof(string)));
        dt.Columns.Add(new DataColumn("用户名称", typeof(string)));
        dt.Columns.Add(new DataColumn("IP", typeof(string)));
        dt.Columns.Add(new DataColumn("卡号", typeof(string)));
        dt.Columns.Add(new DataColumn("运营商", typeof(string)));
        dt.Columns.Add(new DataColumn("合同容量", typeof(string)));
        dt.Columns.Add(new DataColumn("状态", typeof(string)));
        dt.Columns.Add(new DataColumn("流量(MB)", typeof(string)));
        
        //定义连接字符串
        string strconn = ConfigurationManager.ConnectionStrings["3GTrafficConnectionString"].ConnectionString;
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();
        #region      //如果开始日期和结束日期都不为空并且日期相同
        if (!starttime.Equals("") && !endtime.Equals("") && (TextBox1.Text == TextBox2.Text))
        {
            Chart1.Visible = false;
            Chart2.Visible = false;
            Chart3.Visible = false;
            //Chart5.Visible = false;

            #region       //类型为全部
            if (TOP.Equals("全部"))
            {
                string sql = " select  Traffic2.date, ClientInfo.Card, ClientInfo.ClientName, Traffic2.source ,OutDate,OperatorType,TrfficType,State,sum(流量) as 流量 from ("
                   + " select Traffic2.date,Traffic2.source ,sum(Traffic2.traffic) as 流量  "
                   + " from Traffic2 "
                   + Condition.condition2;


                sql += string.Format(" and Traffic2.date >= '{0}' and Traffic2.date <= '{1}'  ", starttime, endtime);

                if (!IP.Equals(""))
                {
                    sql += string.Format(" and source like '{0}%'  ", IP);
                }
                sql += " group by Traffic2.source,Traffic2.date "
                    + " union "
                    + " select Traffic.date,Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                sql += string.Format(" and Traffic.date >= '{0}' and Traffic.date <= '{1}'  ", starttime, endtime);

                if (!IP.Equals(""))
                {
                    sql += string.Format(" and source like '{0}%'  ", IP);
                }
                sql += " group by Traffic.source,Traffic.date "
                    + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                    + " group by Traffic2.source,Traffic2.date,ClientInfo.Card, ClientInfo.ClientName ,OutDate,OperatorType,TrfficType,State "
                    + " order by 流量 DESC ";


                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    dr = dt.NewRow();
                    if (myReader["date"] is DBNull)
                    {
                        dr[0] = myReader["date"].ToString();
                    }
                    else
                    {
                        dr[0] = Convert.ToDateTime(myReader["date"]).ToString("yyyy/MM/dd");
                    }

                    if (myReader["OutDate"] is DBNull)
                    {
                        dr[1] = myReader["OutDate"].ToString();
                    }
                    else
                    {
                        dr[1] = Convert.ToDateTime(myReader["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr[2] = myReader["ClientName"].ToString();
                    dr[3] = myReader["source"].ToString();
                    dr[4] = myReader["Card"].ToString();
                    dr[5] = myReader["OperatorType"].ToString();
                    dr[6] = myReader["TrfficType"].ToString();
                    dr[7] = myReader["State"].ToString();
                    dr[8] = myReader["流量"].ToString();
                    dt.Rows.Add(dr);//把这一行插入到表格dt中
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
                GridView1.DataSource = new DataView(dt);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView1.DataBind();//绑定数据
            }
            #endregion


            #region       //类型为TOP100
            else if (TOP.Equals("TOP100"))
            {
                Chart1.Visible = false;
                Chart2.Visible = false;
                Chart3.Visible = false;
                //Chart5.Visible = false;

                string sql = " select  TOP(100) Traffic2.date, ClientInfo.Card, ClientInfo.ClientName, Traffic2.source ,OutDate,OperatorType,TrfficType,State,sum(流量) as 流量 from ("
                   + " select Traffic2.date,Traffic2.source ,sum(Traffic2.traffic) as 流量  "
                   + " from Traffic2 "
                   + Condition.condition2;


                sql += string.Format(" and Traffic2.date >= '{0}' and Traffic2.date <= '{1}' ", starttime, endtime);

                if (!IP.Equals(""))
                {
                    sql += string.Format(" and source like '{0}%'  ", IP);
                }
                sql += "   group by Traffic2.source,Traffic2.date "
                    + " union "
                    + " select Traffic.date,Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                   + Condition.condition;

                sql += string.Format(" and Traffic.date >= '{0}' and Traffic.date <= '{1}'  ", starttime, endtime);
                if (!IP.Equals(""))
                {
                    sql += string.Format(" and source like '{0}%'  ", IP);
                }
                sql += "  group by Traffic.source,Traffic.date "
                    + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                    + " group by Traffic2.source,Traffic2.date,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                    + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    dr = dt.NewRow();
                    if (myReader["date"] is DBNull)
                    {
                        dr[0] = myReader["date"].ToString();
                    }
                    else
                    {
                        dr[0] = Convert.ToDateTime(myReader["date"]).ToString("yyyy/MM/dd");
                    }

                    if (myReader["OutDate"] is DBNull)
                    {
                        dr[1] = myReader["OutDate"].ToString();
                    }
                    else
                    {
                        dr[1] = Convert.ToDateTime(myReader["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr[2] = myReader["ClientName"].ToString();
                    dr[3] = myReader["source"].ToString();
                    dr[4] = myReader["Card"].ToString();
                    dr[5] = myReader["OperatorType"].ToString();
                    dr[6] = myReader["TrfficType"].ToString();
                    dr[7] = myReader["State"].ToString();
                    dr[8] = myReader["流量"].ToString();
                    dt.Rows.Add(dr);//把这一行插入到表格dt中
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
                GridView1.DataSource = new DataView(dt);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView1.DataBind();//绑定数据
            }
            #endregion

        }
        #endregion


        #region  //其他情况不显示日期
        else
        {
            #region  //类型为全部
            if (TOP.Equals("全部"))
            {
                Chart1.Visible = false;
                Chart2.Visible = false;
                Chart3.Visible = false;
                //Chart5.Visible = false;

                string sql = " select Traffic2.source ,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State,sum(流量) as 流量 from ("
                   + " select source ,sum(traffic) as 流量  "
                   + " from Traffic2 "
                   + Condition.condition2;

                if (!IP.Equals(""))
                {
                    sql += string.Format(" and source like '{0}%'  ", IP);
                }

                if (starttime.Equals("") && endtime.Equals(""))    //没有输入日期
                {
                    sql += string.Format("  group by source ")
                        + " union "
                        + " select source ,sum(traffic) as 流量 "
                        + " from Traffic "
                        + Condition.condition;

                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }

                    sql += string.Format("  group by source ")
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";

                }

                else if (starttime.Equals("") && !endtime.Equals(""))    //输入了结束日期
                {
                    Chart1.Visible = false;
                    Chart2.Visible = false;
                    Chart3.Visible = false;
                    //Chart5.Visible = false;

                    sql += string.Format(" and Traffic2.date <= '{0}'  group by source ", endtime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql += string.Format("  and Traffic.date <= '{0}'   ", endtime);
                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";
                }

                else if (!starttime.Equals("") && endtime.Equals(""))    //输入了开始日期，没有结束日期
                {
                    sql += string.Format(" and Traffic2.date >= '{0}'  group by source ", starttime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql += string.Format("  and Traffic.date >= '{0}'   ", starttime);
                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";





                }

                else if (!starttime.Equals("") && !endtime.Equals(""))    //输入了开始及结束日期
                {
                    
                    sql += string.Format(" and Traffic2.date >= '{0}' and Traffic2.date <= '{1}'  group by source ", starttime, endtime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql += string.Format(" and Traffic.date >= '{0}' and Traffic.date <= '{1}'  ", starttime, endtime);
                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";



                    #region  计算移动4G卡已使用流量代码
                    string sqlCT = " select sum(traffic)as 流量 from ClientInfo where OperatorType = '移动' ";



                    SqlCommand cmdCT = new SqlCommand(sqlCT, conn);
                    cmdCT.ExecuteNonQuery();
                    SqlDataReader myReaderCT = cmdCT.ExecuteReader();
                    while (myReaderCT.Read())
                    {
                        //dr = dt.NewRow();
                        string strtraffic = myReaderCT["流量"].ToString();
                        double doubletraffic = double.Parse(strtraffic);
                        int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计总流量转换为int类型
                        //Condition.contrafficCT = inttraffic;              //有问题改成固定的了 目前152张移动卡,8月15日增加30张1G的，9月增加40张1G,10月11日增加40张1G =262张
                        Condition.contrafficCT = 268288;
                    }

                    myReaderCT.Close();


                    
                    string sql2 = " select  sum(total) as 流量 from TrafficL2 "
                       + " inner join ClientInfo  ON L2user = TrafficL2.users  "
                       + Condition.conditionYD
                       + " and date >= '2017-7-1' and date <= '2017-7-31' ";



                    sql2 += " and CardType = '4G卡' and ClientName not like '%闲置%'  and IP is not Null and OperatorType = '移动'  "
                             + " order by 流量 DESC ";


                    SqlCommand cmd2 = new SqlCommand(sql2, conn);
                    cmd2.ExecuteNonQuery();
                    SqlDataReader myReader2 = cmd2.ExecuteReader();
                    
                    while (myReader2.Read())
                    {
                        //dr = dt.NewRow();
                        string strtraffic = myReader2["流量"].ToString();
                        int inttraffic;
                        if (strtraffic != "")
                        {
                            double doubletraffic = double.Parse(strtraffic);
                            inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型
                        }
                        else
                        {
                            inttraffic = 0;
                        }
                        Condition.contrafficCTuse = inttraffic;
                    }
                    myReader2.Dispose();
                    myReader2.Close();

                    int shenyutrafficCT = Condition.contrafficCT - Condition.contrafficCTuse;

                    Chart1.Visible = true;
                    List<string> xData = new List<string>() { "已用流量", "剩余流量" };
                    List<int> yData = new List<int>() { Condition.contrafficCTuse, shenyutrafficCT };
                    Chart1.Series[0]["PieLabelStyle"] = "Outside";//将文字移到外侧
                    Chart1.Series[0]["PieLineColor"] = "Black";//绘制黑色的连线。
                    Chart1.ChartAreas[0].Area3DStyle.Enable3D = true;  //设置为3D显示
                    Chart1.ChartAreas[0].BackColor = System.Drawing.Color.LightGray;
                    Chart1.ChartAreas[0].Area3DStyle.Inclination = 60;
                    Chart1.Series[0].Points.DataBindXY(xData, yData);

                    #endregion


                    #region  计算机智通电信卡已使用流量代码
                    //string sqlCTZJ = " select sum(traffic)as 流量 from ClientInfo where ClientInfo.Card like '106%' ";



                    //SqlCommand cmdCTZJ = new SqlCommand(sqlCTZJ, conn);
                    //cmdCTZJ.ExecuteNonQuery();
                    //SqlDataReader myReaderCTZJ = cmdCTZJ.ExecuteReader();
                    //while (myReaderCTZJ.Read())
                    //{
                    //    //dr = dt.NewRow();
                    //    string strtraffic = myReaderCTZJ["流量"].ToString();
                    //    double doubletraffic = double.Parse(strtraffic);
                    //    int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计总流量转换为int类型
                    //    Condition.contrafficCTZJ = inttraffic;
                    //}
                    //myReaderCTZJ.Dispose();
                    //myReaderCTZJ.Close();




                    string sql3 = " select sum(流量) as 流量 from ("
                        + " select source ,sum(traffic) as 流量  "
                        + " from Traffic2 "
                        //+ " where (Traffic2.source like '10.32%' or Traffic2.source like '172.16%'  or Traffic2.source like '169.1.31%' or Traffic2.source like '169.1.46%' or Traffic2.source like '169.1.255%' or Traffic2.source like '169.1.41%' or Traffic2.source like '169.1.43%' or Traffic2.source like '169.1.45%' or Traffic2.source like '169.1.47%' or Traffic2.source like '169.1.48%' or Traffic2.source like '169.1.49%' or Traffic2.source like '169.1.50%' or Traffic2.source like '169.1.51%' or Traffic2.source like '169.1.53%' or Traffic2.source like '169.1.56%' or Traffic2.source like '10.3%' or Traffic2.source like '169.1.57%') "
                        + Condition.condition2
                        + " and (Traffic2.date >= '2017-7-1' and Traffic2.date <= '2017-7-31') group by source "
                        + " union "
                        + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                        + " from Traffic "
                        //+ " where (Traffic.source like '10.32%' or Traffic.source like '172.16%'  or Traffic.source like '169.1.31%' or Traffic.source like '169.1.46%' or Traffic.source like '169.1.255%' or Traffic.source like '169.1.41%' or Traffic.source like '169.1.43%' or Traffic.source like '169.1.45%' or Traffic.source like '169.1.47%' or Traffic.source like '169.1.48%' or Traffic.source like '169.1.49%' or Traffic.source like '169.1.50%' or Traffic.source like '169.1.51%' or Traffic.source like '169.1.53%' or Traffic.source like '169.1.56%' or Traffic.source like '10.3%' or Traffic.source like '169.1.57%') "
                        + Condition.condition
                        + " and (Traffic.date >= '2017-7-1' and Traffic.date <= '2017-7-31') "
                        + " group by source "
                        + " )Traffic2 left join ClientInfo  ON source = IP where ClientInfo.Card  like '106%' and  OperatorType = '电信' "
                        + " order by 流量 DESC ";


                    SqlCommand cmd3 = new SqlCommand(sql3, conn);
                    cmd3.ExecuteNonQuery();
                    SqlDataReader myReader3 = cmd3.ExecuteReader();
                    while (myReader3.Read())
                    {
                        //dr = dt.NewRow();
                        string strtraffic = myReader3["流量"].ToString();
                        double doubletraffic = double.Parse(strtraffic);
                        int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型
                        Condition.contrafficCTZJuse = inttraffic;
                        
                    }
                    myReader3.Dispose();
                    myReader3.Close();

                    //5月份 50张1024MB + 1张500MB + 192张50MB  = 118998MB ≈ 116GB
                    //7月17日加了50张500M的     =25000MB
                    //7月21日加了50张50M的      =2500MB
                    //10月28日加了50张50M的     =2500MB
                    //12月10日加了32张50M的     =1600MB
                    //16年1月22日加了40张50M的  =2000MB 
                    //16年3月2日加了30张50M的   =1500MB
                    //16年3月21日加了10张1G的，30张50M的   =10240 + 1500 = 11740MB
                    //16年4月19日加了30张1024M的   = 30720MB
                    //16年6月7日加入30张50M的   = 1500MB
                    //总共197844MB ≈ 193GB
                    //开会讨论后修正为174080MB = 170GB
                    //16年7月6日加入30张50M的   =1500MB
                    //总共175580  =171.46GB
                    //17年4月14日拆机89张，总共18.5G , 总共=156636  =152.96GB
                    int shenyutrafficCTZJ = 156636 - Condition.contrafficCTZJuse;

                    Chart2.Visible = true;
                    List<string> xData2 = new List<string>() { "已用流量", "剩余流量" };
                    List<int> yData2 = new List<int>() { Condition.contrafficCTZJuse, shenyutrafficCTZJ };
                    Chart2.Series[0]["PieLabelStyle"] = "Outside";//将文字移到外侧
                    Chart2.Series[0]["PieLineColor"] = "Black";//绘制黑色的连线。
                    Chart2.ChartAreas[0].Area3DStyle.Enable3D = true;   //设置为3D显示
                    Chart2.ChartAreas[0].BackColor = System.Drawing.Color.LightGray;
                    Chart2.ChartAreas[0].Area3DStyle.Inclination = 60;
                    Chart2.Series[0].Points.DataBindXY(xData2, yData2);
                    //conn.Close();
                    #endregion


                    #region  计算联通流量卡已使用流量代码
                    string sql4 = " select sum(流量) as 流量 from ("
                        + " select source ,sum(traffic) as 流量  "
                        + " from Traffic2 "
                        //+ " where (Traffic2.source like '10.32%' or Traffic2.source like '172.16%'  or Traffic2.source like '169.1.31%' or Traffic2.source like '169.1.46%' or Traffic2.source like '169.1.255%' or Traffic2.source like '169.1.41%' or Traffic2.source like '169.1.43%' or Traffic2.source like '169.1.45%' or Traffic2.source like '169.1.47%' or Traffic2.source like '169.1.48%' or Traffic2.source like '169.1.49%' or Traffic2.source like '169.1.50%' or Traffic2.source like '169.1.51%' or Traffic2.source like '169.1.53%' or Traffic2.source like '169.1.56%' or Traffic2.source like '10.3%' or Traffic2.source like '169.1.57%') "
                        + Condition.condition2
                        + " and (Traffic2.date >= '2017-7-1' and Traffic2.date <= '2017-7-31') group by source "
                        + " union "
                        + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                        + " from Traffic "
                        //+ " where (Traffic.source like '10.32%' or Traffic.source like '172.16%'  or Traffic.source like '169.1.31%' or Traffic.source like '169.1.46%' or Traffic.source like '169.1.255%' or Traffic.source like '169.1.41%' or Traffic.source like '169.1.43%' or Traffic.source like '169.1.45%' or Traffic.source like '169.1.47%' or Traffic.source like '169.1.48%' or Traffic.source like '169.1.49%' or Traffic.source like '169.1.50%' or Traffic.source like '169.1.51%' or Traffic.source like '169.1.53%' or Traffic.source like '169.1.56%' or Traffic.source like '10.3%' or Traffic.source like '169.1.57%') "
                        + Condition.condition
                        + " and (Traffic.date >= '2017-7-1' and Traffic.date <= '2017-7-31') "
                        + " group by source "
                        //+ " )Traffic2 left join ClientInfo  ON source = IP where (OperatorType  = '联通'  and ClientInfo.Traffic = '1024')  "
                        + " )Traffic2 left join ClientInfo  ON source = IP where (OperatorType  = '联通' )  "
                        + " order by 流量 DESC ";


                    SqlCommand cmd4 = new SqlCommand(sql4, conn);
                    cmd4.ExecuteNonQuery();
                    SqlDataReader myReader4 = cmd4.ExecuteReader();
                    while (myReader4.Read())
                    {
                        //dr = dt.NewRow();
                        string strtraffic = myReader4["流量"].ToString();
                        double doubletraffic = double.Parse(strtraffic);
                        int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型

                        

                        //原来联通池流量为74752
                        int shenyutraffic = 1024000 - inttraffic;

                        Chart3.Visible = true;
                        List<string> xData3 = new List<string>() { "已用流量", "剩余流量" };
                        List<int> yData3 = new List<int>() { inttraffic, shenyutraffic };
                        Chart3.Series[0]["PieLabelStyle"] = "Outside";//将文字移到外侧
                        Chart3.Series[0]["PieLineColor"] = "Black";//绘制黑色的连线。
                        Chart3.ChartAreas[0].Area3DStyle.Enable3D = true;   //设置为3D显示
                        Chart3.ChartAreas[0].BackColor = System.Drawing.Color.LightGray;
                        Chart3.ChartAreas[0].Area3DStyle.Inclination = 60;
                        Chart3.Series[0].Points.DataBindXY(xData3, yData3);

                        

                    }


                    myReader4.Dispose();
                    myReader4.Close();
                    #endregion


                    #region  计算禾美摄影已使用流量代码
                    string sql5 = " select sum(流量) as 流量 from ("
                        + " select source ,sum(traffic) as 流量  "
                        + " from Traffic2 "
                        + Condition.condition2
                        + " and (Traffic2.date >= '2017-7-1' and Traffic2.date <= '2017-7-31') group by source "
                        + " union "
                        + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                        + " from Traffic "
                        + Condition.condition
                        + " and (Traffic.date >= '2017-7-1' and Traffic.date <= '2017-7-31') "
                        + " group by source "
                        + " )Traffic2 left join ClientInfo  ON source = IP where (ClientName like '%禾美%' )  "
                        + " order by 流量 DESC ";


                    SqlCommand cmd5 = new SqlCommand(sql5, conn);
                    cmd5.ExecuteNonQuery();
                    SqlDataReader myReader5 = cmd5.ExecuteReader();
                    while (myReader5.Read())
                    {
                        //dr = dt.NewRow();
                        string strtraffic = myReader5["流量"].ToString();
                        if (strtraffic != "")
                        {
                            double doubletraffic = double.Parse(strtraffic);
                            int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型

                            //目前禾美有370张卡，每张500M/月流量
                            //目前442张
                            //目前415张
                            int shenyutraffic = 207500 - inttraffic;

                            Chart4.Visible = true;
                            List<string> xData4 = new List<string>() { "已用流量", "剩余流量" };
                            List<int> yData4 = new List<int>() { inttraffic, shenyutraffic };
                            Chart4.Series[0]["PieLabelStyle"] = "Outside";//将文字移到外侧
                            Chart4.Series[0]["PieLineColor"] = "Black";//绘制黑色的连线。
                            Chart4.ChartAreas[0].Area3DStyle.Enable3D = true;   //设置为3D显示
                            Chart4.ChartAreas[0].BackColor = System.Drawing.Color.LightGray;
                            Chart4.ChartAreas[0].Area3DStyle.Inclination = 60;
                            Chart4.Series[0].Points.DataBindXY(xData4, yData4);
                        }
                        else
                        {
                            double doubletraffic = 0;
                            int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型

                            //原来联通池流量为74752
                            int shenyutraffic = 134500 - inttraffic;

                            Chart4.Visible = true;
                            List<string> xData4 = new List<string>() { "已用流量", "剩余流量" };
                            List<int> yData4 = new List<int>() { inttraffic, shenyutraffic };
                            Chart4.Series[0]["PieLabelStyle"] = "Outside";//将文字移到外侧
                            Chart4.Series[0]["PieLineColor"] = "Black";//绘制黑色的连线。
                            Chart4.ChartAreas[0].Area3DStyle.Enable3D = true;   //设置为3D显示
                            Chart4.ChartAreas[0].BackColor = System.Drawing.Color.LightGray;
                            Chart4.ChartAreas[0].Area3DStyle.Inclination = 60;
                            Chart4.Series[0].Points.DataBindXY(xData4, yData4);
                        }
                        //int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型

                        

                        //原来联通池流量为74752
                        //int shenyutraffic = 80000 - inttraffic;

                        //Chart4.Visible = true;
                        //List<string> xData4 = new List<string>() { "已用流量", "剩余流量" };
                        //List<int> yData4 = new List<int>() { inttraffic, shenyutraffic };
                        //Chart4.Series[0]["PieLabelStyle"] = "Outside";//将文字移到外侧
                        //Chart4.Series[0]["PieLineColor"] = "Black";//绘制黑色的连线。
                        //Chart4.ChartAreas[0].Area3DStyle.Enable3D = true;   //设置为3D显示
                        //Chart4.ChartAreas[0].BackColor = System.Drawing.Color.LightGray;
                        //Chart4.ChartAreas[0].Area3DStyle.Inclination = 60;
                        //Chart4.Series[0].Points.DataBindXY(xData4, yData4);

                        

                    }


                    myReader5.Dispose();
                    myReader5.Close();
                    conn.Close();
                    #endregion


                    //#region  计算深圳电信流量卡已使用流量代码
                    //string sql6 = " select sum(流量) as 流量 from ("
                    //    + " select source ,sum(traffic) as 流量  "
                    //    + " from Traffic2 "
                    //    + Condition.condition2
                    //    + " and (Traffic2.date >= '2017-7-1' and Traffic2.date <= '2017-7-31') group by source "
                    //    + " union "
                    //    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    //    + " from Traffic "
                    //    + Condition.condition
                    //    + " and (Traffic.date >= '2017-7-1' and Traffic.date <= '2017-7-31') "
                    //    + " group by source "
                    //    + " )Traffic2 left join ClientInfo  ON source = IP where (OperatorType  = '深圳电信' )  "
                    //    + " order by 流量 DESC ";


                    //SqlCommand cmd6 = new SqlCommand(sql6, conn);
                    //cmd6.ExecuteNonQuery();
                    //SqlDataReader myReader6 = cmd6.ExecuteReader();
                    //while (myReader6.Read())
                    //{
                    //    //dr = dt.NewRow();
                    //    string strtraffic = myReader6["流量"].ToString();
                    //    double doubletraffic = double.Parse(strtraffic);
                    //    int inttraffic = Convert.ToInt32(doubletraffic);    //取出合计已使用流量转换为int类型



                    //    //深圳电信为1000G
                    //    int shenyutraffic = 1024000 - inttraffic;

                    //    Chart5.Visible = true;
                    //    List<string> xData5 = new List<string>() { "已用流量", "剩余流量" };
                    //    List<int> yData5 = new List<int>() { inttraffic, shenyutraffic };
                    //    Chart5.Series[0]["PieLabelStyle"] = "Outside";//将文字移到外侧
                    //    Chart5.Series[0]["PieLineColor"] = "Black";//绘制黑色的连线。
                    //    Chart5.ChartAreas[0].Area3DStyle.Enable3D = true;   //设置为3D显示
                    //    Chart5.ChartAreas[0].BackColor = System.Drawing.Color.LightGray;
                    //    Chart5.ChartAreas[0].Area3DStyle.Inclination = 60;
                    //    Chart5.Series[0].Points.DataBindXY(xData5, yData5);



                    //}


                    //myReader6.Dispose();
                    //myReader6.Close();
                    //#endregion

                }


                conn.Close();
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    dr = dt.NewRow();
                    //dr[0] = myReader["date"].ToString().Substring(0, 10);
                    if (myReader["OutDate"] is DBNull)
                    {
                        dr[1] = myReader["OutDate"].ToString();
                    }
                    else
                    {
                        dr[1] = Convert.ToDateTime(myReader["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr[2] = myReader["ClientName"].ToString();
                    dr[3] = myReader["source"].ToString();
                    dr[4] = myReader["Card"].ToString();
                    dr[5] = myReader["OperatorType"].ToString();
                    dr[6] = myReader["TrfficType"].ToString();
                    dr[7] = myReader["State"].ToString();
                    dr[8] = myReader["流量"].ToString();
                    dt.Rows.Add(dr);//把这一行插入到表格dt中
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
                GridView1.DataSource = new DataView(dt);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView1.DataBind();//绑定数据
            }

            #endregion

            #region  //类型为TOP100
            else if (TOP.Equals("TOP100"))
            {
                string sql = " select  TOP(100) Traffic2.source ,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State,sum(流量) as 流量 from ("
                   + " select Traffic2.source ,sum(Traffic2.traffic) as 流量  "
                   + " from Traffic2 "
                   + Condition.condition2;

                if (!IP.Equals(""))
                {
                    sql += string.Format(" and source like '{0}%'  ", IP);
                }

                if (starttime.Equals("") && endtime.Equals(""))    //没有输入日期
                {
                    sql += string.Format("  group by source ")
                        + " union "
                        + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                        + " from Traffic "
                        + Condition.condition;
                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }

                    sql += string.Format("  group by source ")
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";

                }

                else if (starttime.Equals("") && !endtime.Equals(""))    //输入了结束日期
                {
                    sql += string.Format(" and Traffic2.date <= '{0}'  group by source ", endtime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql += string.Format("  and Traffic.date <= '{0}'  ", endtime);
                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";
                }

                else if (!starttime.Equals("") && endtime.Equals(""))    //输入了开始日期
                {
                    sql += string.Format(" and Traffic2.date >= '{0}'  group by source ", starttime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql += string.Format("  and Traffic.date >= '{0}'   ", starttime);
                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";
                }

                else if (!starttime.Equals("") && !endtime.Equals(""))    //输入了开始及结束日期
                {
                    sql += string.Format(" and Traffic2.date >= '{0}' and Traffic2.date <= '{1}'  group by source ", starttime, endtime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql += string.Format(" and Traffic.date >= '{0}' and Traffic.date <= '{1}'   ", starttime, endtime);
                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";
                }

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    dr = dt.NewRow();
                    //dr[0] = myReader["date"].ToString().Substring(0, 10);
                    if (myReader["OutDate"] is DBNull)
                    {
                        dr[1] = myReader["OutDate"].ToString();
                    }
                    else
                    {
                        dr[1] = Convert.ToDateTime(myReader["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr[2] = myReader["ClientName"].ToString();
                    dr[3] = myReader["source"].ToString();
                    dr[4] = myReader["Card"].ToString();
                    dr[5] = myReader["OperatorType"].ToString();
                    dr[6] = myReader["TrfficType"].ToString();
                    dr[7] = myReader["State"].ToString();
                    dr[8] = myReader["流量"].ToString();
                    dt.Rows.Add(dr);//把这一行插入到表格dt中
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
                GridView1.DataSource = new DataView(dt);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView1.DataBind();//绑定数据
            }
            #endregion
        }
        #endregion





    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("ChartAnalyze.aspx");
    }


    #region 导出Excel
    protected void btnExport_Click(object sender, EventArgs e)
    {
        {
            //DateTime dt = System.DateTime.Now;
            //string str = dt.ToString("yyyyMMddhhmmss");

            Button4.Visible = true;
            btnExport0.Visible = false;
            GridView2.AllowPaging = false;

            string str = "Traffic";
            str = str + ".xls";

            GridViewToExcel(GridView2, "application/ms-excel", str);

            // Export(gvRecord, "application/ms-excel", str);



        }
    }

    /// <summary>
    /// 将网格数据导出到Excel
    /// </summary>
    /// <param name="ctrl">网格名称(如GridView1)</param>
    /// <param name="FileType">要导出的文件类型(Excel:application/ms-excel)</param>
    /// <param name="FileName">要保存的文件名</param>
    public static void GridViewToExcel(Control ctrl, string FileType, string FileName)
    {
        HttpContext.Current.Response.Charset = "GB2312";
        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.UTF8;//注意编码
        HttpContext.Current.Response.AppendHeader("Content-Disposition",
            "attachment;filename=" + HttpUtility.UrlEncode(FileName, System.Text.Encoding.UTF8).ToString());
        HttpContext.Current.Response.ContentType = FileType;//image/JPEG;text/HTML;image/GIF;vnd.ms-excel/msword
        ctrl.Page.EnableViewState = false;
        StringWriter tw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(tw);
        ctrl.RenderControl(hw);
        HttpContext.Current.Response.Write(tw.ToString());
        HttpContext.Current.Response.End();
    }

    public override void VerifyRenderingInServerForm(Control control)
    {

    }
    #endregion


    #region 分页功能
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        string starttime = TextBox1.Text;
        string endtime = TextBox2.Text;
        string TOP = DropDownList1.Text;
        string IP = TextBox3.Text;

        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add(new DataColumn("日期", typeof(string)));
        dt.Columns.Add(new DataColumn("开通日期", typeof(string)));
        dt.Columns.Add(new DataColumn("用户名称", typeof(string)));
        dt.Columns.Add(new DataColumn("IP", typeof(string)));
        dt.Columns.Add(new DataColumn("卡号", typeof(string)));
        dt.Columns.Add(new DataColumn("运营商", typeof(string)));
        dt.Columns.Add(new DataColumn("合同容量", typeof(string)));
        dt.Columns.Add(new DataColumn("状态", typeof(string)));
        dt.Columns.Add(new DataColumn("流量(MB)", typeof(string)));

        //定义连接字符串
        string strconn = ConfigurationManager.ConnectionStrings["3GTrafficConnectionString"].ConnectionString;
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();
        #region      //如果开始日期和结束日期都不为空并且日期相同
        if (!starttime.Equals("") && !endtime.Equals("") && (TextBox1.Text == TextBox2.Text))
        {
            #region       //类型为全部
            if (TOP.Equals("全部"))
            {
                string sql = " select  Traffic2.date, ClientInfo.Card, ClientInfo.ClientName, Traffic2.source ,OutDate,OperatorType,TrfficType,State,sum(流量) as 流量 from ("
                   + " select Traffic2.date,Traffic2.source ,sum(Traffic2.traffic) as 流量  "
                   + " from Traffic2 "
                   + Condition.condition2;


                sql += string.Format(" and Traffic2.date >= '{0}' and Traffic2.date <= '{1}'  ", starttime, endtime);

                if (!IP.Equals(""))
                {
                    sql += string.Format(" and source like '{0}%'  ", IP);
                }
                sql += " group by Traffic2.source,Traffic2.date "
                    + " union "
                    + " select Traffic.date,Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                sql += string.Format(" and Traffic.date >= '{0}' and Traffic.date <= '{1}'  ", starttime, endtime);

                if (!IP.Equals(""))
                {
                    sql += string.Format(" and source like '{0}%'  ", IP);
                }
                sql += " group by Traffic.source,Traffic.date "
                    + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                    + " group by Traffic2.source,Traffic2.date,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                    + " order by 流量 DESC ";


                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    dr = dt.NewRow();
                    if (myReader["date"] is DBNull)
                    {
                        dr[0] = myReader["date"].ToString();
                    }
                    else
                    {
                        dr[0] = Convert.ToDateTime(myReader["date"]).ToString("yyyy/MM/dd");
                    }

                    if (myReader["OutDate"] is DBNull)
                    {
                        dr[1] = myReader["OutDate"].ToString();
                    }
                    else
                    {
                        dr[1] = Convert.ToDateTime(myReader["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr[2] = myReader["ClientName"].ToString();
                    dr[3] = myReader["source"].ToString();
                    dr[4] = myReader["Card"].ToString();
                    dr[5] = myReader["OperatorType"].ToString();
                    dr[6] = myReader["TrfficType"].ToString();
                    dr[7] = myReader["State"].ToString();
                    dr[8] = myReader["流量"].ToString();
                    dt.Rows.Add(dr);//把这一行插入到表格dt中
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
                GridView1.DataSource = new DataView(dt);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView1.DataBind();//绑定数据
            }
            #endregion


            #region       //类型为TOP100
            else if (TOP.Equals("TOP100"))
            {
                string sql = " select  TOP(100) Traffic2.date, ClientInfo.Card, ClientInfo.ClientName, Traffic2.source ,OutDate,OperatorType,TrfficType,State,sum(流量) as 流量 from ("
                   + " select Traffic2.date,Traffic2.source ,sum(Traffic2.traffic) as 流量  "
                   + " from Traffic2 "
                   + Condition.condition2;


                sql += string.Format(" and Traffic2.date >= '{0}' and Traffic2.date <= '{1}' ", starttime, endtime);

                if (!IP.Equals(""))
                {
                    sql += string.Format(" and source like '{0}%'  ", IP);
                }
                sql += "   group by Traffic2.source,Traffic2.date "
                    + " union "
                    + " select Traffic.date,Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                sql += string.Format(" and Traffic.date >= '{0}' and Traffic.date <= '{1}'  ", starttime, endtime);
                if (!IP.Equals(""))
                {
                    sql += string.Format(" and source like '{0}%'  ", IP);
                }
                sql += "  group by Traffic.source,Traffic.date "
                    + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                    + " group by Traffic2.source,Traffic2.date,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                    + " order by 流量 DESC ";

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    dr = dt.NewRow();
                    if (myReader["date"] is DBNull)
                    {
                        dr[0] = myReader["date"].ToString();
                    }
                    else
                    {
                        dr[0] = Convert.ToDateTime(myReader["date"]).ToString("yyyy/MM/dd");
                    }

                    if (myReader["OutDate"] is DBNull)
                    {
                        dr[1] = myReader["OutDate"].ToString();
                    }
                    else
                    {
                        dr[1] = Convert.ToDateTime(myReader["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr[2] = myReader["ClientName"].ToString();
                    dr[3] = myReader["source"].ToString();
                    dr[4] = myReader["Card"].ToString();
                    dr[5] = myReader["OperatorType"].ToString();
                    dr[6] = myReader["TrfficType"].ToString();
                    dr[7] = myReader["State"].ToString();
                    dr[8] = myReader["流量"].ToString();
                    dt.Rows.Add(dr);//把这一行插入到表格dt中
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
                GridView1.DataSource = new DataView(dt);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView1.DataBind();//绑定数据
            }
            #endregion

        }
        #endregion


        #region  //其他情况不显示日期
        else
        {
            #region  //类型为全部
            if (TOP.Equals("全部"))
            {
                string sql = " select Traffic2.source ,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State,sum(流量) as 流量 from ("
                   + " select source ,sum(traffic) as 流量  "
                   + " from Traffic2 "
                   + Condition.condition2;

                if (!IP.Equals(""))
                {
                    sql += string.Format(" and source like '{0}%'  ", IP);
                }

                if (starttime.Equals("") && endtime.Equals(""))    //没有输入日期
                {
                    sql += string.Format("  group by source ")
                        + " union "
                        + " select source ,sum(traffic) as 流量 "
                        + " from Traffic "
                        + Condition.condition;

                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }

                    sql += string.Format("  group by source ")
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";

                }

                else if (starttime.Equals("") && !endtime.Equals(""))    //输入了结束日期
                {
                    sql += string.Format(" and Traffic2.date <= '{0}'  group by source ", endtime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql += string.Format("  and Traffic.date <= '{0}'   ", endtime);
                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";
                }

                else if (!starttime.Equals("") && endtime.Equals(""))    //输入了开始日期，没有结束日期
                {
                    sql += string.Format(" and Traffic2.date >= '{0}'  group by source ", starttime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql += string.Format("  and Traffic.date >= '{0}'   ", starttime);
                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";





                }

                else if (!starttime.Equals("") && !endtime.Equals(""))    //输入了开始及结束日期
                {
                    sql += string.Format(" and Traffic2.date >= '{0}' and Traffic2.date <= '{1}'  group by source ", starttime, endtime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql += string.Format(" and Traffic.date >= '{0}' and Traffic.date <= '{1}'  ", starttime, endtime);
                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";




                }


                conn.Close();
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    dr = dt.NewRow();
                    //dr[0] = myReader["date"].ToString().Substring(0, 10);
                    if (myReader["OutDate"] is DBNull)
                    {
                        dr[1] = myReader["OutDate"].ToString();
                    }
                    else
                    {
                        dr[1] = Convert.ToDateTime(myReader["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr[2] = myReader["ClientName"].ToString();
                    dr[3] = myReader["source"].ToString();
                    dr[4] = myReader["Card"].ToString();
                    dr[5] = myReader["OperatorType"].ToString();
                    dr[6] = myReader["TrfficType"].ToString();
                    dr[7] = myReader["State"].ToString();
                    dr[8] = myReader["流量"].ToString();
                    dt.Rows.Add(dr);//把这一行插入到表格dt中
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
                GridView1.DataSource = new DataView(dt);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView1.DataBind();//绑定数据
            }

            #endregion

            #region  //类型为TOP100
            else if (TOP.Equals("TOP100"))
            {
                string sql = " select  TOP(100) Traffic2.source ,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State,sum(流量) as 流量 from ("
                   + " select Traffic2.source ,sum(Traffic2.traffic) as 流量  "
                   + " from Traffic2 "
                   + Condition.condition2;

                if (!IP.Equals(""))
                {
                    sql += string.Format(" and source like '{0}%'  ", IP);
                }

                if (starttime.Equals("") && endtime.Equals(""))    //没有输入日期
                {
                    sql += string.Format("  group by source ")
                        + " union "
                        + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                        + " from Traffic "
                        + Condition.condition;
                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }

                    sql += string.Format("  group by source ")
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";

                }

                else if (starttime.Equals("") && !endtime.Equals(""))    //输入了结束日期
                {
                    sql += string.Format(" and Traffic2.date <= '{0}'  group by source ", endtime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql += string.Format("  and Traffic.date <= '{0}'  ", endtime);
                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";
                }

                else if (!starttime.Equals("") && endtime.Equals(""))    //输入了开始日期
                {
                    sql += string.Format(" and Traffic2.date >= '{0}'  group by source ", starttime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql += string.Format("  and Traffic.date >= '{0}'   ", starttime);
                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";
                }

                else if (!starttime.Equals("") && !endtime.Equals(""))    //输入了开始及结束日期
                {
                    sql += string.Format(" and Traffic2.date >= '{0}' and Traffic2.date <= '{1}'  group by source ", starttime, endtime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql += string.Format(" and Traffic.date >= '{0}' and Traffic.date <= '{1}'   ", starttime, endtime);
                    if (!IP.Equals(""))
                    {
                        sql += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";
                }

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                SqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    dr = dt.NewRow();
                    //dr[0] = myReader["date"].ToString().Substring(0, 10);
                    if (myReader["OutDate"] is DBNull)
                    {
                        dr[1] = myReader["OutDate"].ToString();
                    }
                    else
                    {
                        dr[1] = Convert.ToDateTime(myReader["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr[2] = myReader["ClientName"].ToString();
                    dr[3] = myReader["source"].ToString();
                    dr[4] = myReader["Card"].ToString();
                    dr[5] = myReader["OperatorType"].ToString();
                    dr[6] = myReader["TrfficType"].ToString();
                    dr[7] = myReader["State"].ToString();
                    dr[8] = myReader["流量"].ToString();
                    dt.Rows.Add(dr);//把这一行插入到表格dt中
                }
                myReader.Dispose();
                myReader.Close();
                conn.Close();
                GridView1.DataSource = new DataView(dt);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView1.DataBind();//绑定数据
            }
            #endregion
        }
        #endregion


    }
    #endregion


    #region 显示全部数据，准备导出
    protected void btnExport0_Click(object sender, EventArgs e)
    {
        Chart1.Visible = false;
        Chart2.Visible = false;
        Chart3.Visible = false;
        //Chart5.Visible = false;

        GridView1.DataBind();
        btnExport.Visible = true;

        #region 隐藏的gridview

        string starttime = TextBox1.Text;
        string endtime = TextBox2.Text;
        string TOP = DropDownList1.Text;
        string IP = TextBox3.Text;

        DataTable dt2 = new DataTable();
        DataRow dr2;
        dt2.Columns.Add(new DataColumn("日期", typeof(string)));
        dt2.Columns.Add(new DataColumn("开通日期", typeof(string)));
        dt2.Columns.Add(new DataColumn("用户名称", typeof(string)));
        dt2.Columns.Add(new DataColumn("IP", typeof(string)));
        dt2.Columns.Add(new DataColumn("卡号", typeof(string)));
        dt2.Columns.Add(new DataColumn("运营商", typeof(string)));
        dt2.Columns.Add(new DataColumn("合同容量", typeof(string)));
        dt2.Columns.Add(new DataColumn("状态", typeof(string)));
        dt2.Columns.Add(new DataColumn("流量(MB)", typeof(string)));

        //定义连接字符串
        string strconn2 = ConfigurationManager.ConnectionStrings["3GTrafficConnectionString"].ConnectionString;
        SqlConnection conn2 = new SqlConnection(strconn2);
        conn2.Open();
        #region      //如果开始日期和结束日期都不为空并且日期相同
        if (!starttime.Equals("") && !endtime.Equals("") && (TextBox1.Text == TextBox2.Text))
        {
            #region       //类型为全部
            if (TOP.Equals("全部"))
            {
                string sql2 = " select  Traffic2.date, ClientInfo.Card, ClientInfo.ClientName, Traffic2.source ,OutDate,OperatorType,TrfficType,State,sum(流量) as 流量 from ("
                   + " select Traffic2.date,Traffic2.source ,sum(Traffic2.traffic) as 流量  "
                   + " from Traffic2 "
                   + Condition.condition2;


                sql2 += string.Format(" and Traffic2.date >= '{0}' and Traffic2.date <= '{1}'  ", starttime, endtime);

                if (!IP.Equals(""))
                {
                    sql2 += string.Format(" and source like '{0}%'  ", IP);
                }
                sql2 += " group by Traffic2.source,Traffic2.date "
                    + " union "
                    + " select Traffic.date,Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                sql2 += string.Format(" and Traffic.date >= '{0}' and Traffic.date <= '{1}'  ", starttime, endtime);

                if (!IP.Equals(""))
                {
                    sql2 += string.Format(" and source like '{0}%'  ", IP);
                }
                sql2 += " group by Traffic.source,Traffic.date "
                    + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                    + " group by Traffic2.source,Traffic2.date,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                    + " order by 流量 DESC ";


                SqlCommand cmd2 = new SqlCommand(sql2, conn2);
                cmd2.ExecuteNonQuery();
                SqlDataReader myReader2 = cmd2.ExecuteReader();
                while (myReader2.Read())
                {
                    dr2 = dt2.NewRow();
                    if (myReader2["date"] is DBNull)
                    {
                        dr2[0] = myReader2["date"].ToString();
                    }
                    else
                    {
                        dr2[0] = Convert.ToDateTime(myReader2["date"]).ToString("yyyy/MM/dd");
                    }

                    if (myReader2["OutDate"] is DBNull)
                    {
                        dr2[1] = myReader2["OutDate"].ToString();
                    }
                    else
                    {
                        dr2[1] = Convert.ToDateTime(myReader2["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr2[2] = myReader2["ClientName"].ToString();
                    dr2[3] = myReader2["source"].ToString();
                    dr2[4] = myReader2["Card"].ToString();
                    dr2[5] = myReader2["OperatorType"].ToString();
                    dr2[6] = myReader2["TrfficType"].ToString();
                    dr2[7] = myReader2["State"].ToString();
                    dr2[8] = myReader2["流量"].ToString();
                    dt2.Rows.Add(dr2);//把这一行插入到表格dt中
                }
                myReader2.Dispose();
                myReader2.Close();
                conn2.Close();
                GridView2.DataSource = new DataView(dt2);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView2.DataBind();//绑定数据
            }
            #endregion


            #region       //类型为TOP100
            else if (TOP.Equals("TOP100"))
            {
                string sql2 = " select  TOP(100) Traffic2.date, ClientInfo.Card, ClientInfo.ClientName, Traffic2.source ,OutDate,OperatorType,TrfficType,State,sum(流量) as 流量 from ("
                   + " select Traffic2.date,Traffic2.source ,sum(Traffic2.traffic) as 流量  "
                   + " from Traffic2 "
                   + Condition.condition2;


                sql2 += string.Format(" and Traffic2.date >= '{0}' and Traffic2.date <= '{1}' ", starttime, endtime);

                if (!IP.Equals(""))
                {
                    sql2 += string.Format(" and source like '{0}%'  ", IP);
                }
                sql2 += "   group by Traffic2.source,Traffic2.date "
                    + " union "
                    + " select Traffic.date,Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                sql2 += string.Format(" and Traffic.date >= '{0}' and Traffic.date <= '{1}'  ", starttime, endtime);
                if (!IP.Equals(""))
                {
                    sql2 += string.Format(" and source like '{0}%'  ", IP);
                }
                sql2 += "  group by Traffic.source,Traffic.date "
                    + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                    + " group by Traffic2.source,Traffic2.date,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                    + " order by 流量 DESC ";

                SqlCommand cmd2 = new SqlCommand(sql2, conn2);
                cmd2.ExecuteNonQuery();
                SqlDataReader myReader2 = cmd2.ExecuteReader();
                while (myReader2.Read())
                {
                    dr2 = dt2.NewRow();
                    if (myReader2["date"] is DBNull)
                    {
                        dr2[0] = myReader2["date"].ToString();
                    }
                    else
                    {
                        dr2[0] = Convert.ToDateTime(myReader2["date"]).ToString("yyyy/MM/dd");
                    }

                    if (myReader2["OutDate"] is DBNull)
                    {
                        dr2[1] = myReader2["OutDate"].ToString();
                    }
                    else
                    {
                        dr2[1] = Convert.ToDateTime(myReader2["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr2[2] = myReader2["ClientName"].ToString();
                    dr2[3] = myReader2["source"].ToString();
                    dr2[4] = myReader2["Card"].ToString();
                    dr2[5] = myReader2["OperatorType"].ToString();
                    dr2[6] = myReader2["TrfficType"].ToString();
                    dr2[7] = myReader2["State"].ToString();
                    dr2[8] = myReader2["流量"].ToString();
                    dt2.Rows.Add(dr2);//把这一行插入到表格dt中
                }
                myReader2.Dispose();
                myReader2.Close();
                conn2.Close();
                GridView2.DataSource = new DataView(dt2);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView2.DataBind();//绑定数据
            }
            #endregion

        }
        #endregion


        #region  //其他情况不显示日期
        else
        {
            #region  //类型为全部
            if (TOP.Equals("全部"))
            {
                string sql2 = " select Traffic2.source ,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State,sum(流量) as 流量 from ("
                   + " select source ,sum(traffic) as 流量  "
                   + " from Traffic2 "
                   + Condition.condition2;

                if (!IP.Equals(""))
                {
                    sql2 += string.Format(" and source like '{0}%'  ", IP);
                }

                if (starttime.Equals("") && endtime.Equals(""))    //没有输入日期
                {
                    sql2 += string.Format("  group by source ")
                        + " union "
                        + " select source ,sum(traffic) as 流量 "
                        + " from Traffic "
                        + Condition.condition;

                    if (!IP.Equals(""))
                    {
                        sql2 += string.Format(" and source like '{0}%'  ", IP);
                    }

                    sql2 += string.Format("  group by source ")
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";

                }

                else if (starttime.Equals("") && !endtime.Equals(""))    //输入了结束日期
                {
                    sql2 += string.Format(" and Traffic2.date <= '{0}'  group by source ", endtime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql2 += string.Format("  and Traffic.date <= '{0}'   ", endtime);
                    if (!IP.Equals(""))
                    {
                        sql2 += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql2 += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";
                }

                else if (!starttime.Equals("") && endtime.Equals(""))    //输入了开始日期，没有结束日期
                {
                    sql2 += string.Format(" and Traffic2.date >= '{0}'  group by source ", starttime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql2 += string.Format("  and Traffic.date >= '{0}'   ", starttime);
                    if (!IP.Equals(""))
                    {
                        sql2 += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql2 += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";





                }

                else if (!starttime.Equals("") && !endtime.Equals(""))    //输入了开始及结束日期
                {
                    sql2 += string.Format(" and Traffic2.date >= '{0}' and Traffic2.date <= '{1}'  group by source ", starttime, endtime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql2 += string.Format(" and Traffic.date >= '{0}' and Traffic.date <= '{1}'  ", starttime, endtime);
                    if (!IP.Equals(""))
                    {
                        sql2 += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql2 += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";




                }


                conn2.Close();
                conn2.Open();
                SqlCommand cmd2 = new SqlCommand(sql2, conn2);
                cmd2.ExecuteNonQuery();
                SqlDataReader myReader2 = cmd2.ExecuteReader();
                while (myReader2.Read())
                {
                    dr2 = dt2.NewRow();
                    //dr[0] = myReader["date"].ToString().Substring(0, 10);
                    if (myReader2["OutDate"] is DBNull)
                    {
                        dr2[1] = myReader2["OutDate"].ToString();
                    }
                    else
                    {
                        dr2[1] = Convert.ToDateTime(myReader2["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr2[2] = myReader2["ClientName"].ToString();
                    dr2[3] = myReader2["source"].ToString();
                    dr2[4] = myReader2["Card"].ToString();
                    dr2[5] = myReader2["OperatorType"].ToString();
                    dr2[6] = myReader2["TrfficType"].ToString();
                    dr2[7] = myReader2["State"].ToString();
                    dr2[8] = myReader2["流量"].ToString();
                    dt2.Rows.Add(dr2);//把这一行插入到表格dt中
                }
                myReader2.Dispose();
                myReader2.Close();
                conn2.Close();
                GridView2.DataSource = new DataView(dt2);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView2.DataBind();//绑定数据
            }

            #endregion

            #region  //类型为TOP100
            else if (TOP.Equals("TOP100"))
            {
                string sql2 = " select  TOP(100) Traffic2.source ,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State,sum(流量) as 流量 from ("
                   + " select Traffic2.source ,sum(Traffic2.traffic) as 流量  "
                   + " from Traffic2 "
                   + Condition.condition2;

                if (!IP.Equals(""))
                {
                    sql2 += string.Format(" and source like '{0}%'  ", IP);
                }

                if (starttime.Equals("") && endtime.Equals(""))    //没有输入日期
                {
                    sql2 += string.Format("  group by source ")
                        + " union "
                        + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                        + " from Traffic "
                        + Condition.condition;
                    if (!IP.Equals(""))
                    {
                        sql2 += string.Format(" and source like '{0}%'  ", IP);
                    }

                    sql2 += string.Format("  group by source ")
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";

                }

                else if (starttime.Equals("") && !endtime.Equals(""))    //输入了结束日期
                {
                    sql2 += string.Format(" and Traffic2.date <= '{0}'  group by source ", endtime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql2 += string.Format("  and Traffic.date <= '{0}'  ", endtime);
                    if (!IP.Equals(""))
                    {
                        sql2 += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql2 += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";
                }

                else if (!starttime.Equals("") && endtime.Equals(""))    //输入了开始日期
                {
                    sql2 += string.Format(" and Traffic2.date >= '{0}'  group by source ", starttime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql2 += string.Format("  and Traffic.date >= '{0}'   ", starttime);
                    if (!IP.Equals(""))
                    {
                        sql2 += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql2 += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";
                }

                else if (!starttime.Equals("") && !endtime.Equals(""))    //输入了开始及结束日期
                {
                    sql2 += string.Format(" and Traffic2.date >= '{0}' and Traffic2.date <= '{1}'  group by source ", starttime, endtime)
                    + " union "
                    + " select Traffic.source ,sum(Traffic.traffic) as 流量 "
                    + " from Traffic "
                    + Condition.condition;

                    sql2 += string.Format(" and Traffic.date >= '{0}' and Traffic.date <= '{1}'   ", starttime, endtime);
                    if (!IP.Equals(""))
                    {
                        sql2 += string.Format(" and source like '{0}%'  ", IP);
                    }
                    sql2 += " group by source "
                        + " )Traffic2 inner join ClientInfo  ON source = IP " + Condition.conditionUser
                        + " group by Traffic2.source,ClientInfo.Card, ClientInfo.ClientName,OutDate,OperatorType,TrfficType,State "
                        + " order by 流量 DESC ";
                }

                SqlCommand cmd2 = new SqlCommand(sql2, conn2);
                cmd2.ExecuteNonQuery();
                SqlDataReader myReader2 = cmd2.ExecuteReader();
                while (myReader2.Read())
                {
                    dr2 = dt2.NewRow();
                    //dr[0] = myReader["date"].ToString().Substring(0, 10);
                    if (myReader2["OutDate"] is DBNull)
                    {
                        dr2[1] = myReader2["OutDate"].ToString();
                    }
                    else
                    {
                        dr2[1] = Convert.ToDateTime(myReader2["OutDate"]).ToString("yyyy/MM/dd");
                    }
                    dr2[2] = myReader2["ClientName"].ToString();
                    dr2[3] = myReader2["source"].ToString();
                    dr2[4] = myReader2["Card"].ToString();
                    dr2[5] = myReader2["OperatorType"].ToString();
                    dr2[6] = myReader2["TrfficType"].ToString();
                    dr2[7] = myReader2["State"].ToString();
                    dr2[8] = myReader2["流量"].ToString();
                    dt2.Rows.Add(dr2);//把这一行插入到表格dt中
                }
                myReader2.Dispose();
                myReader2.Close();
                conn2.Close();
                GridView2.DataSource = new DataView(dt2);
                //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
                GridView2.DataBind();//绑定数据
            }
            #endregion
        }
        #endregion


        #endregion

    }

    #endregion


    #region  鼠标悬停在gridview1列上时触发的事件
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //首先判断是否是数据行
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //当鼠标停留时更改背景色
                e.Row.Attributes.Add("onmouseover", "c=this.style.backgroundColor;this.style.backgroundColor='#CCCCCC'");
                //当鼠标移开时还原背景色
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=c");
                e.Row.Attributes["style"] = "Cursor:pointer ";
            }

        }
    }
    #endregion


    #region  鼠标悬停在gridview2列上时触发的事件
    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //首先判断是否是数据行
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //当鼠标停留时更改背景色
                e.Row.Attributes.Add("onmouseover", "c=this.style.backgroundColor;this.style.backgroundColor='#CCCCCC'");
                //当鼠标移开时还原背景色
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=c");
                e.Row.Attributes["style"] = "Cursor:pointer ";
            }

        }
    }
    #endregion


    #region  点击注销的事件
    protected void btnExit_Click(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'注销登陆')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }


        Session.Clear();
        Response.Write("<script languge='javascript'>alert('注销成功'); window.location.href='../Login.aspx'</script>");
    }
    #endregion


    #region 网页报错事件
    protected void Page_Error(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'网页报错弹出error页面')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }
    }
    #endregion
}

