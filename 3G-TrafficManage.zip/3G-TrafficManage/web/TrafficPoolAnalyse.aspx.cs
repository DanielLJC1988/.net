﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Net;
using System.Threading;
using System.Security.Cryptography;

public partial class web_TrafficPoolAnalyse : System.Web.UI.Page
{
    //定义全局变量类Condition，其中的condition
    class Condition
    {
        //用来把sql语句赋值给下面的全局变量
        public static string ymcdx3G = "";
        public static string ysydx3G = "";
        public static string ymcdx4G = "";
        public static string ysydx4G = "";
        public static string ymclt3G = "";
        public static string ysylt3G = "";
        public static string ymcyd4G = "";
        public static string ysyyd4G = "";
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["loginname"] == null)
        {

            Response.Write("<script languge='javascript'>alert('非法登陆，请重新登陆'); window.location.href='../Login.aspx'</script>");
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        //调用按钮方法
        btnclickMethod();
    }
    #region 提交按钮方法
    private void btnclickMethod()
    {

        #region     周期计算
        string strStartYear = DateTime.Now.AddDays(1 - DateTime.Now.Day).AddYears(-1).ToString("yyyy-MM-dd") + "  00:00:00.000";
        string strStart = DateTime.Now.AddDays(1 - DateTime.Now.Day).ToString("yyyy-MM-dd") + "  00:00:00.000";
        string strEnd = DateTime.Now.AddDays(1 - DateTime.Now.Day).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd") + "  23:59:59.000";
        #endregion



        //定义连接字符串
        string strconn = ConfigurationManager.ConnectionStrings["3GTrafficConnectionString"].ConnectionString;
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();

        string sql1 = " select sum(Traffic) as 已卖出流量 from ClientInfo where ClientName <> '闲置在库' and OperatorType = '电信' and CardType = '3G卡'and Card like '1064%'  ";
        SqlCommand cmd1 = new SqlCommand(sql1, conn);
        cmd1.ExecuteNonQuery();
        SqlDataReader myReader1 = cmd1.ExecuteReader();
        while (myReader1.Read())
        {
            var aaa = Convert.ToInt32(myReader1["已卖出流量"]) / 1024;
            Label1.Text = aaa.ToString();
            double temp = aaa * 100 / 153;
            Label9.Text = temp.ToString() + "%";
        }

        myReader1.Dispose();
        myReader1.Close();


        string sql2 = " select sum(total) as 已使用流量 from TrafficL2  "
                        + " inner join ClientInfo  ON L2user = TrafficL2.users "
                        + " and CardType = '3G卡' and OperatorType = '电信' and ClientName not like '%闲置%'  and IP is not Null and Card like '1064%'  "
                        + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";
                        

        SqlCommand cmd2 = new SqlCommand(sql2, conn);
        cmd2.ExecuteNonQuery();
        SqlDataReader myReader2 = cmd2.ExecuteReader();
        while (myReader2.Read())
        {
            var aaa = Convert.ToInt32(myReader2["已使用流量"]) / 1024;
            Label2.Text = aaa.ToString();
            double temp = aaa * 100 / 153;
            Label13.Text = temp.ToString() + "%";
        }

        myReader2.Dispose();
        myReader2.Close();


        string sql3 = " select sum(Traffic) as 已卖出流量 from ClientInfo where ClientName <> '闲置在库' and OperatorType = '深圳电信' and CardType = '4G卡'and Card like '1064%'  ";
        SqlCommand cmd3 = new SqlCommand(sql3, conn);
        cmd3.ExecuteNonQuery();
        SqlDataReader myReader3 = cmd3.ExecuteReader();
        while (myReader3.Read())
        {
            var aaa = Convert.ToInt32(myReader3["已卖出流量"]) / 1024;
            Label3.Text = aaa.ToString();
            double temp = aaa * 100 / 1000;
            Label10.Text = temp.ToString() + "%";
        }

        myReader3.Dispose();
        myReader3.Close();



        string sql4 = " select sum(total) as 已使用流量 from TrafficL2  "
                        + " inner join ClientInfo  ON L2user = TrafficL2.users "
                        + " and CardType = '4G卡' and OperatorType = '深圳电信' and ClientName not like '%闲置%'  and IP is not Null "
                        + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";

        SqlCommand cmd4 = new SqlCommand(sql4, conn);
        cmd4.ExecuteNonQuery();
        SqlDataReader myReader4 = cmd4.ExecuteReader();
        while (myReader4.Read())
        {
            int aaa;
            if ((myReader4["已使用流量"]).ToString() != "")
            {
                aaa = Convert.ToInt32(myReader4["已使用流量"]) / 1024;
                Label4.Text = aaa.ToString() ;
                double temp = aaa * 100 / 1000;
                Label14.Text = temp.ToString() + "%";
            }
            else
            {
                Label4.Text = "0" ;
                Label14.Text = "0%";
            }
            
        }

        myReader4.Dispose();
        myReader4.Close();


        string sql5 = " select sum(Traffic) as 已卖出流量 from ClientInfo where ClientName <> '闲置在库' and ClientName <> '阿里巴巴' and OperatorType = '联通' and CardType = '3G卡'  ";
        SqlCommand cmd5 = new SqlCommand(sql5, conn);
        cmd5.ExecuteNonQuery();
        SqlDataReader myReader5 = cmd5.ExecuteReader();
        while (myReader5.Read())
        {
            var aaa = Convert.ToInt32(myReader5["已卖出流量"]) / 1024;
            Label5.Text = aaa.ToString();
            double temp = aaa * 100 / 1000;
            Label11.Text = temp.ToString() + "%";
        }

        myReader5.Dispose();
        myReader5.Close();


        string sql6 = " select sum(total) as 已使用流量 from TrafficL2  "
                        + " inner join ClientInfo  ON L2user = TrafficL2.users "
                        + " and CardType = '3G卡' and OperatorType = '联通' and ClientName not like '%闲置%'  and IP is not Null "
                        + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";

        SqlCommand cmd6 = new SqlCommand(sql6, conn);
        cmd6.ExecuteNonQuery();
        SqlDataReader myReader6 = cmd6.ExecuteReader();
        while (myReader6.Read())
        {
            var aaa = Convert.ToInt32(myReader6["已使用流量"]) / 1024;
            Label6.Text = aaa.ToString();
            double temp = aaa * 100 / 1000;
            Label15.Text = temp.ToString() + "%";
        }

        myReader6.Dispose();
        myReader6.Close();


        string sql7 = " select sum(Traffic) as 已卖出流量 from ClientInfo where ClientName <> '闲置在库' and OperatorType = '移动' ";
        SqlCommand cmd7 = new SqlCommand(sql7, conn);
        cmd7.ExecuteNonQuery();
        SqlDataReader myReader7 = cmd7.ExecuteReader();
        while (myReader7.Read())
        {
            var aaa = Convert.ToInt32(myReader7["已卖出流量"]) / 1024;
            Label7.Text = aaa.ToString();
            double temp = aaa * 100 / 262;
            Label12.Text = temp.ToString() + "%";
        }

        myReader7.Dispose();
        myReader7.Close();


        string sql8 = " select sum(total) as 已使用流量 from TrafficL2  "
                        + " inner join ClientInfo  ON L2user = TrafficL2.users "
                        + " and CardType = '4G卡' and OperatorType = '移动' and ClientName not like '%闲置%'  and IP is not Null "
                        + " and date >= '" + strStart + "' and date <= '" + strEnd + "' ";

        SqlCommand cmd8 = new SqlCommand(sql8, conn);
        cmd8.ExecuteNonQuery();
        SqlDataReader myReader8 = cmd8.ExecuteReader();
        while (myReader8.Read())
        {
            int aaa;
            if ((myReader8["已使用流量"]).ToString() != "")
            {
                aaa = Convert.ToInt32(myReader8["已使用流量"]) / 1024;
                Label8.Text = aaa.ToString() ;
                double temp = aaa * 100 / 262;
                Label16.Text = temp.ToString() + "%";
            }
            else
            {
                Label8.Text = "0";
                Label16.Text = "0%";
            }
                
            
        }

        myReader8.Dispose();
        myReader8.Close();


        conn.Close();

    }
    #endregion


    #region  点击注销的事件
    protected void btnExit_Click(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'注销登陆')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }


        Session.Clear();
        Response.Write("<script languge='javascript'>alert('注销成功'); window.location.href='../Login.aspx'</script>");
    }
    #endregion


    #region 网页报错事件
    protected void Page_Error(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'网页报错弹出error页面')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }
    }
    #endregion

}
