﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using Newtonsoft.Json;
using System.Net;

public partial class web_TrafficSub : System.Web.UI.Page
{
    //定义全局变量类Condition，其中的condition
    class Condition
    {
        //用来把sql语句赋值给下面的全局变量
        public static string condition = "";
        public static string condition2 = "";
    }

    //定义json类
    public class Account
    {
        public string reason { get; set; }      //获取响应状态
        public string id { get; set; }          //获取ID号
        public string status { get; set; }      //获取卡状态
        public string imsi { get; set; }        //获取imsi号码
        public string msisdn { get; set; }      //获取msisdn号码
    }

    //定义返回URL值
    private string GetContentFromUrll(string _requestUrl)
    {
        string _StrResponse = "";
        HttpWebRequest _WebRequest = (HttpWebRequest)WebRequest.Create(_requestUrl);
        _WebRequest.Method = "GET";
        WebResponse _WebResponse = _WebRequest.GetResponse();
        StreamReader _ResponseStream = new StreamReader(_WebResponse.GetResponseStream(), System.Text.Encoding.GetEncoding("gb2312"));
        _StrResponse = _ResponseStream.ReadToEnd();
        _WebResponse.Close();
        _ResponseStream.Close();
        return _StrResponse;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["loginname"] == null)
        {

            Response.Write("<script languge='javascript'>alert('非法登陆，请重新登陆'); window.location.href='../Login.aspx'</script>");
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        //调用按钮方法
        btnclickMethod();

    }

    #region 提交按钮方法
    private void btnclickMethod()
    {
        //判断身份，区分查询条件，没有权限则把此用户提出到登陆页面


        if ((Session["loginname"].ToString() == "管理员") || (Session["loginname"].ToString() == "客服部") || (Session["loginname"].ToString() == "技术部") || (Session["loginname"].ToString() == "业务部") || (Session["loginname"].ToString() == "客服部管理员"))
        {
            Condition.condition = " where (Traffic.source like '10.32%' or Traffic.source like '172.16%'  or Traffic.source like '169.1.%' or Traffic.source like '10.3%' or Traffic.source like '130.130.1%' or Traffic.source like '192.168.254.10' ) ";
            Condition.condition2 = " where (Traffic2.source like '10.32%' or Traffic2.source like '172.16%'  or Traffic2.source like '169.1.%' or Traffic2.source like '10.3%' or Traffic2.source like '130.130.1%' or Traffic2.source like '192.168.254.10' ) ";

        }
        else if (Session["loginname"].ToString() == "软银")
        {
            Condition.condition = " where (Traffic.source like  '169.1.53%' ) ";
            Condition.condition2 = " where (Traffic2.source like  '169.1.53%' ) ";
        }
        else
        {
            //清除Session，弹出到登陆页面
            Session.Clear();
            Response.Write("<script languge='javascript'>alert('权限不足无法查询数据，请与管理员联系'); window.location.href='../Login.aspx'</script>");
        }

        string fazhi = DropDownList1.Text;


        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add(new DataColumn("日期", typeof(string)));
        dt.Columns.Add(new DataColumn("阀值信息", typeof(string)));
        dt.Columns.Add(new DataColumn("用户名称", typeof(string)));
        dt.Columns.Add(new DataColumn("IP", typeof(string)));
        dt.Columns.Add(new DataColumn("卡号", typeof(string)));
        dt.Columns.Add(new DataColumn("套餐流量(MB)", typeof(string)));
        dt.Columns.Add(new DataColumn("已使用流量(MB)", typeof(string)));
        dt.Columns.Add(new DataColumn("状态", typeof(string)));

        //定义连接字符串
        string strconn = ConfigurationManager.ConnectionStrings["3GTrafficConnectionString"].ConnectionString;
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();

        string sql = " select ClientInfo.ClientName,Traffic2.source ,ClientInfo.Card, ClientInfo.Traffic,State, sum(流量) as 流量 from ("
                   + " select source ,sum(traffic) as 流量  "
                   + " from Traffic2 "
                   + Condition.condition2
                   + " and Traffic2.date >= '2015-7-13 00:00:00.000' and Traffic2.date <= '2015-7-19 00:00:00.000' ";




        sql += string.Format("  group by source ")
            + " union "
            + " select source ,sum(traffic) as 流量 "
            + " from Traffic "
            + Condition.condition
            + " and Traffic.date >= '2015-7-13 00:00:00.000' and Traffic.date <= '2015-7-19 00:00:00.000' ";



        sql += string.Format("  group by source ")
            + " )Traffic2 inner join ClientInfo  ON source = IP "
            + " group by ClientInfo.ClientName, Traffic2.source, ClientInfo.Card, ClientInfo.Traffic,State  having sum(流量) ";

        //根据选择的阀值，设置不同的判断条件
        if (fazhi == "超流量")
        {
            sql += " >= ClientInfo.Traffic / 4  and State <> '关停' and State <> '忽略' ";
        }
        
        
        else if (fazhi == "已关停")
        {
            sql += " <> 0 and State = '关停' and State <> '忽略' ";
        }
        else if (fazhi == "忽略")
        {
            sql += " <> 0 and State = '忽略' ";
        }
        sql += " order by 流量 DESC ";



        //conn.Close();
        //conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.ExecuteNonQuery();
        SqlDataReader myReader = cmd.ExecuteReader();
        while (myReader.Read())
        {
            dr = dt.NewRow();
            //dr[0] = myReader["date"].ToString().Substring(0, 10);
            dr[0] = "2015年7月第三周";
            dr[1] = fazhi;
            dr[2] = myReader["ClientName"].ToString();
            dr[3] = myReader["source"].ToString();
            dr[4] = myReader["Card"].ToString();
            dr[5] = myReader["Traffic"].ToString();
            dr[6] = myReader["流量"].ToString();
            dr[7] = myReader["State"].ToString();
            dt.Rows.Add(dr);//把这一行插入到表格dt中
        }
        myReader.Dispose();
        myReader.Close();
        conn.Close();
        GridView1.DataSource = new DataView(dt);
        //把DataTable中的二维数据dt作为一个数据源赋给DataGrid1
        GridView1.DataBind();//绑定数据
    }
    #endregion


    #region  鼠标悬停在列上时触发的事件
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //首先判断是否是数据行
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //当鼠标停留时更改背景色
                e.Row.Attributes.Add("onmouseover", "c=this.style.backgroundColor;this.style.backgroundColor='#CCCCCC'");
                //当鼠标移开时还原背景色
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=c");
                e.Row.Attributes["style"] = "Cursor:pointer ";
            }

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //第二行的第一个控件
                Button b = e.Row.Cells[1].Controls[0] as Button;
                b.Attributes.Add("onclick", "if(confirm('确定要进行开启或关停操作吗？')){ __doPostBack('GridView1','$" + e.Row.RowIndex + "')}else{return false;}");
                //第三行的第一个控件
                Button c = e.Row.Cells[2].Controls[0] as Button;
                c.Attributes.Add("onclick", "if(confirm('确定要进行忽略或还原操作吗？')){ __doPostBack('GridView1','$" + e.Row.RowIndex + "')}else{return false;}");
            }
        }



    }
    #endregion


    #region 控件内生成事件时激发
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "mailto")
        {
            /////////////////自定义邮箱地址//////////////////////////
            string cusAddressTEC = txtAddressTEC.Text;
            string cusAddressCC = txtAddressCC.Text;
            /////////////////////////////////////////////////////////

            /////////////////截取控件中相应的字符/////////////////////////
            int index = int.Parse(e.CommandArgument.ToString());
            string fazhi = GridView1.Rows[index].Cells[4].Text;
            string client = GridView1.Rows[index].Cells[5].Text;
            string card = GridView1.Rows[index].Cells[7].Text;
            string Traffictotal = GridView1.Rows[index].Cells[8].Text;
            //string Trafficlimit = GridView1.Rows[index].Cells[8].Text;
            string Trafficuse = GridView1.Rows[index].Cells[9].Text;
            /////////////////////////////////////////////////////////////

            /////////////////把流量字符转换为数字型，进行计算////////////
            decimal dectraffictotal = decimal.Parse(Traffictotal);
            decimal dectrafficuse = decimal.Parse(Trafficuse);
            decimal dectrafficshenyu = dectrafficuse - dectraffictotal;
            /////////////////////////////////////////////////////////////

            /////////////////定义邮箱地址////////////////////////////////
            string addressTEC = "technology@fashion-tele.com";
            string addresscc = "service@fashion-tele.com ; business@fashion-tele.com ; stsgrp-chinasalessp@g.softbank.co.jp ; sales1@fashion-tele.com";
            /////////////////////////////////////////////////////////////

            //定义告警日期
            string time = System.DateTime.Now.ToString("MM月dd日HH时");

            //定义主题
            string subject;
            //定义邮件内容
            string body;

            

            if (fazhi == "超流量")
            {
                if (cusAddressTEC.Equals("") && cusAddressCC.Equals(""))
                {
                    subject = "&Subject=尊敬的" + client + "：截止" + time + "，您卡号为 " + card + " 现在已超过套餐每周限定使用流量，本卡将被关停，下周才能开启使用！！";
                    body = "&body=尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 " + Traffictotal + "MB" + " ，现已使用 " + Trafficuse + "MB"  + "，已超过每周限定使用流量，本卡将被关停，下周才能开启使用！！";
                    //输出邮件脚本
                    Response.Write("<script> window.open( ' mailto:" + addressTEC + "?cc=" + addresscc + subject + body + "')</script>");
                }
                else
                {
                    subject = "&Subject=尊敬的" + client + "：截止" + time + "，您卡号为 " + card + " 现在已超过套餐每周限定使用流量，本卡将被关停，下周才能开启使用！！";
                    body = "&body=尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 " + Traffictotal + "MB" + " ，现已使用 " + Trafficuse + "MB"  + "，已超过每周限定使用流量，本卡将被关停，下周才能开启使用！！";
                    //输出邮件脚本
                    Response.Write("<script> window.open( ' mailto:" + cusAddressTEC + "?cc=" + cusAddressCC + subject + body + "')</script>");
                }
            }

            

            else if (fazhi == "已关停")
            {
                if (cusAddressTEC.Equals("") && cusAddressCC.Equals(""))
                {
                    subject = "&Subject=尊敬的" + client + "：截止" + time + "，卡号为 " + card + " ，现在已被关停！！";
                    body = "&body=尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 " + Traffictotal + "MB" + " ，现已使用 " + Trafficuse + "MB" + "，已超额使用了" + dectrafficshenyu + "MB" + "，本卡已被关停！！";
                    //输出邮件脚本
                    Response.Write("<script>; window.open( ' mailto:" + addressTEC + "?cc=" + addresscc + subject + body + "')</script>");
                }
                else
                {
                    subject = "&Subject=尊敬的" + client + "：截止" + time + "，卡号为 " + card + " ，现在已被关停！！";
                    body = "&body=尊敬的" + client + "：<br><br>截止" + time + "，您卡号为 " + card + " 本月套餐流量为 " + Traffictotal + "MB" + " ，现已使用 " + Trafficuse + "MB" + "，已超额使用了" + dectrafficshenyu + "MB" + "，本卡已被关停！！";
                    //输出邮件脚本
                    Response.Write("<script>; window.open( ' mailto:" + cusAddressTEC + "?cc=" + cusAddressCC + subject + body + "')</script>");
                }
            }


            //输出邮件脚本
            //Response.Write("<script> window.open( ' mailto:" + addressTEC + "?cc=" + addresscc + subject + body + "')</script>");
        }

        else if (e.CommandName == "OpenClose")
        {
            /////////////////截取控件中相应的字符/////////////////////////
            int index = int.Parse(e.CommandArgument.ToString());
            string fazhi = GridView1.Rows[index].Cells[4].Text;
            string client = GridView1.Rows[index].Cells[5].Text;
            string IP = GridView1.Rows[index].Cells[6].Text;
            string card = GridView1.Rows[index].Cells[7].Text;
            string State = GridView1.Rows[index].Cells[10].Text;
            /////////////////////////////////////////////////////////////

            string sql = "";
            string sql2 = "";
            string StateOpen = "启用";
            string StateClose = "关停";





            //获取当前登陆用户IP
            string anonymity = Request.UserHostAddress;
            string anonymityHostName = Request.UserHostName;

            string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
            string Role;

            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            if (State.Equals("启用"))
            {

                //string jsonText = "act=sms&mobile=&msg=短信平台测试短信";
                string sURL = "http://169.2.3.8:80/card/search/" + IP;

                WebRequest wrGETURL;
                wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

                string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
                Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                string reason = account.reason;                                         //取出返回值名称为reason的数值
                string id = account.id;                                                 //取出返回值名称为id的数值
                string status = account.status;
                string msisdn = account.msisdn;
                string imsi = account.imsi;

                if (reason == "Success!" && status == "active")
                {
                    if (msisdn != null)
                    {
                        string sURL2 = "http://169.2.3.8:80/card/status/" + msisdn + "/" + "inactive";

                        WebRequest wrGETURL2;
                        wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                        string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                        Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                        string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                        string id2 = account2.id;                                                 //取出返回值名称为id的数值
                        string status2 = account2.status;

                        if (reason2 == "Success!" && status2 == "inactive")
                        {

                            //暂时更新此卡数据库状态信息为 开启/关停
                            sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, IP, card);
                            //打开数据库连接
                            conn.Open();

                            //创建command对象
                            SqlCommand command = new SqlCommand(sql, conn);
                            int result = command.ExecuteNonQuery();
                            conn.Close();



                            Role = Session["loginname"].ToString();
                            //写入数据库日志
                            sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'将卡号为: {3} 关停')", logtime, Role, anonymity, card);
                            //打开数据库连接
                            conn.Open();

                            //创建command对象
                            SqlCommand command2 = new SqlCommand(sql2, conn);
                            int result2 = command2.ExecuteNonQuery();
                            conn.Close();

                            Response.Write("<script languge='javascript'>alert('此3G卡关停成功'); window.location.href='TrafficExceed.aspx'</script>");
                        }
                        else
                        {
                            Response.Write("<script languge='javascript'>alert('此3G卡关停失败'); window.location.href='TrafficExceed.aspx'</script>");
                        }
                    }

                    else if (imsi != null)
                    {
                        string sURL2 = "http://169.2.3.8:80/card/status/" + imsi + "/" + "inactive";

                        WebRequest wrGETURL2;
                        wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                        string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                        Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                        string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                        string id2 = account2.id;                                                 //取出返回值名称为id的数值
                        string status2 = account2.status;

                        if (reason2 == "Success!" && status2 == "inactive")
                        {

                            //暂时更新此卡数据库状态信息为 开启/关停
                            sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateClose, IP, card);
                            //打开数据库连接
                            conn.Open();

                            //创建command对象
                            SqlCommand command = new SqlCommand(sql, conn);
                            int result = command.ExecuteNonQuery();
                            conn.Close();



                            Role = Session["loginname"].ToString();
                            //写入数据库日志
                            sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'将卡号为: {3} 关停')", logtime, Role, anonymity, card);
                            //打开数据库连接
                            conn.Open();

                            //创建command对象
                            SqlCommand command2 = new SqlCommand(sql2, conn);
                            int result2 = command2.ExecuteNonQuery();
                            conn.Close();

                            Response.Write("<script languge='javascript'>alert('此3G卡关停成功'); window.location.href='TrafficExceed.aspx'</script>");
                        }
                        else
                        {
                            Response.Write("<script languge='javascript'>alert('此3G卡关停失败'); window.location.href='TrafficExceed.aspx'</script>");
                        }
                    }

                }
            }
            else if (State.Equals("关停"))
            {
                string sURL = "http://169.2.3.8:80/card/search/" + IP;

                WebRequest wrGETURL;
                wrGETURL = WebRequest.Create(sURL);                                     //发起WEB请求

                string geturlvalue = GetContentFromUrll(sURL);                          //URL值转成string类型
                Account account = JsonConvert.DeserializeObject<Account>(geturlvalue);  //反序列化string类型的URL值，变为JSON类型
                string reason = account.reason;                                         //取出返回值名称为reason的数值
                string id = account.id;                                                 //取出返回值名称为id的数值
                string status = account.status;
                string msisdn = account.msisdn;
                string imsi = account.imsi;

                if (reason == "Success!" && status == "inactive")
                {
                    if (msisdn != null)
                    {
                        string sURL2 = "http://169.2.3.8:80/card/status/" + msisdn + "/" + "active";

                        WebRequest wrGETURL2;
                        wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                        string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                        Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                        string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                        string id2 = account2.id;                                                 //取出返回值名称为id的数值
                        string status2 = account2.status;

                        if (reason2 == "Success!" && status2 == "active")
                        {
                            sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateOpen, IP, card);
                            //打开数据库连接
                            conn.Open();

                            //创建command对象
                            SqlCommand command = new SqlCommand(sql, conn);
                            int result = command.ExecuteNonQuery();
                            conn.Close();

                            Role = Session["loginname"].ToString();
                            //写入数据库日志
                            sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'将卡号为: {3} 启用')", logtime, Role, anonymity, card);
                            //打开数据库连接
                            conn.Open();

                            //创建command对象
                            SqlCommand command2 = new SqlCommand(sql2, conn);
                            int result2 = command2.ExecuteNonQuery();
                            conn.Close();
                            Response.Write("<script languge='javascript'>alert('此3G卡启用成功'); window.location.href='TrafficExceed.aspx'</script>");
                        }
                        else
                        {
                            Response.Write("<script languge='javascript'>alert('此3G卡启用失败'); window.location.href='TrafficExceed.aspx'</script>");
                        }

                    }
                    else if (imsi != null)
                    {
                        string sURL2 = "http://169.2.3.8:80/card/status/" + imsi + "/" + "active";

                        WebRequest wrGETURL2;
                        wrGETURL2 = WebRequest.Create(sURL2);                                     //发起WEB请求

                        string geturlvalue2 = GetContentFromUrll(sURL2);                          //URL值转成string类型
                        Account account2 = JsonConvert.DeserializeObject<Account>(geturlvalue2);  //反序列化string类型的URL值，变为JSON类型
                        string reason2 = account2.reason;                                         //取出返回值名称为reason的数值
                        string id2 = account2.id;                                                 //取出返回值名称为id的数值
                        string status2 = account2.status;

                        if (reason2 == "Success!" && status2 == "active")
                        {

                            //暂时更新此卡数据库状态信息为 开启/关停
                            sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateOpen, IP, card);
                            //打开数据库连接
                            conn.Open();

                            //创建command对象
                            SqlCommand command = new SqlCommand(sql, conn);
                            int result = command.ExecuteNonQuery();
                            conn.Close();



                            Role = Session["loginname"].ToString();
                            //写入数据库日志
                            sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'将卡号为: {3} 启用')", logtime, Role, anonymity, card);
                            //打开数据库连接
                            conn.Open();

                            //创建command对象
                            SqlCommand command2 = new SqlCommand(sql2, conn);
                            int result2 = command2.ExecuteNonQuery();
                            conn.Close();

                            Response.Write("<script languge='javascript'>alert('此3G卡启用成功'); window.location.href='TrafficExceed.aspx'</script>");
                        }
                        else
                        {
                            Response.Write("<script languge='javascript'>alert('此3G卡启用失败'); window.location.href='TrafficExceed.aspx'</script>");
                        }
                    }

                }

            }
            else
            {
                Response.Write("<script languge='javascript'>alert('查询3G卡信息失败'); window.location.href='TrafficExceed.aspx'</script>");
            }
        }

        else if (e.CommandName == "Ignore")
        {
            /////////////////截取控件中相应的字符/////////////////////////
            int index = int.Parse(e.CommandArgument.ToString());
            string fazhi = GridView1.Rows[index].Cells[4].Text;
            string client = GridView1.Rows[index].Cells[5].Text;
            string IP = GridView1.Rows[index].Cells[6].Text;
            string card = GridView1.Rows[index].Cells[7].Text;
            string State = GridView1.Rows[index].Cells[10].Text;
            /////////////////////////////////////////////////////////////

            string sql = "";
            string sql2 = "";
            string StateIgnore = "忽略";
            string StateRestore = "启用";

            //获取当前登陆用户IP
            string anonymity = Request.UserHostAddress;
            string anonymityHostName = Request.UserHostName;

            string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
            string Role;

            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);

            if (State.Equals("启用"))
            {
                sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateIgnore, IP, card);
                //打开数据库连接
                conn.Open();

                //创建command对象
                SqlCommand command = new SqlCommand(sql, conn);
                int result = command.ExecuteNonQuery();
                conn.Close();



                Role = Session["loginname"].ToString();
                //写入数据库日志
                sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'将卡号为: {3} 忽略告警')", logtime, Role, anonymity, card);
                //打开数据库连接
                conn.Open();

                //创建command对象
                SqlCommand command2 = new SqlCommand(sql2, conn);
                int result2 = command2.ExecuteNonQuery();
                conn.Close();

                Response.Write("<script languge='javascript'>alert('此3G卡忽略成功'); window.location.href='TrafficExceed.aspx'</script>");
            }
            else if (State.Equals("忽略"))
            {
                sql = string.Format("update ClientInfo set State = '{0}' where IP = '{1}' and Card = '{2}' ", StateRestore, IP, card);
                //打开数据库连接
                conn.Open();

                //创建command对象
                SqlCommand command = new SqlCommand(sql, conn);
                int result = command.ExecuteNonQuery();
                conn.Close();






                Role = Session["loginname"].ToString();
                //写入数据库日志
                sql2 = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'将卡号为: {3} 还原忽略')", logtime, Role, anonymity, card);
                //打开数据库连接
                conn.Open();

                //创建command对象
                SqlCommand command2 = new SqlCommand(sql2, conn);
                int result2 = command2.ExecuteNonQuery();
                conn.Close();

                Response.Write("<script languge='javascript'>alert('此3G卡还原忽略成功'); window.location.href='TrafficExceed.aspx'</script>");
            }
        }
    }

    #endregion


    #region  点击注销的事件
    protected void btnExit_Click(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'注销登陆')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }


        Session.Clear();
        Response.Write("<script languge='javascript'>alert('注销成功'); window.location.href='../Login.aspx'</script>");
    }
    #endregion


    #region 网页报错事件
    protected void Page_Error(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'网页报错弹出error页面')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }
    }
    #endregion


}
