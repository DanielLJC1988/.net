﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Net;

public partial class web_TrafficPoolUser : System.Web.UI.Page
{
    //定义全局变量类Condition，其中的condition
    class Condition
    {
        //用来把sql语句赋值给下面的全局变量

        public static string sql1 = "";
        public static string sql2 = "";
        public static string sql3 = "";
        public static string strSQL = "";
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["loginname"] == null)
        {

            Response.Write("<script languge='javascript'>alert('非法登陆，请重新登陆'); window.location.href='../Login.aspx'</script>");
        }
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        //调用按钮方法
        btnclickMethod();
    }

    #region 提交按钮方法
    private void btnclickMethod()
    {

        string fazhi = DropDownList1.Text;
        string sql;

        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add(new DataColumn("用户名", typeof(string)));
        dt.Columns.Add(new DataColumn("已使用流量(GB)", typeof(string)));

        //定义连接字符串
        string strconn = ConfigurationManager.ConnectionStrings["3GTrafficConnectionString"].ConnectionString;
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();

        //string sql = " select ClientName,sum(流量) as 流量 from (select source ,sum(traffic) as 流量  from Traffic2 where (Traffic2.source like '10.32%' or Traffic2.source like '172.16%'  or Traffic2.source like '169.%'  or Traffic2.source like '10.3%' ) and (Traffic2.date >= '2017-7-1' and Traffic2.date <= '2017-7-31') group by source union select Traffic.source ,sum(Traffic.traffic) as 流量 from Traffic where (Traffic.source like '10.32%'  or Traffic.source like '172.16%'  or Traffic.source like '169.%'  or Traffic.source like '10.3%' ) and (Traffic.date >= '2017-7-1' and Traffic.date <= '2017-7-31') group by source )Traffic2 left join ClientInfo  ON source = IP group by ClientName,CardType having ClientName <> '闲置在库'  and CardType <> '' order by 流量 DESC ";
        if (fazhi == "3G电信卡池")
        {
            Condition.sql1 = " select TOP(5) ClientCompany,sum(流量) as 流量 from (select TrafficL2.users ,sum(total)/1024 as 流量  from TrafficL2 where TrafficL2.date >= '2017-7-1' and TrafficL2.date <= '2017-7-31' group by TrafficL2.users)TrafficL2 inner join ClientInfo  ON L2user = TrafficL2.users  where ClientCompany <> '闲置在库'  and CardType = '3G卡' and OperatorType = '电信' and (Card is not NULL or Card != '') group by ClientCompany   order by 流量 DESC ";
            Condition.strSQL = Condition.sql1;
        }
        else if (fazhi == "3G联通卡池")
        {
            Condition.sql2 = " select TOP(5) ClientCompany,sum(流量) as 流量 from (select TrafficL2.users ,sum(total)/1024 as 流量  from TrafficL2 where TrafficL2.date >= '2017-7-1' and TrafficL2.date <= '2017-7-31' group by TrafficL2.users)TrafficL2 inner join ClientInfo  ON L2user = TrafficL2.users  where ClientCompany <> '闲置在库'  and CardType = '3G卡' and OperatorType = '联通' and (Card is not NULL or Card != '') group by ClientCompany   order by 流量 DESC ";
            Condition.strSQL = Condition.sql2;
        }
        else if (fazhi == "4G电信卡池")
        {
            Condition.sql3 = " select TOP(5) ClientCompany,sum(流量) as 流量 from (select TrafficL2.users ,sum(total)/1024 as 流量  from TrafficL2 where TrafficL2.date >= '2017-7-1' and TrafficL2.date <= '2017-7-31' group by TrafficL2.users)TrafficL2 inner join ClientInfo  ON L2user = TrafficL2.users  where ClientCompany <> '闲置在库'  and CardType = '4G卡' and OperatorType = '深圳电信' and (Card is not NULL or Card != '') group by ClientCompany   order by 流量 DESC ";
            Condition.strSQL = Condition.sql3;
        }

        sql = Condition.strSQL;

        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.ExecuteNonQuery();
        SqlDataReader myReader = cmd.ExecuteReader();
        while (myReader.Read())
        {
            dr = dt.NewRow();
            dr[0] = myReader["ClientCompany"].ToString();
            dr[1] = myReader["流量"].ToString();
            dt.Rows.Add(dr);
        }
        myReader.Dispose();
        myReader.Close();
        conn.Close();
        GridView1.DataSource = new DataView(dt);
        GridView1.DataBind();//

    }
    #endregion


    #region  鼠标悬停在列上时触发的事件
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //首先判断是否是数据行
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //当鼠标停留时更改背景色
                e.Row.Attributes.Add("onmouseover", "c=this.style.backgroundColor;this.style.backgroundColor='#CCCCCC'");
                //当鼠标移开时还原背景色
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=c");
                e.Row.Attributes["style"] = "Cursor:pointer ";
            }

            
        }



    }
    #endregion


    #region  点击注销的事件
    protected void btnExit_Click(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'注销登陆')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }


        Session.Clear();
        Response.Write("<script languge='javascript'>alert('注销成功'); window.location.href='../Login.aspx'</script>");
    }
    #endregion


    #region 网页报错事件
    protected void Page_Error(object sender, EventArgs e)
    {
        //获取当前登陆用户IP
        string anonymity = Request.UserHostAddress;
        string anonymityHostName = Request.UserHostName;

        string logtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        string sql = "";
        string Role;
        //会由于超时，导致无法取到session的值，导致赋值失败，加入判断，当有session值时才进行赋值
        if (Session["loginname"] != null)
        {
            Role = Session["loginname"].ToString();


            //声明数据库
            string strconn = "server=FASHION-TEC;database=3GTraffic;uid=sa;pwd=ex78684858";
            SqlConnection conn = new SqlConnection(strconn);
            //写入数据库日志
            sql = string.Format("INSERT INTO InfoLog(infotime, username, infolog) values ('{0}','{1} IP:' + '{2}' ,'网页报错弹出error页面')", logtime, Role, anonymity);
            //打开数据库连接
            conn.Open();

            //创建command对象
            SqlCommand command = new SqlCommand(sql, conn);
            int result = command.ExecuteNonQuery();
            conn.Close();
        }
    }
    #endregion
}

